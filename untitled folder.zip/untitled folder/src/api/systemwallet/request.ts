import { axiosInstance } from 'api/axios';
import { IWalletSystemRequest } from './types';

export const postMethod = async (request: IWalletSystemRequest): Promise<any> => {
  const { data } = await axiosInstance.post(`/wallet/tx/send`, request);
  return data;
};
