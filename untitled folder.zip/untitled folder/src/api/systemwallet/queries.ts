import { axiosInstance } from 'api/axios';
import { useQuery, UseQueryOptions } from 'react-query';

export const useGetTxid = (requestId: any, options?: UseQueryOptions<any>) => {
  return useQuery<any>(
    ['wallet/tx/getTxid', requestId],
    async () => {
      const { data } = await axiosInstance.get(`/wallet/tx/getTxid/${requestId}`);
      return data;
    },
    options
  );
};
