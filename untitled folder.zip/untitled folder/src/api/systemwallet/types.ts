export interface IWalletSystemRequest {
  currency?: string;
  method?: string;
  data?: any;
  emailCode?: string;
  twofa?: string;
  price?: any;
}
