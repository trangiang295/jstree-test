import { axiosInstance } from 'api/axios';
import { IPaginationRequest, IPaginationResponse } from 'api/types';
import { useQuery, UseQueryOptions } from 'react-query';
import { ICategoryDetailRequest, ICategoryDetailResponse, ICategoryResponse } from './types';

export const useGetCategoryFAQ = (
  params: IPaginationRequest,
  options?: UseQueryOptions<{ list: ICategoryResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: ICategoryResponse[]; pagination: IPaginationResponse }>(
    ['/articles/list-category', params],
    async () => {
      const { data } = await axiosInstance.get(`/articles/list-category`, { params });
      return data;
    },
    options
  );
};

export const useGetListCategoryById = (
  params: ICategoryDetailRequest,
  options?: UseQueryOptions<{ list: ICategoryDetailResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: ICategoryDetailResponse[]; pagination: IPaginationResponse }>(
    ['/articles/item-detail-category', params],
    async () => {
      const { data } = await axiosInstance.get(`/articles/item-detail-category`, { params });
      const temp = data?.list?.map((item: any) => ({ ...item, title: item.answer, content: item.question }));
      data.list = temp;
      return data;
    },
    options
  );
};
