export interface ICategoryResponse {
  id: number;
  categoryName: string;
  createdAt: string;
  updatedAt: string;
}

export interface ICategoryDetailRequest {
  page: number;
  limit: number;
  id: string;
}

export interface ICategoryDetailResponse {
  id: number;
  createdAt: string;
  updatedAt: string;
  categoryId: number;
  question: string;
  answer: string;
  title: string;
  content: string;
}
