export interface IBrandResponse {
  id: number;
  brandName: string;
  description: string;
  status: null | number;
  logoUrl: string;
  logoType: string;
  descriptionUrl: string;
  descriptionType: string;
  createdAt: string;
  updatedAt: string;
  collections: ICollectionResponse[];
  brand_name: string;
  description_url: string;
}

export interface ICollectionResponse {
  id: number;
  name: string;
  description: string;
  image_url: string;
  brand_name: string;
  brand_id: number;
  owner_name: null | string;
  owner_email: null | string;
  owner_first_name: null | string;
  owner_last_name: null | string;
}

export interface IAboutResponse {
  id: number;
  title: string;
  description: string;
  logoUrl: string;
  logoType: string;
  createdAt: string;
  updatedAt: string;
}

export interface ICategoryResponse {
  id: string;
  categoryName: string;
  categoryDescription: string;
  createdAt: string;
  updatedAt: string;
}
