import { axiosInstance } from 'api/axios';
import { IPaginationRequest, IPaginationResponse } from 'api/types';
import { useQuery, UseQueryOptions } from 'react-query';
import { IAboutResponse, IBrandResponse, ICategoryResponse } from './types';

export const useGetListBrands = (
  params: IPaginationRequest,
  options?: UseQueryOptions<{ list: IBrandResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: IBrandResponse[]; pagination: IPaginationResponse }>(
    ['brand/list-brand', params],
    async () => {
      const { data } = await axiosInstance.get(`/brand/list-brand`, { params });
      return data;
    },
    options
  );
};

export const useGetBrandDetail = (id: string, options?: UseQueryOptions<IBrandResponse>) => {
  return useQuery<IBrandResponse>(
    ['brand/detail-brand', id],
    async () => {
      const { data } = await axiosInstance.get(`/brand/detail-brand/${id}`);
      return data;
    },
    options
  );
};

export const useGetAbout = (
  params: IPaginationRequest,
  options?: UseQueryOptions<{ list: IAboutResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: IAboutResponse[]; pagination: IPaginationResponse }>(
    ['/articles/list-about', params],
    async () => {
      const { data } = await axiosInstance.get(`/articles/list-about`, { params });
      return data;
    },
    options
  );
};

export const useGetListCategory = (
  params: IPaginationRequest,
  options?: UseQueryOptions<{ list: ICategoryResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: ICategoryResponse[]; pagination: IPaginationResponse }>(
    ['category/list-category-of-collection', params],
    async () => {
      const { data } = await axiosInstance.get(`/category/list-category-of-collection`, { params });
      return data;
    },
    options
  );
};
