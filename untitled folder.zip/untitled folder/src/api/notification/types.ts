export interface INotificationParams {
  page: number;
  limit: number;
}

export interface INotificationRequest {
  id: 8;
  fromUser: string;
  totoUser: string;
  data: any;
  type: number;
  isRead: boolean;
  collectionId: number;
  nftId: number;
  createdAt: string;
  updatedAt: string;
}

export interface INotificationNotReadResponse {
  Total: string;
}

export interface INotifcationIsReadRequest {
  id: number;
}
