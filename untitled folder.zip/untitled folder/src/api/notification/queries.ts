import { axiosInstance } from 'api/axios';
import { useQuery, UseQueryOptions } from 'react-query';
import { INotificationNotReadResponse, INotificationParams, INotificationRequest } from './types';
import { IPaginationResponse } from 'api/types';

export const useGetListNotifications = (
  params?: INotificationParams,
  options?: UseQueryOptions<{ list: INotificationRequest[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: INotificationRequest[]; pagination: IPaginationResponse }>(
    ['notification/list', params],
    async () => {
      const { data } = await axiosInstance.get(`/notification/list`, { params });
      return data;
    },
    {
      keepPreviousData: true,
      ...options,
    }
  );
};

export const useGetNumberNotReadNotification = (
  wallet: any,
  options?: UseQueryOptions<INotificationNotReadResponse[]>
) => {
  return useQuery<INotificationNotReadResponse[]>(
    ['notification/total-not-read', wallet],
    async () => {
      const { data } = await axiosInstance.get(`/notification/total-not-read`);
      return data;
    },
    {
      keepPreviousData: true,
      ...options,
    }
  );
};
