import { axiosInstance } from 'api/axios';
import { INotifcationIsReadRequest } from './types';

export const updateIsRead = async (request: INotifcationIsReadRequest): Promise<any> => {
  const { data } = await axiosInstance.post(`/notification/update`, request);
  return data;
};
