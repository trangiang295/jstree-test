export interface ICreateNFTResponse {
  collectionId: string;
  collectionName: string;
  name: string;
  slug: string;
  description: string;
  paymentToken: string;
  price: string;
  quantity: string;
  imageUrl: string;
  ownerId: number;
  data: string;
  createdAt: string;
  updatedAt: string;
  status: string;
  type: string | null;
  id: number;
  url_ipfs: string;
}
export interface INFTDetailResponse {
  id?: number;
  collectionId?: number;
  name?: string;
  slug?: string;
  description?: string;
  quantity?: string;
  price?: string;
  status?: string;
  type?: string | null;
  data?: string | null;
  ownerId?: number;
  createdAt?: string;
  updatedAt?: string;
  owner?: string;
  tokenUri?: string;
  order_id?: any;
  meta_data?: string;
  block_timestamp?: string;
  image_url?: string;
  collection_name?: string;
  owner_name?: string;
  owner_email?: string;
  token_id?: string;
  token_uri?: string;
  human_owner?: string;
  contract_address?: string | null;
  collection_id?: string;
  payment_token?: string;
  is_onsale?: any;
  image_type: string;
}

export interface INFTResponse {
  token_id: number;
  token_uri: string;
  owner: string;
  human_owner: string;
  status: string;
  contract_address: string;
  name: string;
  description: string;
  image_url: string;
  collection_name: string;
  price: number;
  owner_name?: string | null;
  owner_email?: string | null;
  edition?: number | null;
  image_type: string;
}

export interface IActiveNFTRequest {
  id: number;
  status: string;
}

export interface IUpdateNFTRequest {
  id: number;
  price?: number;
  paymentToken?: string;
}

export interface INFTParams {
  limit?: number;
  page?: number;
  status?: string | null;
  name?: string | null;
  collectionName?: string;
  collectionId?: string;
}

export interface INFTMintRequest {
  quantity: number;
  currency: string;
  id: string;
}

export interface INFTMintResponse {
  data: boolean;
}

export interface IHistoryResponse {
  token_id: number | null;
  contract_address: string | null;
  from: string | null;
  to: string | null;
  nft_action: string | null;
  txid: string | null;
  updated_at: string | null;
  log_action: string | null;
  price: string | null;
  payment_token: string | null;
  owner_from_name: string | null;
  owner_from_email: string | null;
  owner_to_name: string | null;
  owner_to_email: string | null;
}
