import { INFTResponse } from 'api/nft';
import { axiosInstance } from 'api/axios';
import { useQuery, UseQueryOptions } from 'react-query';
import { IHistoryResponse, INFTDetailResponse, INFTParams } from './types';
import { IOffersRequest, IOffersResponse, IPaginationRequest, IPaginationResponse } from 'api/types';

export const useGetListOwnerNFT = (
  params?: INFTParams,
  options?: UseQueryOptions<{ list: INFTResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: INFTResponse[]; pagination: IPaginationResponse }>(
    ['nft/list-of-owner', params],
    async () => {
      const { data } = await axiosInstance.get(`/nft/list-of-owner`, { params });
      return data;
    },
    {
      keepPreviousData: true,
      ...options,
    }
  );
};

export const useGetListNFT = (
  params?: INFTParams,
  options?: UseQueryOptions<{ list: INFTResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: INFTResponse[]; pagination: IPaginationResponse }>(
    ['nft/list', params],
    async () => {
      const { data } = await axiosInstance.get(`/nft/list`, { params });
      return data;
    },
    {
      keepPreviousData: true,
      ...options,
    }
  );
};

export const useGetNFT = (id: any, options?: UseQueryOptions<INFTDetailResponse>) => {
  return useQuery<INFTDetailResponse>(
    'nft/item',
    async () => {
      const { data } = await axiosInstance.get(`/nft/item/${id}`);
      return data[0];
    },
    options
  );
};

export const useGetHistory = (
  id: any,
  params: IPaginationRequest,
  options?: UseQueryOptions<{ list: IHistoryResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: IHistoryResponse[]; pagination: IPaginationResponse }>(
    ['nft/log', params],
    async () => {
      const { data } = await axiosInstance.get(`/nft/log/${id}`, { params });
      return data;
    },
    options
  );
};

export const useGetOffers = (
  params: IOffersRequest,
  options?: UseQueryOptions<{ list: IOffersResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: IOffersResponse[]; pagination: IPaginationResponse }>(
    ['nft/offers', params],
    async () => {
      const { data } = await axiosInstance.get(`/nft/offers`, { params });
      return data;
    },
    options
  );
};

export const useGetOfferDetail = (id: any, options?: UseQueryOptions<IOffersResponse>) => {
  return useQuery<IOffersResponse>(
    ['nft/offers', id],
    async () => {
      const { data } = await axiosInstance.get(`/nft/offer/${id}`);
      return data;
    },
    options
  );
};

export const useGetListOwnerOffer = (
  params?: INFTParams,
  options?: UseQueryOptions<{ list: INFTResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: INFTResponse[]; pagination: IPaginationResponse }>(
    ['nft/offers-owner', params],
    async () => {
      const { data } = await axiosInstance.get(`/nft/offers-owner`, { params });
      return data;
    },
    {
      keepPreviousData: true,
      ...options,
    }
  );
};

export const useGetListBidderOffer = (
  params?: INFTParams,
  options?: UseQueryOptions<{ list: INFTResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: INFTResponse[]; pagination: IPaginationResponse }>(
    ['nft/offers-bidder', params],
    async () => {
      const { data } = await axiosInstance.get(`/nft/offers-bidder`, { params });
      return data;
    },
    {
      keepPreviousData: true,
      ...options,
    }
  );
};

export const useGetCommission = (options?: UseQueryOptions<number>) => {
  return useQuery<number>(
    '/commission',
    async () => {
      const { data } = await axiosInstance.get(`/commission`);
      return data;
    },
    {
      ...options,
    }
  );
};
