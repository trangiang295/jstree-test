import { axiosInstance } from 'api/axios';
import { ICreateNFTResponse, IActiveNFTRequest, INFTMintRequest, INFTMintResponse, IUpdateNFTRequest } from './types';

export const createNft = async (request: FormData): Promise<ICreateNFTResponse> => {
  const { data } = await axiosInstance.post(`/nft/create`, request);
  return data;
};

export const updateStatusNft = async (request: IActiveNFTRequest): Promise<ICreateNFTResponse> => {
  const { data } = await axiosInstance.post(`/nft/update-status`, request);
  return data;
};

export const updateNft = async (request: IUpdateNFTRequest): Promise<ICreateNFTResponse> => {
  const { data } = await axiosInstance.post(`/nft/update`, request);
  return data;
};

export const mintNftSystem = async (request: INFTMintRequest): Promise<INFTMintResponse> => {
  const { data } = await axiosInstance.post(`/nft/mint/${request.id}`, request);
  return data;
};
