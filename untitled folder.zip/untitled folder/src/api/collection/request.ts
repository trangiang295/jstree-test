import { axiosInstance } from 'api/axios';
import { ICollectionResponse } from './types';

export const createCollection = async (request: FormData): Promise<ICollectionResponse> => {
  const { data } = await axiosInstance.post(`/collection/create`, request);
  return data;
};

export const updateCollection = async (request: FormData): Promise<ICollectionResponse> => {
  const { data } = await axiosInstance.post(`/collection/update`, request);
  return data;
};
