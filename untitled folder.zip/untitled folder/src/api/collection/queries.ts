import { ICollectionResponse, ICollectionParams } from 'api/collection';
import { axiosInstance } from 'api/axios';
import { useQuery, UseQueryOptions } from 'react-query';
import { IPaginationResponse } from 'api/types';

export const useGetListOwnerCollection = (
  params?: ICollectionParams,
  options?: UseQueryOptions<{ list: ICollectionResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: ICollectionResponse[]; pagination: IPaginationResponse }>(
    ['collection/list-of-owner', params],
    async () => {
      const { data } = await axiosInstance.get(`/collection/list-of-owner`, { params });
      return data;
    },
    {
      keepPreviousData: true,
      ...options,
    }
  );
};

export const useGetListCollection = (
  params?: ICollectionParams,
  options?: UseQueryOptions<{ list: ICollectionResponse[]; pagination: IPaginationResponse }>
) => {
  return useQuery<{ list: ICollectionResponse[]; pagination: IPaginationResponse }>(
    ['collection/list', params],
    async () => {
      const { data } = await axiosInstance.get(`/collection/list`, { params });
      return data;
    },
    {
      keepPreviousData: true,
      ...options,
    }
  );
};

export const useGetCollectionDetail = (id: any, options?: UseQueryOptions<ICollectionResponse>) => {
  return useQuery<ICollectionResponse>(
    ['collection/item', id],
    async () => {
      const { data } = await axiosInstance.get(`/collection/item/${id}`);
      return data;
    },
    options
  );
};

export const useGetCollectionHot = (options?: UseQueryOptions<ICollectionResponse[]>) => {
  return useQuery<ICollectionResponse[]>(
    'nft/list-collection-hot',
    async () => {
      const { data } = await axiosInstance.get(`/nft/list-collection-hot`);
      return data;
    },
    {
      ...options,
    }
  );
};
