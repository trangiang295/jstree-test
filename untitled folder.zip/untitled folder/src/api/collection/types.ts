export interface ICollectionResponse {
  id: number;
  name: string;
  slug: string;
  imageUrl: string;
  description: string;
  paymentToken: string;
  status: boolean | null;
  type: string | null;
  data: string | null;
  ownerId: number;
  ownerName: string;
  createdAt: string;
  updatedAt: string;
  image_url?: string;
}

export interface ICollectionParams {
  limit?: number;
  page?: number;
  status?: string;
  name?: string;
}
