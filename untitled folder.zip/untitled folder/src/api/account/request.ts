import { axiosInstance } from 'api/axios';
import {
  IRegisterRequest,
  IRegisterResponse,
  ILoginRequest,
  ILoginResponse,
  IResendEmailRequest,
  IResendEmailResponse,
  IResetPasswordResponse,
  IUserInfoResponse,
  IUpdatePasswordRequest,
  IResetPasswordRequest,
  ILoginExternalWalletRequest,
  IRegisterExternalWalletRequest,
  IUpdateSendEmailCode,
} from './types';

export const register = async (request: IRegisterRequest): Promise<IRegisterResponse> => {
  const { data } = await axiosInstance.post(`/user/register`, request);
  return data;
};

export const login = async (request: ILoginRequest): Promise<ILoginResponse> => {
  const { data } = await axiosInstance.post(`/user/login`, request);
  return data;
};

export const resendEmail = async (request: IResendEmailRequest): Promise<IResendEmailResponse> => {
  const { data } = await axiosInstance.post(`/user/resend-mail-active-user`, request);
  return data;
};

export const sendEmailResetPassword = async (request: IResendEmailRequest): Promise<IResetPasswordResponse> => {
  const { data } = await axiosInstance.post(`/user/send-mail-reset-password`, request);
  return data;
};

export const updateProfile = async (request: FormData): Promise<IUserInfoResponse> => {
  const { data } = await axiosInstance.post(`/user/update-profile`, request);
  return data;
};

export const updatePassword = async (request: IUpdatePasswordRequest): Promise<IUserInfoResponse> => {
  const { data } = await axiosInstance.post(`/user/update-password`, request);
  return data;
};

export const logout = async (): Promise<IRegisterResponse> => {
  const { data } = await axiosInstance.post(`/user/logout`);
  return data;
};

export const resetPassword = async (request: IResetPasswordRequest): Promise<IUserInfoResponse> => {
  const { data } = await axiosInstance.post(`/user/reset-password`, request);
  return data;
};

export const registerUserExternalWallet = async (
  request: IRegisterExternalWalletRequest
): Promise<IUserInfoResponse> => {
  const { data } = await axiosInstance.post(`/user/register-external-wallet`, request);
  return data;
};

export const loginExternalWallet = async (request: ILoginExternalWalletRequest): Promise<IUserInfoResponse> => {
  const { data } = await axiosInstance.post(`/user/login-external-wallet`, request);
  return data;
};

export const disable2FARequest = async (request: { twofa: string }): Promise<any> => {
  const { data } = await axiosInstance.post(`/user/disable-2fa`, request);
  return data;
};

export const active2FARequest = async (request: { twofa: string }): Promise<any> => {
  const { data } = await axiosInstance.post(`/user/active-2fa`, request);
  return data;
};

export const checkActive2FA = async (request: { email: string; password: string }): Promise<IUserInfoResponse> => {
  const { data } = await axiosInstance.post(`/user/is-active-2fa`, request);
  return data;
};

export const checkActiveSecurity = async (request: { email: string; password: string }): Promise<IUserInfoResponse> => {
  const { data } = await axiosInstance.post(`/user/is-active-security`, request);
  return data;
};

export const sendEmailCode = async (): Promise<any> => {
  const { data } = await axiosInstance.post(`/user/send-email-code`);
  return data;
};

export const updateSendEmailCode = async (request: IUpdateSendEmailCode): Promise<any> => {
  const { data } = await axiosInstance.post(`/user/update-status-email-code`, request);
  return data;
};
