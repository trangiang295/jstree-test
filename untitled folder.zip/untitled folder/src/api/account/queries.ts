import { IUserInfoResponse } from 'api/account';
import { axiosInstance } from 'api/axios';
import { useQuery, UseQueryOptions } from 'react-query';
import { LOCAL_STORAGE } from 'utils/constant';

export const useGetUserInfo = (options?: UseQueryOptions<IUserInfoResponse>) => {
  return useQuery<IUserInfoResponse>(
    'user/info-user',
    async () => {
      const { data } = await axiosInstance.get(`/user/info-user`);
      return data;
    },
    { ...options, enabled: !!localStorage.getItem(LOCAL_STORAGE.token) }
  );
};

export const useGet2FA = (options?: UseQueryOptions<any>) => {
  return useQuery<any>(
    'user/get-2fa',
    async () => {
      const { data } = await axiosInstance.post(`/user/get-2fa`);
      return data;
    },
    options
  );
};
