import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { IOffersResponse } from 'api/types';
import { RootState } from 'store';

export interface TNFTReducer {
  nftModal: 'create-nft' | 'deploy-nft' | 'update-nft' | 'offer' | 'transfer-nft' | null;
  dataMint: any;
  bidId: IOffersResponse | null;
  withDrawRequest: any;
}

const initialState = {
  nftModal: null,
  dataMint: {},
  bidId: null,
  withDrawRequest: {},
} as TNFTReducer;

const nftSlice = createSlice({
  name: 'nft',
  initialState,
  reducers: {
    setNFTModal(state, action: PayloadAction<TNFTReducer['nftModal']>) {
      return {
        ...state,
        nftModal: action.payload,
      };
    },
    setDataMint(state, action: PayloadAction<TNFTReducer['dataMint']>) {
      return {
        ...state,
        dataMint: action.payload,
      };
    },
    setBidId(state, action: PayloadAction<TNFTReducer['bidId']>) {
      return {
        ...state,
        bidId: action.payload,
      };
    },
    setWithDrawRequest(state, action: PayloadAction<TNFTReducer['withDrawRequest']>) {
      return {
        ...state,
        withDrawRequest: action.payload,
      };
    },
  },
});

export const getNFT = (state: RootState): TNFTReducer => state.nft;

export const getNFTModal = (state: RootState): TNFTReducer['nftModal'] => state.nft.nftModal;
export const getDataMint = (state: RootState): TNFTReducer['dataMint'] => state.nft.dataMint;
export const getBidId = (state: RootState): TNFTReducer['bidId'] => state.nft.bidId;
export const getWithDrawRequest = (state: RootState): TNFTReducer['withDrawRequest'] => state.nft.withDrawRequest;

export const { setNFTModal, setDataMint, setBidId, setWithDrawRequest } = nftSlice.actions;
export default nftSlice.reducer;
