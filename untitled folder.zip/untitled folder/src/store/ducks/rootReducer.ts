import { combineReducers } from '@reduxjs/toolkit';

import systemReducer from './system/slice';
import walletReducer from './wallet/slice';
import userReducer from './user/slice';
import nftReducer from './nft/slice';

const createRootReducer = () => {
  return combineReducers({
    system: systemReducer,
    wallet: walletReducer,
    user: userReducer,
    nft: nftReducer,
  });
};

export default createRootReducer;
