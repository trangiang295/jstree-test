import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from 'store';

export interface TSystemReducer {
  authModal:
    | 'login'
    | 'register'
    | 'forgot'
    | 'wallet'
    | 'resend-active'
    | 'register-wallet'
    | '2fa'
    | 'email-code'
    | 'transfer'
    | 'verify'
    | 'mobile'
    | null;
}

const initialState = {
  authModal: null,
} as TSystemReducer;

const systemSlice = createSlice({
  name: 'system',
  initialState,
  reducers: {
    setAuthModal(state, action: PayloadAction<TSystemReducer['authModal']>) {
      return {
        ...state,
        authModal: action.payload,
      };
    },
  },
});

export const getSystem = (state: RootState): TSystemReducer => state.system;

export const getAuthModal = (state: RootState): TSystemReducer['authModal'] => state.system.authModal;

export const { setAuthModal } = systemSlice.actions;
export default systemSlice.reducer;
