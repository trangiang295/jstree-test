import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from 'store';
import { LOCAL_STORAGE } from 'utils/constant';

export interface TUserReducer {
  token: string;
  signature: string;
  loginType: 'wallet' | 'email' | null;
  wallet: string | undefined;
  file: any;
  loginRequest: any;
  balance: any;
}

const initialState = {
  token: localStorage.getItem(LOCAL_STORAGE.token),
  loginType: localStorage.getItem(LOCAL_STORAGE.type),
  signature: localStorage.getItem(LOCAL_STORAGE.signature),
  wallet: localStorage.getItem(LOCAL_STORAGE.wallet),
  file: '',
  loginRequest: {},
  balance: { usdc: 0, token: 0, nft: 0, matic: 0 },
} as TUserReducer;

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setToken(state, action: PayloadAction<TUserReducer['token']>) {
      return {
        ...state,
        token: action.payload,
      };
    },
    setLoginType(state, action: PayloadAction<TUserReducer['loginType']>) {
      return {
        ...state,
        loginType: action.payload,
      };
    },
    setSignature(state, action: PayloadAction<TUserReducer['signature']>) {
      return {
        ...state,
        signature: action.payload,
      };
    },
    setWallet(state, action: PayloadAction<TUserReducer['wallet']>) {
      return {
        ...state,
        wallet: action.payload,
      };
    },
    setFile(state, action: PayloadAction<TUserReducer['file']>) {
      return {
        ...state,
        file: action.payload,
      };
    },
    setLoginRequest(state, action: PayloadAction<TUserReducer['loginRequest']>) {
      return {
        ...state,
        loginRequest: action.payload,
      };
    },
    setBalance(state, action: PayloadAction<TUserReducer['balance']>) {
      return {
        ...state,
        balance: action.payload,
      };
    },
  },
});

export const getToken = (state: RootState): TUserReducer['token'] => state.user.token;
export const getLoginType = (state: RootState): TUserReducer['loginType'] => state.user.loginType;
export const getSignature = (state: RootState): TUserReducer['signature'] => state.user.signature;
export const getWallet = (state: RootState): TUserReducer['wallet'] => state.user.wallet;
export const getFile = (state: RootState): TUserReducer['file'] => state.user.file;
export const getLoginRequest = (state: RootState): TUserReducer['loginRequest'] => state.user.loginRequest;
export const getBalance = (state: RootState): TUserReducer['balance'] => state.user.balance;

export const { setToken, setLoginType, setSignature, setWallet, setFile, setLoginRequest, setBalance } =
  userSlice.actions;
export default userSlice.reducer;
