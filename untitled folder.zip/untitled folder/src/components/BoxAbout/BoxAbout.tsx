import { Col } from 'antd';
import { FC } from 'react';
import styles from './BoxAbout.module.less';
import clsx from 'clsx';

export const BoxAbout: FC<{ title: string; content: string; index: number }> = ({ index, title, content }) => {
  return (
    <Col xs={24} md={12} className={clsx(styles.root, 'mt-4')}>
      <div className={`d-flex w-75 ${index % 2 === 1 ? 'mx-auto ms-md-auto' : 'mx-auto'}`}>
        <div className="ps-lg-5">
          <h5 className={styles.title}>{title}</h5>
          <div className={styles.content} dangerouslySetInnerHTML={{ __html: content }} />
        </div>
      </div>
    </Col>
  );
};
