import { UploadProps as AntdUploadProps, Upload as UploadAntd } from 'antd';
import { UploadChangeParam } from 'antd/lib/upload';
import { UploadFile } from 'antd/lib/upload/interface';
import clsx from 'clsx';
import { FC, useEffect, useState } from 'react';
import { AiOutlinePlus } from 'react-icons/ai';
import { configForm } from 'utils/form';
import { message } from 'utils/message';
import styles from './styles.module.less';

type UploadProps = AntdUploadProps & {
  className?: string;
  onChangeFile?: Function;
  imageUrl?: any;
  onSubmitFailUpload?: any;
};

export const Upload: FC<UploadProps> = ({ className, onChangeFile, imageUrl, onSubmitFailUpload }) => {
  const [file, setFile] = useState<UploadFile<any>[]>();
  const [checkFile, setCheckFile] = useState(0);

  useEffect(() => {
    if (imageUrl) {
      setFile([
        {
          uid: '-1',
          status: 'done',
          url: imageUrl, // is imageUrl
          // name: value.substring(value.lastIndexOf('/') + 1),
          name: 'abc',
        },
      ]);
    }
  }, [imageUrl]);

  const onChange = (info: UploadChangeParam) => {
    const file = info?.file;
    if (file?.status === 'removed') return;
    if (file) {
      const isJpgOrPng = configForm.allowedImageContentType.includes(file.type as string);
      if (!isJpgOrPng) {
        setCheckFile(2);
        onSubmitFailUpload(true);
        message.error('You can only upload JPG/PNG/GIF file!');
        return false;
      }
      const fileLarger = (file.size as number) / 1024 / 1024 < configForm.maxImageFileSize;
      if (!fileLarger) {
        setCheckFile(2);
        onSubmitFailUpload(true);
        message.error(`Image must smaller than ${configForm.maxImageFileSize}MB!`);
        return false;
      }
    }
    onSubmitFailUpload(false);
    setCheckFile(1);
    setFile(info.fileList);
    if (onChangeFile) {
      onChangeFile(file);
    }
    return false;
  };

  const onRemove = () => {
    setCheckFile(0);
    onSubmitFailUpload(false);
    setFile(undefined);
    if (onChangeFile) {
      onChangeFile(undefined);
    }
  };

  const onPreview = async (file: any) => {
    let src = file.url;
    if (!src) {
      src = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.readAsDataURL(file.originFileObj);
        reader.onload = () => resolve(reader.result);
      });
    }
    const image = new Image();
    image.src = src;
    const imgWindow = window.open(src);
    imgWindow?.document.write(image.outerHTML);
  };

  return (
    <UploadAntd
      className={clsx(className, checkFile === 2 ? styles.uploadFail : '')}
      beforeUpload={() => false}
      maxCount={1}
      onChange={onChange}
      listType="picture-card"
      fileList={file}
      onRemove={onRemove}
      onPreview={onPreview}
    >
      {checkFile === 0 && <AiOutlinePlus />}
    </UploadAntd>
  );
};
