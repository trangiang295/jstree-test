import { Divider, Tooltip } from 'antd';
import { Surface } from 'components/Surface';
import { FC, useMemo } from 'react';
import styles from './NFTCard.module.less';
import avatar from 'assets/images/Avatar.png';
import { Button } from 'components/Button';
import { useHistory } from 'react-router-dom';
import { convertEther, formatNumberFixed } from 'utils/number';
import { getWallet } from 'store/ducks/user/slice';
import { useAppSelector } from 'hooks';
import { Video } from 'components/Media';

type CardProps = {
  type: string;
  image: string;
  name: string;
  price: number;
  edition: string | number;
  owner: string | null;
  ownerAddress: string;
  brand: string;
  id: number;
  onClick?: () => void;
};

export const NFTCard: FC<CardProps> = ({
  type,
  image,
  name,
  price,
  edition,
  owner,
  ownerAddress,
  brand,
  id,
  onClick,
}) => {
  const history = useHistory();
  const wallet = useAppSelector(getWallet);

  const onBuy = (event: Event) => {
    event.stopPropagation();
    history.push(`/sell-nft/summary/${id}`);
  };

  const priceAction = useMemo(() => {
    if (price) {
      const formatPrice = `${formatNumberFixed(convertEther(price), 2)} USDC`;
      if (formatPrice.length > 10) {
        return <Tooltip title={formatPrice}>{formatPrice}</Tooltip>;
      } else return <span>{formatPrice}</span>;
    }

    if (wallet === ownerAddress) {
      return (
        <Button className={styles.button} onClick={(event: any) => onBuy(event)}>
          Sell
        </Button>
      );
    }

    return '---';
  }, [price]);

  return (
    <Surface className={styles.root} onClick={onClick}>
      {type === 'video/mp4' ? (
        <Video src={image} className={styles.image} />
      ) : (
        <div style={{ backgroundImage: `url("${image}")` }} className={styles.image}></div>
      )}

      <div className={styles.cardContent}>
        <div className={styles.ownerContainer}>
          <img src={avatar} className={styles.avatar} />
          <div className={styles.ownerName}>{owner}</div>
        </div>
        <div className={styles.name}>{name}</div>
        <Divider className="my-3" />
        <div className={styles.priceContainer}>
          <div className={styles.price}>{priceAction}</div>
          <div className={styles.editionContainer}>
            <div>{brand}</div>
            <div>Edition: {edition}</div>
          </div>
        </div>
      </div>
    </Surface>
  );
};
