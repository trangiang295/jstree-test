import { Col, Row } from 'antd';
import { Button } from 'components/Button';
import { Input } from 'components/Input';
import { FC } from 'react';
import styles from './NewsLetter.module.less';

export const NewsLetter: FC = () => {
  return (
    <Row className={styles.root} align="middle" justify="space-around">
      <Col md={8} xs={24} className="text-center">
        <strong>Subscribe to our newsletter</strong>
      </Col>
      <Col md={8} xs={24} className="text-center">
        <Input placeholder="Email*" />
      </Col>
      <Col md={8} xs={24} className="text-center">
        <Button>SUBSCRIBE</Button>
      </Col>
    </Row>
  );
};
