export { FAQ } from './FAQ';
