import { Space } from 'antd';
import { useGetListCategoryById } from 'api/faq';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Collapse } from 'components/Collapse';
import { HeaderTitle } from 'components/HeaderTitle';
import { routesEnum } from 'pages/Routes';
import { FC } from 'react';
import { useHistory } from 'react-router-dom';
import styles from './FAQ.module.css';

export const FAQ: FC = () => {
  const history = useHistory();
  const { data: categories } = useGetListCategoryById({
    id: '2',
    page: 1,
    limit: 20,
  });
  return (
    <div className={clsx(styles.root, 'container')}>
      <HeaderTitle title="FAQ" />
      <Collapse data={categories?.list || []} />
      <Space className="my-5" direction="vertical" align="center">
        <Button className="customBtnCommon" onClick={() => history.push(routesEnum.faq)}>
          SEE ALL FAQs
        </Button>
      </Space>
    </div>
  );
};
