import { Layout } from 'antd';
import clsx from 'clsx';
import { useAppDispatch, useAppSelector } from 'hooks';
import { routesEnum } from 'pages/Routes';
import { AiOutlineMenu, AiOutlineSearch } from 'react-icons/ai';
import { Link } from 'react-router-dom';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';

import styles from './Mobile.module.less';
import MobileModal from './Modal/MobileModal';

const NavbarMobile = () => {
  const dispatch = useAppDispatch();
  const state = useAppSelector(getAuthModal);

  return (
    <Layout.Header className={styles.root}>
      <AiOutlineMenu
        className={styles.icon}
        onClick={() => dispatch(setAuthModal(state === 'mobile' ? null : 'mobile'))}
      />
      <Link className={clsx(styles.logo, 'fs-2 fw-bolder me-3 lh-1 text-white')} to={routesEnum.home}>
        Verdant
      </Link>
      <AiOutlineSearch className={styles.icon} />
      <MobileModal />
    </Layout.Header>
  );
};

export default NavbarMobile;
