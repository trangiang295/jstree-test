import { Divider, Menu as MenuAntd } from 'antd';
import { FC } from 'react';
import { useHistory } from 'react-router-dom';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { logout, useGetUserInfo } from 'api/account';
import { setLoginType, setToken, setWallet } from 'store/ducks/user/slice';
import { useAppDispatch } from 'hooks';
import { routesEnum } from 'pages/Routes';
import { message } from 'utils/message';
import styles from './Menu.module.less';
import { GoogleOutlined, LogoutOutlined, MailOutlined, UserOutlined, WalletOutlined } from '@ant-design/icons';

export const Menu: FC = () => {
  const history = useHistory();
  const dispatch = useAppDispatch();
  const { data: userInfo } = useGetUserInfo();

  const { mutate: mutateLogout } = useMutation(logout, {
    onSuccess: () => {
      localStorage.clear();
      dispatch(setToken(''));
      dispatch(setLoginType(null));
      dispatch(setWallet(''));
      history.push(routesEnum.home);
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const handleLogout = () => {
    mutateLogout();
  };

  return (
    <MenuAntd mode="inline" className={styles.root}>
      <MenuAntd.Item key={routesEnum.profile} icon={<UserOutlined />} onClick={() => history.push(routesEnum.profile)}>
        Account
      </MenuAntd.Item>
      {userInfo?.type === 'email' && (
        <>
          <MenuAntd.Item
            key={routesEnum.google2fa}
            icon={<GoogleOutlined />}
            onClick={() => history.push(routesEnum.google2fa)}
          >
            Google 2FA
          </MenuAntd.Item>
          <MenuAntd.Item
            key={routesEnum.emailActiveCode}
            icon={<MailOutlined />}
            onClick={() => history.push(routesEnum.emailActiveCode)}
          >
            Active Email Code
          </MenuAntd.Item>
        </>
      )}
      <MenuAntd.Item key={routesEnum.wallet} icon={<WalletOutlined />} onClick={() => history.push(routesEnum.wallet)}>
        My Wallet
      </MenuAntd.Item>
      <Divider className={styles.divider} />
      <MenuAntd.Item key="4" icon={<LogoutOutlined />} onClick={handleLogout}>
        Logout
      </MenuAntd.Item>
    </MenuAntd>
  );
};
