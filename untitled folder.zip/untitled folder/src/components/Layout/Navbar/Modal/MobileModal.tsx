import { Divider, Drawer, Typography } from 'antd';
import { logout, useGetUserInfo } from 'api/account';
import { IError } from 'api/types';
import { useAppDispatch, useAppSelector } from 'hooks';
import { routesEnum } from 'pages/Routes';
import { FC, useEffect, useMemo } from 'react';
import { useMutation } from 'react-query';
import { Link, useHistory, useLocation } from 'react-router-dom';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';
import { setLoginType, setToken, setWallet } from 'store/ducks/user/slice';
import { message } from 'utils/message';
import { navigationRoutes } from '../routes';
import styles from './styles.module.less';

const { Paragraph } = Typography;

const LIST_MENU = [
  { title: 'Newsletter', path: routesEnum.newsletter },
  { title: 'About', path: routesEnum.about },
  { title: 'Privacy Policy', path: routesEnum.privacy },
  { title: 'Terms of service', path: routesEnum.termsService },
  { title: 'Support', path: '/' },
];

const MobileModal: FC = () => {
  const history = useHistory();
  const dispatch = useAppDispatch();
  const state = useAppSelector(getAuthModal);
  const visible = useMemo(() => state === 'mobile', [state]);
  const location = useLocation();
  const { token } = useAppSelector((state) => state.user);
  const { data: userInfo } = useGetUserInfo({ enabled: !!token });

  useEffect(() => {
    dispatch(setAuthModal(null));
  }, [location.pathname]);

  const { mutate: mutateLogout } = useMutation(logout, {
    onSuccess: () => {
      localStorage.clear();
      dispatch(setToken(''));
      dispatch(setLoginType(null));
      dispatch(setWallet(''));
      history.push(routesEnum.home);
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const handleLogout = () => {
    mutateLogout();
  };

  return (
    <Drawer
      height="100%"
      width="100%"
      className={styles.drawer}
      visible={visible}
      onClose={() => dispatch(setAuthModal(null))}
      closable={false}
      placement="left"
    >
      {!token ? (
        <Paragraph strong className="pt-4 px-5" onClick={() => dispatch(setAuthModal('login'))}>
          Login/Sign up
        </Paragraph>
      ) : (
        <Link to={routesEnum.profile}>
          <Paragraph strong className="pt-4 px-5">
            {userInfo?.username}
          </Paragraph>
        </Link>
      )}
      <Divider />
      <div className="px-5">
        {navigationRoutes.map((route) => (
          <Paragraph strong key={route.path} onClick={() => history.push(route.path)}>
            {route.title}
          </Paragraph>
        ))}
      </div>
      <Divider />
      <div className="px-5">
        {LIST_MENU.map((route) => (
          <Paragraph strong key={route.path} onClick={() => history.push(route.path)}>
            {route.title}
          </Paragraph>
        ))}
        <Paragraph strong onClick={handleLogout}>
          Logout
        </Paragraph>
      </div>
    </Drawer>
  );
};

export default MobileModal;
