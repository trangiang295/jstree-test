import clsx from 'clsx';
import { Button } from 'components/Button';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { useWallet } from 'hooks/useWallet';
import { FC } from 'react';
import { getWalletModal, toggleWalletModal } from 'store/ducks/wallet/slice';
import { IMAGES } from 'utils/images';
import styles from './styles.module.less';

const WalletModal: FC = () => {
  const dispatch = useAppDispatch();
  const open = useAppSelector(getWalletModal);
  const { connect } = useWallet();

  const handleClose = () => {
    dispatch(toggleWalletModal());
  };

  const handleConnect = async (key: 'injected' | 'walletconnect' | 'walletlink') => {
    localStorage.clear();
    await connect(key);
  };

  return (
    <Modal
      width={440}
      visible={open}
      centered
      title="Connect a wallet"
      onCancel={handleClose}
      className={styles.walletModal}
    >
      <Button className={clsx(styles.button, 'f-between')} onClick={() => handleConnect('injected')} block>
        MetaMask <img src={IMAGES.wallet.metamask} />
      </Button>
      <Button className={clsx(styles.button, 'f-between')} onClick={() => handleConnect('walletconnect')} block>
        Wallet connect <img src={IMAGES.wallet.walletConnect} />
      </Button>
      <Button className={clsx(styles.button, 'f-between')} onClick={() => handleConnect('walletlink')} block>
        Coinbase Wallet <img src={IMAGES.wallet.coinbase} />
      </Button>
      <Button className={clsx(styles.button, 'f-between')} onClick={() => handleConnect('injected')} block>
        Trust Wallet <img src={IMAGES.wallet.trust} />
      </Button>
    </Modal>
  );
};

export default WalletModal;
