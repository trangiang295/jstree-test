import { FC, useMemo } from 'react';
import { getChainById, shortenIfAddress, useEthers } from '@usedapp/core';
import Identicon from '../Account/Identicon';

// import { walletconnect, walletlink } from '@/lib/connectors';
import { useAppDispatch, useAppSelector } from 'hooks';
import { useCopy } from 'hooks/useCopy';
import { Button } from 'components/Button';
import { CheckOutlined, CopyOutlined, GlobalOutlined, UndoOutlined } from '@ant-design/icons';
import { Typography } from 'antd';
import { getAccountModal, toggleAccountModal, toggleWalletModal } from 'store/ducks/wallet/slice';
import { Modal } from 'components/Modal';
import { Surface } from 'components/Surface';
import styles from './styles.module.less';

const AccountModal: FC = () => {
  const dispatch = useAppDispatch();
  const open = useAppSelector(getAccountModal);
  const { account, connector, chainId } = useEthers();
  const [copied, copy] = useCopy();

  const handleClose = () => {
    dispatch(toggleAccountModal());
  };

  const openWalletModal = () => {
    dispatch(toggleWalletModal());
    handleClose();
  };

  const handleCopy = () => {
    copy(account as string);
  };

  const walletType = useMemo(() => {
    // if (connector === walletconnect) return 'WalletConnect';
    // if (connector === walletlink) return 'Coinbase Wallet';
    return 'Meta mask';
  }, [connector]);

  if (!account || !chainId) return null;
  return (
    <Modal visible={open} onCancel={handleClose} title="Account" footer={null} centered width={440}>
      <Surface className={styles.surface}>
        <div className="f-between">
          <Typography className="fs-8">Connect with {walletType}</Typography>
          <Button className={styles.buttonChange} icon={<UndoOutlined />} onClick={openWalletModal}>
            Change
          </Button>
        </div>
        <div className="d-flex align-items-center">
          <Identicon />
          <Typography className="ms-2 fs-4">{shortenIfAddress(account)}</Typography>
        </div>
        <div className="d-flex mt-4">
          <Button type="link" icon={copied ? <CheckOutlined /> : <CopyOutlined />} onClick={handleCopy}>
            Copy address
          </Button>
          <Button
            type="link"
            icon={<GlobalOutlined />}
            onClick={() => window.open(getChainById(chainId)?.getExplorerAddressLink(account) || '', '_blank')}
          >
            View on Explorer
          </Button>
        </div>
      </Surface>
    </Modal>
  );
};

export default AccountModal;
