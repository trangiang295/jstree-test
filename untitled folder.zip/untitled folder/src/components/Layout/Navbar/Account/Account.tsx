import { FC, useEffect } from 'react';
import { getWalletModal, toggleWalletModal } from 'store/ducks/wallet/slice';
import { useAppDispatch, useAppSelector } from 'hooks/useRedux';
import { CURRENCY } from 'lib/config';
import { Button } from 'components/Button';
import { requestSwitchNetwork } from 'lib/requestSwitchNetwork';
import { setAuthModal } from 'store/ducks/system/slice';
import { setLoginType, setToken, setWallet } from 'store/ducks/user/slice';
import { LOCAL_STORAGE, WALLET_MESSAGE } from 'utils/constant';
import { useWallet } from 'hooks/useWallet';
import { message } from 'utils/message';
import { useMutation } from 'react-query';
import { ILoginExternalWalletRequest, loginExternalWallet, logout } from 'api/account';
import { IError } from 'api/types';
import { routesEnum } from 'pages/Routes';
import { useHistory } from 'react-router-dom';
import { useInactiveListener } from 'hooks/useEagerConnect';

const Account: FC = () => {
  const { token, loginType } = useAppSelector((state) => state.user);
  const dispatch = useAppDispatch();
  const { chainId, account, error, library } = useWallet();
  const open = useAppSelector(getWalletModal);
  const history = useHistory();

  useInactiveListener();

  const openWalletModal = () => {
    dispatch(toggleWalletModal());
  };

  const handleSwitchNetwork = async () => {
    await requestSwitchNetwork(Number(Object.keys(CURRENCY)[0]));
  };

  useEffect(() => {
    if (String(error?.name) === 'UnsupportedChainIdError' || String(error?.name) === 't') {
      if (loginType === 'wallet') {
        mutateLogout();
        return;
      }
    }
  }, [error, loginType]);

  useEffect(() => {
    if (loginType !== 'email') getSigner();
  }, [account, chainId, library, error]);

  const getSigner = async () => {
    if (library && account && chainId) {
      if (localStorage.getItem(LOCAL_STORAGE.wallet) && localStorage.getItem(LOCAL_STORAGE.wallet) !== account) {
        await mutateLogout();
      }
      let signature: any = '';
      if (!localStorage.getItem(LOCAL_STORAGE.signature)) {
        const signer = library.getSigner(account);
        signature = await signer.signMessage(WALLET_MESSAGE.message).catch((error) => {
          message.error(error.message);
        });
      }
      if (open) {
        dispatch(toggleWalletModal());
      }
      if (signature) {
        localStorage.setItem(LOCAL_STORAGE.signature, signature || '');
        loginWithExternalWallet(signature as string);
      }
    }
  };

  const { mutate: mutateLoginWithExternalWallet } = useMutation(loginExternalWallet, {
    onSuccess: (data) => {
      dispatch(setToken(data?.token));
      dispatch(setLoginType('wallet'));
      dispatch(setWallet(data?.wallet));
      localStorage.setItem(LOCAL_STORAGE.token, data?.token);
      localStorage.setItem(LOCAL_STORAGE.wallet, data?.wallet);
      localStorage.setItem(LOCAL_STORAGE.type, data?.type);
    },
    onError: () => {
      dispatch(setAuthModal('register-wallet'));
    },
  });

  const loginWithExternalWallet = (signature: string) => {
    const request: ILoginExternalWalletRequest = {
      address: account,
      signature: signature,
    };
    mutateLoginWithExternalWallet(request);
  };

  const { mutateAsync: mutateLogout } = useMutation(logout, {
    onSuccess: () => {
      localStorage.clear();
      dispatch(setToken(''));
      dispatch(setLoginType(null));
      dispatch(setWallet(''));
      history.push(routesEnum.home);
      message.info('Please check metamask to sign or chain network');
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  if (String(error?.name) === 'UnsupportedChainIdError' || String(error?.name) === 't') {
    return <Button onClick={handleSwitchNetwork}>Wrong network</Button>;
  }

  if (!token) {
    return <Button onClick={openWalletModal}>Connect wallet</Button>;
  }

  return null;

  // return (
  //   <Button className={clsx(styles.button, 'f-between')} onClick={openAccountModal}>
  //     <Space align="center">
  //       <Typography>
  //         {`${Number(formatEther(etherBalance || 0)).toFixed(2)} ${chainId ? CURRENCY[chainId] : ''}`}
  //       </Typography>
  //       <p>{account ? shortenAddress(account) : ''}</p>
  //       <Identicon />
  //     </Space>
  //   </Button>
  // );
};

export default Account;
