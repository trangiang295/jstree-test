import { routesEnum } from 'pages/Routes';

export const navigationRoutes = [
  { title: 'Marketplace', path: routesEnum.collections },
  { title: 'Brands', path: routesEnum.brands },
  { title: 'About', path: routesEnum.about },
  { title: 'FAQ', path: routesEnum.faq },
];
