import { Input as AntdInput, Layout, Space, Popover, Badge, Row } from 'antd';
import clsx from 'clsx';
import { Link, useHistory, useLocation } from 'react-router-dom';
import styles from './Desktop.module.less';
import { navigationRoutes } from './routes';
import { routesEnum } from 'pages/Routes';
import { Input } from 'components/Input';
import { Account } from './Account';
import { useAppDispatch, useAppSelector } from 'hooks';
import { setAuthModal } from 'store/ducks/system/slice';
import { getToken } from 'store/ducks/user/slice';
import { AiOutlineBell, AiOutlineUser } from 'react-icons/ai';
import { AiOutlineSearch } from 'react-icons/ai';
import { useEffect, useState } from 'react';
import { Notification } from 'components/Notification';
import { useGetListNotifications, useGetNumberNotReadNotification } from 'api/notification';
import { useAuthWebSocket } from 'hooks/useAuthWebSocket';
import { SOCKET_EVENT } from 'utils/constant';
import { Button } from 'components/Button';
import { DownOutlined, BellOutlined, SearchOutlined, UserOutlined } from '@ant-design/icons';
import { Select } from 'components/Select';
import { Menu } from './Menu';
import { Logo } from 'components/Logo';

const MENU = [
  {
    text: (
      <>
        Marketplace <DownOutlined style={{ fontSize: '10px' }} />
      </>
    ),
    type: 'text',
  },
  { text: 'About', type: 'text', link: routesEnum.about },
  { text: 'FAQs', type: 'text', link: routesEnum.faq },
];

const NavbarDesktop = () => {
  const { socket } = useAuthWebSocket();
  const history = useHistory();
  const [search, setSearch] = useState('');
  const [visible, setVisible] = useState(false);
  const [visibleMenu, setVisibleMenu] = useState(false);

  const location = useLocation();
  const { wallet, token } = useAppSelector((state) => state.user);
  const { data: notifications, refetch: refetchNotification } = useGetListNotifications(
    { page: 1, limit: 5 },
    { enabled: !!wallet }
  );

  const { data: countNotRead } = useGetNumberNotReadNotification(wallet, { enabled: !!wallet });
  const [count, setCount] = useState(0);

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (wallet && countNotRead) {
      setCount(Number(countNotRead[0].Total));
    }
  }, [wallet, countNotRead && countNotRead[0].Total]);

  useEffect(() => {
    SOCKET_EVENT.forEach((item) => {
      socket.on(item.action, () => {
        setCount((count) => count + 1);
      });
    });
  }, [socket]);

  useEffect(() => {
    setVisible(false);
  }, [countNotRead]);

  useEffect(() => {
    if (!location.pathname.startsWith('/search/nft') && !location.pathname.startsWith('/search/collection')) {
      setSearch('');
    }
    setVisible(false);
    setVisibleMenu(false);
  }, [location.pathname]);

  const handleSearch = () => {
    history.push(`/search/nft/${search}`);
  };

  const handleVisibleChange = (e: any) => {
    setVisible(e);
    if (e) {
      refetchNotification();
    }
  };

  const handleVisibleMenuChange = (e: any) => {
    setVisibleMenu(e);
  };

  return (
    <Layout.Header className={styles.root}>
      <div className={clsx('container-fluid', styles.content)}>
        <Space size={24}>
          <Logo />
          {MENU.map((item, index) => (
            <Button className={styles.buttonTabs} key={index} type={item.type as any}>
              {!item.link ? item.text : <Link to={item.link}>{item.text}</Link>}
            </Button>
          ))}
        </Space>
        <AntdInput.Group className={styles.groupInput} compact>
          <Input allowClear className={styles.input} placeholder="Search Items" prefix={<SearchOutlined />} />
          <Select placeholder="Select" className={styles.select}>
            <Select.Option value="Collections">Collections</Select.Option>
            <Select.Option value="Jiangsu">Jiangsu</Select.Option>
          </Select>
        </AntdInput.Group>
        {token ? (
          <Space>
            <Popover
              title={null}
              visible={visible}
              content={
                <Notification
                  headerClass={styles.headerNotification}
                  notifications={notifications ? notifications.list : []}
                  showTooltip
                />
              }
              overlayStyle={{ maxWidth: '350px', minWidth: '300px' }}
              trigger="click"
              onVisibleChange={handleVisibleChange}
              arrowPointAtCenter={true}
            >
              <Badge count={count}>
                <Button className={styles.circleButton} shape="circle" icon={<BellOutlined />}></Button>
              </Badge>
            </Popover>
            <Popover
              visible={visibleMenu}
              title={null}
              content={<Menu />}
              trigger="click"
              arrowPointAtCenter={true}
              onVisibleChange={handleVisibleMenuChange}
            >
              <Button className={styles.circleButton} shape="circle" icon={<UserOutlined />}></Button>
            </Popover>
            {wallet && <Button type="primary">Connect wallet</Button>}
            {!wallet && <Button type="link">My collection</Button>}
          </Space>
        ) : (
          <Space>
            <Button type="default">Login</Button>
            <Button type="primary">Sign up</Button>
          </Space>
        )}
      </div>
      <Account />
    </Layout.Header>
  );
};

export default NavbarDesktop;
