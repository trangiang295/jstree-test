import { FC, useEffect } from 'react';
import useBreakpoint from 'antd/lib/grid/hooks/useBreakpoint';
import NavbarDesktop from './Desktop';
import NavbarMobile from './Mobile';
import { setAuthModal } from 'store/ducks/system/slice';
import { useAppDispatch, useAppSelector, useGetTokenBalance, useGetTokenBalanceToken } from 'hooks';
import { CONTRACT_ADDRESS } from 'utils/constant';
import USDC from 'contracts/USDCABI.json';
import TOKEN from 'contracts/TokenABI.json';
import NFT from 'contracts/NFTABI.json';
import { setBalance } from 'store/ducks/user/slice';
import { formatUnits } from 'ethers/lib/utils';

const Navbar: FC = () => {
  const dispatch = useAppDispatch();
  const { wallet } = useAppSelector((state) => state.user);
  const balanceUsdc = useGetTokenBalanceToken(wallet || '', CONTRACT_ADDRESS.USDC, USDC);
  const balanceToken = useGetTokenBalanceToken(wallet || '', CONTRACT_ADDRESS.TOKEN, TOKEN);
  const balanceNft = useGetTokenBalanceToken(wallet || '', CONTRACT_ADDRESS.NFT, NFT);
  const balanceMatic = useGetTokenBalance(wallet || '');

  useEffect(() => {
    if (balanceUsdc && balanceToken && balanceNft && balanceMatic) {
      dispatch(
        setBalance({
          nft: formatUnits(balanceNft, 0),
          token: formatUnits(balanceToken, 18),
          usdc: formatUnits(balanceUsdc, 18),
          matic: formatUnits(balanceMatic, 18),
        })
      );
    }
  }, [balanceUsdc, balanceNft, balanceToken]);

  useEffect(() => {
    if (location.pathname === '/login') {
      dispatch(setAuthModal('login'));
    }
  }, []);

  useEffect(() => {
    const handleLogoutMultiPleTab = (e: any) => {
      if (!e.key && !e.newValue && !e.oldValue) window.location.reload();
    };
    window.addEventListener('storage', handleLogoutMultiPleTab);
    return function cleanup() {
      window.removeEventListener('storage', handleLogoutMultiPleTab);
    };
  });

  const screen = useBreakpoint();
  return <>{screen.md ? <NavbarDesktop /> : <NavbarMobile />}</>;
};

export default Navbar;
