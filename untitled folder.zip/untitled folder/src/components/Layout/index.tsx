import { FC } from 'react';
import styles from './Layout.module.less';
import { Layout as AntdLayout } from 'antd';
import { Footer } from './Footer';
import { ConfigProvider as AntdConfigProvider } from 'antd';
import clsx from 'clsx';
import Navbar from './Navbar';
import { AuthModal } from 'components/AuthModal';
import { AccountModal, WalletModal } from './Navbar/Modal';
import { formConfig } from 'utils/form';
import { NFTModal } from 'components/NFTModal';
import { IoProvider } from 'socket.io-react-hook';

export const Layout: FC = ({ children }) => {
  return (
    <AntdConfigProvider form={{ ...formConfig }}>
      <AntdLayout className={clsx(styles.root)}>
        <IoProvider>
          <WalletModal />
          <AccountModal />
          <Navbar />
          <main>{children}</main>
          <Footer />
          <AuthModal />
          <NFTModal />
        </IoProvider>
      </AntdLayout>
    </AntdConfigProvider>
  );
};
