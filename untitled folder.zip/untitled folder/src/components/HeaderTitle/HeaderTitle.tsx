import { Divider, Typography } from 'antd';
import clsx from 'clsx';
import { FC } from 'react';
import styles from './HeaderTitle.module.less';

const { Title } = Typography;

interface TitleProps {
  title?: string;
  description?: string;
  className?: string;
  notShowDivider?: boolean;
}

export const HeaderTitle: FC<TitleProps> = ({ className, title, description, notShowDivider }) => {
  return (
    <div className={clsx(styles.root, className, 'container')}>
      {!notShowDivider && <Divider>***</Divider>}
      <Title className={clsx('mb-0 fw-bold', styles.title)} level={1}>
        {title}
      </Title>
      {description && (
        <Title className="my-1 mb-4 fw-bold w-50" level={4}>
          {description}
        </Title>
      )}
    </div>
  );
};
