import { Col, Row, Typography } from 'antd';
import { FC } from 'react';
import styles from './AboutInfo.module.less';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { useHistory, useLocation } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';

const { Title, Paragraph } = Typography;

export const AboutInfo: FC<{ item: any; index: number; showBtn?: boolean; imageUrl?: any }> = ({
  item,
  index,
  showBtn,
  imageUrl,
}) => {
  const history = useHistory();
  const { pathname } = useLocation<{ pathname: string }>();

  return (
    <Row className={clsx(styles.root, index % 2 !== 0 ? styles.rootReverse : '')}>
      <Col xl={12} className="mx-auto">
        <img src={imageUrl} alt="img" />
      </Col>
      <Col xl={12} className="my-auto px-lg-5">
        <Title className="text-center"> {item.title || item.brandName}</Title>
        <Paragraph className={pathname === routesEnum.brands ? 'text-center' : ''}>
          {item.des || item.description}
        </Paragraph>
        {showBtn && (
          <div className="text-center">
            <Button onClick={() => history.push(`${routesEnum.brandDetail}/${item.id}`)}>SEE MORE</Button>
          </div>
        )}
      </Col>
    </Row>
  );
};
