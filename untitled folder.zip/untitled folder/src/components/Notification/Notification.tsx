import { Descriptions, List, message, Tooltip } from 'antd';
import { IError } from 'api/types';
import { routesEnum } from 'pages/Routes';
import { FC } from 'react';
import { useMutation } from 'react-query';
import { useHistory } from 'react-router-dom';
import { getNotificationMessage } from 'utils/common';
import { convertNotification } from 'utils/notification';
import styles from './Notification.module.less';
import { updateIsRead, useGetNumberNotReadNotification } from 'api/notification';
import clsx from 'clsx';
import { useAppSelector } from 'hooks';

export const Notification: FC<{ headerClass?: string; hidden?: any; notifications: any; showTooltip?: any }> = ({
  headerClass,
  hidden,
  notifications,
  showTooltip,
}) => {
  const { wallet } = useAppSelector((state) => state.user);
  const history = useHistory();
  const { refetch } = useGetNumberNotReadNotification(wallet);

  const handleClick = (item: any) => {
    mutateUpdateIsRead({ id: item.id });
    if (item.type !== 0) {
      history.push(`/nft-detail/${item.nft_id}`);
    }
  };

  const { mutate: mutateUpdateIsRead } = useMutation(updateIsRead, {
    onSuccess: () => {
      refetch();
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  return (
    <div className={styles.root}>
      <List
        size="small"
        header={<div className={headerClass}>Recently Received Notifications</div>}
        footer={
          hidden?.footer ? null : (
            <div className={styles.textViewAll} onClick={() => history.push(routesEnum.listNotification)}>
              View all
            </div>
          )
        }
        dataSource={notifications}
        renderItem={(item: any) => {
          if (showTooltip)
            return (
              <Tooltip placement="bottom" title={getNotificationMessage(item)}>
                <List.Item onClick={() => handleClick(item)}>
                  <Descriptions layout="vertical">
                    <Descriptions.Item
                      label={convertNotification(item.type, item)}
                      className={clsx(
                        styles.des,
                        showTooltip ? styles.showTooltip : '',
                        item?.is_read === 1 ? styles.isRead : ''
                      )}
                    >
                      {getNotificationMessage(item)}
                    </Descriptions.Item>
                  </Descriptions>
                </List.Item>
              </Tooltip>
            );
          else {
            return (
              <List.Item onClick={() => handleClick(item)}>
                <Descriptions layout="vertical">
                  <Descriptions.Item
                    label={convertNotification(item.type, item)}
                    className={clsx(styles.des, item?.is_read === 1 ? styles.isRead : '')}
                  >
                    {getNotificationMessage(item)}
                  </Descriptions.Item>
                </Descriptions>
              </List.Item>
            );
          }
        }}
      />
    </div>
  );
};
