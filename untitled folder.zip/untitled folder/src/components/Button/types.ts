import React, { CSSProperties, MouseEvent } from 'react';

export interface ButtonProps {
  type?: "primary" | "default" | "link" | "dashed" | "text" | "ghost" | undefined
  size?: 'large' | 'middle' | 'small';
  shape?: 'circle' | 'round';
  onClick?(event?: MouseEvent): void;
  className?: string;
  htmlType?: 'submit' | 'button' | 'reset';
  icon?: React.ReactNode;
  disabled?: boolean;
  loading?: boolean;
  block?: boolean;
  id?: any;
  href?: string;
  style?: CSSProperties
}
