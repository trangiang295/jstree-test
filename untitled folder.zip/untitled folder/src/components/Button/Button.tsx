import { Button as ButtonAntd } from 'antd';
import clsx from 'clsx';
import { forwardRef, PropsWithChildren } from 'react';
import styles from './Button.module.less';
import { ButtonProps } from './types';

export const Button = forwardRef<HTMLElement, PropsWithChildren<ButtonProps>>(function Button(
  {
    style,
    children,
    id,
    block,
    type,
    size = 'middle',
    htmlType = 'button',
    className,
    disabled,
    loading,
    onClick,
    icon,
    ...props
  },
  ref
) {
  return (
    <ButtonAntd
      id={id}
      htmlType={htmlType}
      className={clsx(styles.root, styles[size], className)}
      type={type}
      ref={ref}
      onClick={onClick}
      disabled={disabled}
      loading={loading}
      block={block}
      icon={icon}
      style={style}
      {...props}
    >
      {children}
    </ButtonAntd>
  );
});
