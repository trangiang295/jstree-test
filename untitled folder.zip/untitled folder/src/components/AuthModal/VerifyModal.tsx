import { FC, useEffect, useMemo, useState } from 'react';
import styles from './styles.module.less';
import { Form, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { Input } from 'components/Input';
import { message } from 'utils/message';
import { getWithDrawRequest, setWithDrawRequest } from 'store/ducks/nft/slice';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';
import { useContractProvider } from 'hooks/useContract';
import { useGetUserInfo } from 'api/account';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';
import { CONTRACT_ADDRESS } from 'utils/constant';
import { getBalance } from 'store/ducks/user/slice';
import { getStatusPrice } from 'utils/common';

const { Title } = Typography;

export const VerifyModal: FC = () => {
  const state = useAppSelector(getAuthModal);
  const visible = useMemo(() => state === 'verify', [state]);
  const [form] = Form.useForm();
  const dispatch = useAppDispatch();
  const withDrawRequest = useAppSelector(getWithDrawRequest);
  const [txid, setTxid] = useState('');
  const { data: userInfo } = useGetUserInfo();
  const balance = useAppSelector(getBalance);

  const loadingGetTransaction = useContractProvider(txid);

  useEffect(() => {
    form.resetFields();
    setTxid('');
    reset();
  }, [visible]);

  const handleClose = () => {
    dispatch(setAuthModal(null));
  };

  const onFinish = (value: any) => {
    const request: IWalletSystemRequest = { ...value, ...withDrawRequest };
    const token = withDrawRequest.data[0] === CONTRACT_ADDRESS.TOKEN ? 'DMT' : 'USDC';

    if (!getStatusPrice(token === 'DMT' ? balance.token : balance.usdc, withDrawRequest.price)) {
      message.info(`Lack of ${token}`);
      return;
    }
    delete request.price;
    mutatePostWalletSystem(request);
  };

  const {
    mutate: mutatePostWalletSystem,
    status,
    reset,
  } = useMutation(postMethod, {
    onSuccess: (data) => {
      if (data?.status !== 'failed') {
        setTxid(data?.txid);
        dispatch(setWithDrawRequest({}));
      } else {
        message.error('Invalid');
      }
    },

    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  useEffect(() => {
    if (status === 'success' && !loadingGetTransaction) {
      dispatch(setWithDrawRequest({}));
      dispatch(setAuthModal(null));
      message.success('Successfully');
      window.location.reload();
    }
  }, [status, loadingGetTransaction]);

  return (
    <Modal visible={visible} onCancel={handleClose} width={400}>
      <div className={clsx(styles.root)}>
        <Title level={3} className="text-center">
          VERIFY
        </Title>
        <Form layout="vertical" onFinish={onFinish} form={form} validateTrigger="onBlur">
          {userInfo?.isActive2fa === 1 && (
            <Form.Item label="2FA" name="twofa" rules={[{ required: true }]}>
              <Input placeholder={'Enter your 2FA code'} />
            </Form.Item>
          )}
          {userInfo?.isActiveEmailCode === 1 && (
            <Form.Item label="Email Code" name="emailCode" rules={[{ required: true }]}>
              <Input placeholder={'Enter your email code'} />
            </Form.Item>
          )}
          <Form.Item>
            <Button
              loading={(txid !== '' && loadingGetTransaction) || status === 'loading'}
              className="w-100"
              htmlType="submit"
            >
              Verify
            </Button>
          </Form.Item>
        </Form>
      </div>
    </Modal>
  );
};
