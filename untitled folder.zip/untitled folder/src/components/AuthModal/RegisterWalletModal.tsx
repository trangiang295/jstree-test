import { FC, useEffect, useMemo, useState } from 'react';
import styles from './styles.module.less';
import { Form, Checkbox, Space, Divider } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';
import { useMutation } from 'react-query';
import {
  registerUserExternalWallet,
  IRegisterExternalWalletRequest,
  ILoginExternalWalletRequest,
  loginExternalWallet,
} from 'api/account';
import { IError } from 'api/types';
import { useEthers } from '@usedapp/core';
import { LOCAL_STORAGE } from 'utils/constant';
import { Input } from 'components/Input';
import { setToken, setWallet } from 'store/ducks/user/slice';
import { message } from 'utils/message';

export const RegisterWalletModal: FC = () => {
  const state = useAppSelector(getAuthModal);
  const [form] = Form.useForm();
  const dispatch = useAppDispatch();
  const { account, deactivate } = useEthers();

  const [agreeTerms, setAgreeTerms] = useState<boolean>(false);

  const visible = useMemo(() => state === 'register-wallet', [state]);

  useEffect(() => {
    setAgreeTerms(false);
    form.resetFields();
  }, [visible]);

  const handleClose = () => {
    localStorage.clear();
    deactivate();
    dispatch(setAuthModal(null));
  };

  const { mutate: mutateRegisterWallet, status } = useMutation(registerUserExternalWallet, {
    onSuccess: () => {
      message.success('Register successfully');
      dispatch(setAuthModal(null));
      loginWallet();
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const { mutate: mutateLoginWallet } = useMutation(loginExternalWallet, {
    onSuccess: (data) => {
      dispatch(setToken(data?.token));
      dispatch(setWallet(data?.wallet));
      localStorage.setItem(LOCAL_STORAGE.token, data?.token);
      localStorage.setItem(LOCAL_STORAGE.wallet, data?.wallet);
    },
    onError: (error: IError) => {
      dispatch(setAuthModal('register-wallet'));
      message.error(error.meta.message);
    },
  });

  const onRegisterWallet = (value: any) => {
    const registerRequest: IRegisterExternalWalletRequest = {
      ...value,
      address: account,
      signature: localStorage.getItem(LOCAL_STORAGE.signature),
    };
    mutateRegisterWallet(registerRequest);
  };

  const loginWallet = () => {
    const loginWalletRequest: ILoginExternalWalletRequest = {
      address: account,
      signature: localStorage.getItem(LOCAL_STORAGE.signature),
    };
    mutateLoginWallet(loginWalletRequest);
  };

  return (
    <Modal visible={visible} onCancel={handleClose}>
      <div className={styles.root}>
        <Space className={clsx(styles.topTitle, 'f-between flex-md-row flex-column')}>
          <div>
            <strong>Register your wallet</strong>
          </div>
        </Space>
        <div className="text-center">
          <Divider className="my-3" />
          <div>Your account will be associated with wallet address:</div>
          <strong>{account}</strong>
          <Divider className="my-3" />
        </div>
        <Form layout="vertical" onFinish={onRegisterWallet} form={form} validateTrigger="onBlur">
          <Form.Item label="Email" name="email" rules={[{ required: true }, { type: 'email' }]}>
            <Input placeholder="Enter your email" />
          </Form.Item>
          <Form.Item label="Username" name="username" rules={[{ required: true }]}>
            <Input placeholder="Username" />
          </Form.Item>
          <Checkbox
            className={clsx(styles.textTermPolicy, 'd-flex align-items-center mb-3')}
            checked={agreeTerms}
            onChange={(e) => setAgreeTerms(e.target.checked)}
          >
            By creating an account you agree to the Terms of Service and Privacy Policy
          </Checkbox>
          <Form.Item>
            <Button loading={status === 'loading'} className="w-100" htmlType="submit" disabled={!agreeTerms}>
              REGISTER WALLET
            </Button>
          </Form.Item>
        </Form>
      </div>
    </Modal>
  );
};
