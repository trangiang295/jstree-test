import { FC, useEffect, useMemo } from 'react';
import styles from './styles.module.less';
import { Form } from 'antd';
import clsx from 'clsx';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';
import { Button } from 'components/Button';
import { resendEmail, IResendEmailRequest } from 'api/account';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { Input } from 'components/Input';
import { message } from 'utils/message';

export const ResendEmailActive: FC = () => {
  const state = useAppSelector(getAuthModal);
  const [form] = Form.useForm();
  const dispatch = useAppDispatch();

  const visible = useMemo(() => state === 'resend-active', [state]);

  useEffect(() => {
    form.resetFields();
  }, [visible]);

  const handleClose = () => {
    dispatch(setAuthModal(null));
  };

  const { mutate: mutateResendEmail, status: statusResentEmail } = useMutation(resendEmail, {
    onSuccess: () => {
      message.success('Resend email successfully');
      dispatch(setAuthModal(null));
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const onResendEmailActive = (value: any) => {
    const resendEmailRequest: IResendEmailRequest = {
      email: value.email,
    };
    mutateResendEmail(resendEmailRequest);
  };

  return (
    <Modal visible={visible} onCancel={handleClose}>
      <div className={clsx(styles.root)}>
        <h2>
          <strong>Resend email active</strong>
        </h2>
        <Form layout="vertical" onFinish={onResendEmailActive} form={form} validateTrigger="onBlur">
          <p>Enter your username or email address and we will send you a link to active email.</p>
          <Form.Item label="Email" name="email" rules={[{ required: true }, { type: 'email' }]}>
            <Input placeholder="Enter your email" />
          </Form.Item>
          <Form.Item>
            <Button loading={statusResentEmail === 'loading'} className="w-100" htmlType="submit">
              Resend Active Email
            </Button>
          </Form.Item>
        </Form>
        <p className="mt-3 text-center mb-0 pointer" onClick={() => dispatch(setAuthModal('register'))}>
          <strong>Back</strong>
        </p>
      </div>
    </Modal>
  );
};
