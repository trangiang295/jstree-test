import { FC, useEffect, useMemo } from 'react';
import styles from './styles.module.less';
import { Form, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';
import { getLoginRequest, setLoginRequest, setLoginType, setToken, setWallet } from 'store/ducks/user/slice';
import { login, ILoginRequest } from 'api/account';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { LOCAL_STORAGE } from 'utils/constant';
import { Input } from 'components/Input';
import { message } from 'utils/message';

const { Title } = Typography;

export const Verify2FAModal: FC = () => {
  const state = useAppSelector(getAuthModal);
  const [form] = Form.useForm();
  const dispatch = useAppDispatch();
  const loginRequest = useAppSelector(getLoginRequest);

  const visible = useMemo(() => state === '2fa', [state]);

  const { mutate: mutateLogin, status } = useMutation(login, {
    onSuccess: (data) => {
      dispatch(setAuthModal(null));
      dispatch(setToken(data?.token));
      dispatch(setWallet(data?.wallet));
      dispatch(setLoginType('email'));
      dispatch(setLoginRequest({}));
      localStorage.setItem(LOCAL_STORAGE.token, data?.token);
      localStorage.setItem(LOCAL_STORAGE.wallet, data?.wallet);
      localStorage.setItem(LOCAL_STORAGE.type, data?.type);
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  useEffect(() => {
    form.resetFields();
  }, [visible]);

  const handleClose = () => {
    dispatch(setAuthModal(null));
  };

  const onLogin = (value: any) => {
    const request: ILoginRequest = { ...value, ...loginRequest };
    mutateLogin(request);
  };

  return (
    <Modal visible={visible} onCancel={handleClose} width={400}>
      <div className={clsx(styles.root)}>
        <Title level={3} className="text-center">
          VERIFY 2FA
        </Title>
        <Form layout="vertical" onFinish={onLogin} form={form} validateTrigger="onBlur">
          <Form.Item label="2FA" name="twofa" rules={[{ required: true }]}>
            <Input placeholder={'Enter your 2FA code'} />
          </Form.Item>
          <Form.Item>
            <Button loading={status === 'loading'} className="w-100" htmlType="submit">
              Verify
            </Button>
          </Form.Item>
        </Form>
      </div>
    </Modal>
  );
};
