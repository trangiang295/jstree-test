import { FC, useEffect, useMemo } from 'react';
import styles from './styles.module.less';
import { Form, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';
import { getLoginRequest, setLoginRequest, setLoginType, setToken, setWallet } from 'store/ducks/user/slice';
import { login, ILoginRequest, checkActiveSecurity } from 'api/account';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { LOCAL_STORAGE } from 'utils/constant';
import { Input, InputPassword } from 'components/Input';
import { message } from 'utils/message';
import { Logo } from 'components/Logo';

const { Title } = Typography;

export const LoginModal: FC = () => {
  const state = useAppSelector(getAuthModal);
  const loginRequest = useAppSelector(getLoginRequest);
  const [form] = Form.useForm();
  const dispatch = useAppDispatch();

  const visible = useMemo(() => state === 'login', [state]);

  const { mutate: mutateLogin, status } = useMutation(login, {
    onSuccess: (data) => {
      dispatch(setAuthModal(null));
      dispatch(setToken(data?.token));
      dispatch(setWallet(data?.wallet));
      dispatch(setLoginType('email'));
      localStorage.setItem(LOCAL_STORAGE.token, data?.token);
      localStorage.setItem(LOCAL_STORAGE.wallet, data?.wallet);
      localStorage.setItem(LOCAL_STORAGE.type, data?.type);
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const { mutate: mutateCheckActiveSecurity } = useMutation(checkActiveSecurity, {
    onSuccess: (data) => {
      if (!data.isActiveEmailCode && !data.isActive2fa) {
        mutateLogin(loginRequest);
      } else {
        if (data.isActive2fa) {
          dispatch(setAuthModal('2fa'));
        } else {
          dispatch(setAuthModal('email-code'));
        }
      }
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  useEffect(() => {
    form.resetFields();
  }, [visible]);

  const handleClose = () => {
    dispatch(setAuthModal(null));
  };

  const onLogin = (value: any) => {
    const loginRequest: ILoginRequest = { ...value };
    dispatch(setLoginRequest({ ...value }));
    mutateCheckActiveSecurity(loginRequest);
  };

  return (
    <Modal visible={visible} onCancel={handleClose}>
      <div className={clsx(styles.root, styles.login)}>
        <div className={styles.loginHeader}>
          <Logo />
          <Title level={3} className={styles.title}>
            Login to Verdant
          </Title>
        </div>
        <Form layout="vertical" onFinish={onLogin} form={form} validateTrigger="onBlur" autoComplete="1">
          <Form.Item label="Email" name="email" rules={[{ required: true }, { type: 'email' }]}>
            <Input placeholder={'Enter your email'} />
          </Form.Item>
          <Form.Item
            label="Password"
            name="password"
            rules={[{ required: true }, { type: 'string', min: 6 }, { type: 'string', max: 20 }]}
            style={{ marginBottom: 20 }}
          >
            <InputPassword placeholder="Password" />
          </Form.Item>
          <div style={{ textAlign: 'right' }}>
            <Button style={{ padding: '0' }} type="link" onClick={() => dispatch(setAuthModal('forgot'))}>
              Forget password
            </Button>
          </div>
          <Form.Item>
            <Button type="primary" loading={status === 'loading'} className="w-100" htmlType="submit">
              Login
            </Button>
          </Form.Item>
        </Form>
        <div className="f-center">
          Not a member?{' '}
          <Button onClick={() => dispatch(setAuthModal('register'))} style={{ padding: '0' }} type="link">
            Sign up
          </Button>{' '}
          now
        </div>
      </div>
    </Modal>
  );
};
