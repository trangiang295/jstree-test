import { FC, useEffect, useMemo } from 'react';
import styles from './styles.module.less';
import { Form, Typography } from 'antd';
import clsx from 'clsx';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';
import { Button } from 'components/Button';
import { sendEmailResetPassword, IResendEmailRequest } from 'api/account';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { Input } from 'components/Input';
import { message } from 'utils/message';
import { Logo } from 'components/Logo';

const { Title } = Typography;

export const ForgotPasswordModal: FC = () => {
  const state = useAppSelector(getAuthModal);
  const [form] = Form.useForm();
  const dispatch = useAppDispatch();

  const visible = useMemo(() => state === 'forgot', [state]);

  const { mutate: mutateSendEmailResetPassword, status } = useMutation(sendEmailResetPassword, {
    onSuccess: () => {
      dispatch(setAuthModal(null));
      message.success('Send email reset password successfully');
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  useEffect(() => {
    form.resetFields();
  }, [visible]);

  const handleClose = () => {
    dispatch(setAuthModal(null));
  };

  const onForgotPassword = (value: any) => {
    const resendEmailRequest: IResendEmailRequest = {
      email: value.email,
    };
    mutateSendEmailResetPassword(resendEmailRequest);
  };

  return (
    <Modal visible={visible} onCancel={handleClose}>
      <div className={clsx(styles.root)}>
        <div className={styles.loginHeader}>
          <Logo />
          <Title level={3} className={styles.title}>
            Reset Password
          </Title>
        </div>
        <Form layout="vertical" onFinish={onForgotPassword} form={form} validateTrigger="onBlur">
          <p>Enter your username or email address and we will send you a link to reset your password.</p>
          <Form.Item label="Email" name="email" rules={[{ required: true }, { type: 'email' }]}>
            <Input placeholder="Enter your email" />
          </Form.Item>
          <Form.Item>
            <Button loading={status === 'loading'} className="w-100" htmlType="submit">
              FORGOT PASSWORD
            </Button>
          </Form.Item>
        </Form>
        <p className="mt-3 text-center mb-0">
          <strong className="pointer" onClick={() => dispatch(setAuthModal('login'))}>
            Back
          </strong>
        </p>
      </div>
    </Modal>
  );
};
