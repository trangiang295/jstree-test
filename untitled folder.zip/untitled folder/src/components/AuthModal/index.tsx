import { FC } from 'react';
import { ForgotPasswordModal } from './ForgotPasswordModal';
import { LoginModal } from './LoginModal';
import { RegisterModal } from './RegisterModal';
import { ResendEmailActive } from './ResendEmailActive';
import { RegisterWalletModal } from './RegisterWalletModal';
import { Verify2FAModal } from './Verify2FAModal';
import { EmailCodeModal } from './EmailCodeModal';
import { VerifyModal } from './VerifyModal';

export const AuthModal: FC = () => {
  return (
    <>
      <LoginModal />
      <RegisterModal />
      <ForgotPasswordModal />
      <ResendEmailActive />
      <RegisterWalletModal />
      <Verify2FAModal />
      <EmailCodeModal />
      <VerifyModal />
    </>
  );
};
