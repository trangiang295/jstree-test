import { FC, useEffect, useMemo, useState } from 'react';
import styles from './styles.module.less';
import { Form, Space } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';
import { useMutation } from 'react-query';
import { register, IRegisterRequest } from 'api/account';
import { IError } from 'api/types';
import { Input, InputPassword } from 'components/Input';
import { Checkbox } from 'components/Checkbox';
import { message } from 'utils/message';

export const RegisterModal: FC = () => {
  const state = useAppSelector(getAuthModal);
  const [form] = Form.useForm();
  const dispatch = useAppDispatch();

  const [agreeTerms, setAgreeTerms] = useState<boolean>(false);

  const visible = useMemo(() => state === 'register', [state]);

  const { mutate: mutateRegister, status } = useMutation(register, {
    onSuccess: () => {
      message.success('Register successfully. Please check your email to active account.');
      dispatch(setAuthModal(null));
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  useEffect(() => {
    setAgreeTerms(false);
    form.resetFields();
  }, [visible]);

  const handleClose = () => {
    dispatch(setAuthModal(null));
  };

  const onRegister = (value: any) => {
    const registerRequest: IRegisterRequest = {
      email: value.email,
      password: value.password,
    };
    mutateRegister(registerRequest);
  };

  return (
    <Modal visible={visible} onCancel={handleClose}>
      <div className={clsx(styles.root)}>
        <Space className={clsx(styles.topTitle, 'mb-3 f-between flex-md-row flex-column')}>
          <div>
            <strong>Register your account</strong>
          </div>
          <div>
            Are you a member?
            <span className="pointer" onClick={() => dispatch(setAuthModal('login'))}>
              <strong> Login now</strong>
            </span>
          </div>
        </Space>
        <Form layout="vertical" onFinish={onRegister} form={form} validateTrigger="onBlur">
          <Form.Item label="Email" name="email" rules={[{ required: true }, { type: 'email' }]}>
            <Input placeholder="Enter your email" />
          </Form.Item>
          <Form.Item
            label="Password"
            name="password"
            rules={[{ required: true }, { type: 'string', min: 6 }, { type: 'string', max: 20 }]}
          >
            <InputPassword placeholder="Password" />
          </Form.Item>
          <Form.Item
            label="Confirm Password"
            name="confirmPassword"
            dependencies={['password']}
            rules={[
              { required: true },
              ({ getFieldValue }) => ({
                validator(_, value) {
                  if (!value || getFieldValue('password') === value) {
                    return Promise.resolve();
                  }
                  return Promise.reject(new Error('Confirm password do not match!'));
                },
              }),
            ]}
          >
            <InputPassword placeholder="Confirm Password" />
          </Form.Item>
          <Checkbox
            checked={agreeTerms}
            onChange={(e) => setAgreeTerms(e.target.checked)}
            className={clsx(styles.textTermPolicy, 'd-flex align-items-center mb-3')}
          >
            By creating an account you agree to the Terms of Service and Privacy Policy
          </Checkbox>
          <Form.Item>
            <Button loading={status === 'loading'} className="w-100" htmlType="submit" disabled={!agreeTerms}>
              SIGN UP
            </Button>
          </Form.Item>
        </Form>
        <div className="f-center">
          <a type="link" onClick={() => dispatch(setAuthModal('resend-active'))}>
            <strong>Resend active email</strong>
          </a>
        </div>
      </div>
    </Modal>
  );
};
