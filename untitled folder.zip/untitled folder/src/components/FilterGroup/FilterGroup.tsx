import { FC, CSSProperties } from 'react';
import styles from './styles.module.css';
import { Radio, RadioGroupProps, Space } from 'antd';
import clsx from 'clsx';

export interface filterValue {
  value?: any;
  label?: any;
  className?: any;
  disabled?: boolean;
  [key: string]: any;
}

type FilterGroupProps = Partial<RadioGroupProps> & {
  data: filterValue[];
  filled?: boolean;
  className?: string;
  strectch?: boolean;
  style?: CSSProperties;
};

export const FilterGroup: FC<FilterGroupProps> = ({ strectch = false, data, filled, className, style, ...props }) => {
  return (
    <Space
      className={clsx(styles.root, className, {
        [styles.stretchItem]: strectch,
        [styles.filled]: filled,
      })}
      style={style}
    >
      <Radio.Group
        className={clsx(styles.filterWrapper, {
          [styles.stretch]: strectch,
        })}
        buttonStyle="solid"
        {...props}
      >
        {data.map((item) => (
          <Radio.Button
            key={item.value}
            className={clsx(styles.filterItem, item?.className ?? undefined)}
            value={item.value}
            id={`radio-${item.value}`}
            disabled={item.disabled}
          >
            {item.label}
          </Radio.Button>
        ))}
      </Radio.Group>
    </Space>
  );
};
