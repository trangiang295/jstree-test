import { Slider as AntdSlider } from 'antd';
import clsx from 'clsx';
import { memo } from 'react';
import styles from './styles.module.less';

interface SliderProps {
  value?: [number, number] | undefined;
  handleChange?: (value: [number, number]) => void;
  maxValue?: number;
  disabled?: boolean;
  handle?: 'yellow' | 'black';
  step?: number;
}

// eslint-disable-next-line react/display-name
export const SliderRange = memo(({ value, handleChange, maxValue, disabled, handle = 'yellow', step }: SliderProps) => {
  const marks = {
    0: 0,
    25: 1,
    50: 2,
    75: 3,
    100: 4,
  };

  return (
    <div className={clsx(styles.slider, styles[handle])}>
      <AntdSlider
        range
        disabled={disabled}
        marks={marks}
        value={value}
        onChange={(e: [number, number]) => {
          if (handleChange) handleChange(e);
        }}
        max={maxValue}
        step={step}
      />
    </div>
  );
});
