import { Slider as AntdSlider } from 'antd';
import clsx from 'clsx';
import { memo } from 'react';
import styles from './styles.module.less';

interface SliderProps {
  value?: number | undefined;
  handleChange?: (value: number) => void;
  maxValue?: number;
  disabled?: boolean;
  handle?: 'yellow' | 'black';
}

// eslint-disable-next-line react/display-name
export const Slider = memo(({ value, handleChange, maxValue, disabled, handle = 'yellow' }: SliderProps) => {
  const marks = {
    0: 0,
    25: 1,
    50: 2,
    75: 3,
    100: 4,
  };

  return (
    <div className={clsx(styles.slider, styles[handle])}>
      <AntdSlider
        disabled={disabled}
        marks={marks}
        value={value}
        onChange={(e: number) => {
          if (handleChange) handleChange((e / 100) * (maxValue || 0));
        }}
        range={false}
        max={100}
        tipFormatter={(value: number | undefined) => {
          return `${value}%`;
        }}
      />
    </div>
  );
});
