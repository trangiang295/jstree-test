import { FC, useMemo, useEffect } from 'react';
import styles from './CheckDataNFTModal.module.less';
import { Typography } from 'antd';
import clsx from 'clsx';
import { Modal } from 'components/Modal';
import { Button } from 'components/Button';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { useContractFunction, useEthers } from '@usedapp/core';
import { useConnectABI } from 'hooks/useConnectABI';
import { CONTRACT_ADDRESS } from 'utils/constant';
import NFTABI from 'contracts/NFTABI.json';
import { useAppDispatch, useAppSelector } from 'hooks';
import { getNFT, setNFTModal } from 'store/ducks/nft/slice';
import { useHistory } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';
import { message } from 'utils/message';
import { checkLogin, getLoadingBtn } from 'utils/common';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';

const { Title, Paragraph } = Typography;

export const DeployNFTModal: FC = () => {
  const dispatch = useAppDispatch();
  const { wallet, loginType } = useAppSelector((state) => state.user);
  const { nftModal: state, dataMint } = useAppSelector(getNFT);
  const visible = useMemo(() => state === 'deploy-nft', [state]);
  const { active } = useEthers();
  const history = useHistory();

  useEffect(() => {
    if (dataMint) {
      handleMint();
    }
  }, [loginType]);

  const { state: statusMint, send: sendSafeMint } = useContractFunction(
    useConnectABI(NFTABI, CONTRACT_ADDRESS.NFT),
    'safeMint',
    {
      transactionName: 'wrap',
    }
  );

  const handleClose = () => {
    dispatch(setNFTModal(null));
    history.push(routesEnum.listNft);
  };

  const handleMint = () => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }
    if (loginType === 'email') {
      const request: IWalletSystemRequest = {
        method: 'safeMint',
        currency: 'polygon',
        data: [
          Array(parseInt(dataMint.quantity)).fill(wallet),
          Array(parseInt(dataMint.quantity)).fill(dataMint.url_ipfs.toString()),
        ],
      };
      mutatePostWalletSystem(request);
    } else if (loginType === 'wallet') {
      sendSafeMint(
        Array(parseInt(dataMint.quantity)).fill(wallet),
        Array(parseInt(dataMint.quantity)).fill(dataMint.url_ipfs.toString())
      );
    }
  };

  const { mutate: mutatePostWalletSystem, status: statusPostWalletSystem } = useMutation(postMethod, {
    onSuccess: () => {
      message.success('Mint NFT successfully');
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const getLoadingMint = () => {
    if (loginType === 'email') {
      return statusPostWalletSystem === 'loading';
    }
    return getLoadingBtn(statusMint);
  };

  useEffect(() => {
    if (statusMint.status === 'Success' || statusPostWalletSystem === 'success') {
      handleClose();
    }
  }, [statusMint, statusPostWalletSystem]);

  return (
    <Modal visible={visible} onCancel={handleClose} width={400}>
      <div className={styles.root}>
        <Title level={2} className={clsx(styles.title, 'text-center')}>
          MINT NFT
        </Title>
        <Title level={4} className="mb-0">
          <strong>Mint</strong>
        </Title>
        <Paragraph>Send transaction to complete create your NFT</Paragraph>
        <Button
          loading={getLoadingMint()}
          className="w-100 mb-4"
          onClick={handleMint}
          disabled={statusMint.status === 'Success' || statusPostWalletSystem === 'success'}
        >
          {statusMint.status === 'Success' || statusPostWalletSystem === 'success'
            ? 'Done'
            : getLoadingMint()
            ? 'Inprogress'
            : 'Start'}
        </Button>
      </div>
    </Modal>
  );
};
