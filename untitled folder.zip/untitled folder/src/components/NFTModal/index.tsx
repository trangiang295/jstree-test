import { FC } from 'react';
import { DeployNFTModal } from './DeployNFTModal';
import { ConfirmFeeModal } from './ConfirmFeeModal';
import { useAppSelector } from 'hooks';
import { getNFTModal } from 'store/ducks/nft/slice';

export const NFTModal: FC = () => {
  const state = useAppSelector(getNFTModal);

  return (
    <>
      {state === 'deploy-nft' && <DeployNFTModal />}
      <ConfirmFeeModal />
    </>
  );
};
