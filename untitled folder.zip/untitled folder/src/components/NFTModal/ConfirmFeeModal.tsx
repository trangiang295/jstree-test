import { FC, useMemo } from 'react';
import styles from './CheckDataNFTModal.module.less';
import { Typography } from 'antd';
import clsx from 'clsx';
import { Modal } from 'components/Modal';
import { Button } from 'components/Button';
import { IMAGES } from 'utils/images';
import { useAppDispatch, useAppSelector } from 'hooks';
import { getNFT, setNFTModal } from 'store/ducks/nft/slice';

const { Title, Paragraph } = Typography;

export const ConfirmFeeModal: FC = () => {
  const dispatch = useAppDispatch();
  const { nftModal: state } = useAppSelector(getNFT);
  const visible = useMemo(() => state === 'update-nft', [state]);

  const handleClose = () => {
    dispatch(setNFTModal(null));
  };

  return (
    <Modal visible={visible} onCancel={handleClose}>
      <div className={clsx(styles.root)}>
        <Title level={2} className={clsx(styles.title, 'text-center')}>
          Confirm fee change price
        </Title>
        <div className="text-center">
          <img src={IMAGES.nft.confirmfee} alt="confirm-fee" />
        </div>
        <Paragraph className="w-75 text-center mx-auto my-4">
          You will be fee-gas 0.5 EHT to change the price for this product
        </Paragraph>
        <div className="w-75 mx-auto">
          <Button className="w-100 mb-4" onClick={handleClose}>
            Cancel
          </Button>
        </div>
        <div className="w-75 mx-auto">
          <Button className="w-100 mb-4">Confirm</Button>
        </div>
      </div>
    </Modal>
  );
};
