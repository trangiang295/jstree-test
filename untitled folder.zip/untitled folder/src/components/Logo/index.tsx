import { Button } from 'components/Button';
import { routesEnum } from 'pages/Routes';
import { FC } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.module.less';

export const Logo: FC = () => {
  return (
    <Button type="dashed" className={styles.root}>
      <Link to={routesEnum.home}>VERDANT</Link>
    </Button>
  );
};
