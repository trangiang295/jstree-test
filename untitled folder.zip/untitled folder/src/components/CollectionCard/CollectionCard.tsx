import { Surface } from 'components/Surface';
import { FC } from 'react';
import styles from './CollectionCard.module.less';
import avatar from 'assets/images/Avatar.png';
type CardProps = {
  image: string;
  name: string;
  owner: string;
  description: string;
  onClick?: () => void;
};

export const CollectionCard: FC<CardProps> = ({ image, name, owner, onClick }) => {
  return (
    <Surface className={styles.root} onClick={onClick}>
      <div style={{ backgroundImage: `url("${image}")` }} className={styles.image}></div>
      <div className={styles.cardContent}>
        <img src={avatar} alt="avatar" className={styles.avatar} />
        <div className={styles.name}>{name}</div>
        <div className={styles.owner}>
          by <span>{owner}</span>
        </div>
        {/* <div className={styles.description}>
          <span>{description}</span>
        </div> */}
      </div>
    </Surface>
  );
};
