import { FC, useEffect, useMemo, useState } from 'react';
import styles from './Offers.module.less';
import { Form, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { Input } from 'components/Input';
import { message } from 'utils/message';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';
import { useContractProvider } from 'hooks/useContract';
import { useParams } from 'react-router-dom';
import { getNFTModal, setNFTModal, setWithDrawRequest } from 'store/ducks/nft/slice';
import { sendEmailCode, useGetUserInfo } from 'api/account';
import { CONTRACT_ADDRESS } from 'utils/constant';
import { setAuthModal } from 'store/ducks/system/slice';

const { Title } = Typography;

export const TransferNftModal: FC = () => {
  const state = useAppSelector(getNFTModal);
  const [form] = Form.useForm();
  const dispatch = useAppDispatch();
  const [txid, setTxid] = useState('');
  const { data: userInfo } = useGetUserInfo();
  const [loading, setLoading] = useState(false);

  const { id } = useParams<{ id: string }>();

  const visible = useMemo(() => state === 'transfer-nft', [state]);
  const loadingGetTransaction = useContractProvider(txid);

  useEffect(() => {
    form.resetFields();
    setTxid('');
    setLoading(false);
    reset();
  }, [visible]);

  const handleClose = () => {
    dispatch(setNFTModal(null));
  };

  const {
    mutate: mutatePostWalletSystem,
    status: statusPostWalletSystem,
    reset,
  } = useMutation(postMethod, {
    onSuccess: (data) => {
      if (data?.status !== 'failed') {
        setTxid(data?.txid);
      } else {
        setLoading(false);
        message.error('Invalid');
      }
    },

    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const onFinish = async (value: any) => {
    setLoading(true);
    const request: IWalletSystemRequest = {
      method: 'withDrawNft',
      currency: 'polygon',
      data: [CONTRACT_ADDRESS.NFT, id, value.address],
    };
    if (!userInfo?.isActiveEmailCode && !userInfo?.isActive2fa) {
      mutatePostWalletSystem(request);
    } else {
      if (userInfo.isActiveEmailCode) {
        await mutateSendEmailCode();
      }
      dispatch(setWithDrawRequest(request));
      dispatch(setNFTModal(null));
      dispatch(setAuthModal('verify'));
    }
  };

  const { mutateAsync: mutateSendEmailCode } = useMutation(sendEmailCode, {
    onSuccess: () => {
      message.success('An email has been sent to your mail');
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  useEffect(() => {
    if (statusPostWalletSystem === 'success' && !loadingGetTransaction) {
      setTimeout(() => {
        setLoading(false);
        dispatch(setWithDrawRequest({}));
        message.success('Successfully');
        window.location.reload();
      }, 5000);
    }
  }, [statusPostWalletSystem, loadingGetTransaction]);

  return (
    <Modal visible={visible} onCancel={handleClose} width={400}>
      <div className={clsx(styles.root)}>
        <Title level={3} className="text-center">
          Transfer NFT
        </Title>
        <Form layout="vertical" onFinish={onFinish} form={form} validateTrigger="onBlur">
          <Form.Item label="Address" name="address" rules={[{ required: true }]}>
            <Input placeholder={'Enter address'} />
          </Form.Item>
          <Form.Item>
            <Button
              loading={
                (txid !== '' && loadingGetTransaction) || statusPostWalletSystem === 'loading' || loading === true
              }
              className="w-100"
              htmlType="submit"
            >
              Transfer
            </Button>
          </Form.Item>
        </Form>
      </div>
    </Modal>
  );
};
