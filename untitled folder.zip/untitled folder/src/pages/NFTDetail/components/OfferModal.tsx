import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { FC, useEffect, useMemo, useState } from 'react';
import { getBidId, getNFTModal, setBidId, setNFTModal } from 'store/ducks/nft/slice';
import { Col, Form, Row, Space, Typography } from 'antd';
import { InputNumber } from 'components/Input';
import { Select } from 'components/Select';
import { COMMON_DATA, CONTRACT_ADDRESS, PRICE } from 'utils/constant';
import { Button } from 'components/Button';
import { convertEther } from 'utils/number';
import { useConnectABI } from 'hooks/useConnectABI';
import MarketABI from 'contracts/MarketABI.json';
import { useContractFunction, useEthers } from '@usedapp/core';
import { checkLogin, getLoadingBtn, getStatusPrice } from 'utils/common';
import { useGetNFT, useGetOfferDetail } from 'api/nft';
import { useParams } from 'react-router-dom';
import { getTimeFromTo } from 'utils/time';
import { message } from 'utils/message';
import { useMutation } from 'react-query';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';
import { IError } from 'api/types';
import BigNumber from 'bignumber.js';
import styles from './Offers.module.less';
import { useContractProvider } from 'hooks/useContract';
import { getBalance } from 'store/ducks/user/slice';

const { Title, Paragraph } = Typography;
const { Option } = Select;

export const OfferModal: FC = () => {
  const state = useAppSelector(getNFTModal);
  const dispatch = useAppDispatch();
  const bidId = useAppSelector(getBidId);
  const visible = useMemo(() => state === 'offer', [state]);
  const { wallet, loginType } = useAppSelector((state) => state.user);
  const { id } = useParams<{ id: string }>();
  const { data: dataNFT, refetch: refetchNftDetail } = useGetNFT(id, { enabled: !!id });
  const { data: bidDetail, refetch: refetchBidDetail } = useGetOfferDetail(bidId, { enabled: !!bidId });
  const [action, setAction] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [txid, setTxid] = useState('');
  const balance = useAppSelector(getBalance);

  const [resetGetTransaction, setResetGetTransaction] = useState(false);
  const loadingGetTransaction = useContractProvider(txid, resetGetTransaction);

  const { active } = useEthers();

  const [form] = Form.useForm();

  useEffect(() => {
    if (bidDetail) {
      form.setFieldsValue({
        price: convertEther(bidDetail?.price),
        days: getTimeFromTo(Number(bidDetail?.createdAt), Number(bidDetail.expTime)),
      });
    }
    setAction(null);
    setTxid('');
    setLoading(false);
  }, [bidDetail]);

  const {
    resetState: resetStateUpdateBid,
    state: statusUpdateBid,
    send: sendUpdateBid,
  } = useContractFunction(useConnectABI(MarketABI, CONTRACT_ADDRESS.MARKET), 'updateBid');

  const {
    state: statusAcceptBid,
    send: sendAcceptBid,
    resetState: resetStateAcceptBid,
  } = useContractFunction(useConnectABI(MarketABI, CONTRACT_ADDRESS.MARKET), 'acceptBid');

  const {
    resetState: resetStateCancelBid,
    state: statusCancelBid,
    send: sendCancelBid,
  } = useContractFunction(useConnectABI(MarketABI, CONTRACT_ADDRESS.MARKET), 'cancelBid');

  const { mutate: mutatePostWalletSystem, status: statusPostWalletSystem } = useMutation(postMethod, {
    onSuccess: (data) => {
      if (data?.status !== 'failed') {
        setTxid(data?.txid);
      } else {
        setLoading(false);
        message.error('Invalid');
      }
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const handleClose = () => {
    dispatch(setBidId(null));
    dispatch(setNFTModal(null));
  };

  const onFinish = (value: any) => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }

    if (action) {
      message.info('You have an loading action');
      return;
    }

    if (wallet !== bidDetail?.bidder || bidDetail?.isActive === 0) {
      message.info('Please stop change website');
      return;
    }
    setResetGetTransaction(false);
    setAction('update');
    const bigNumber = new BigNumber(value.price).multipliedBy(10 ** 18);
    if (loginType === 'wallet') {
      setLoading(true);
      sendUpdateBid(bidDetail?.bidId, `${bigNumber.toPrecision(bigNumber.e ? bigNumber.e + 1 : 0)}`);
    } else if (loginType === 'email') {
      const request: IWalletSystemRequest = {
        method: 'updateBid',
        currency: 'polygon',
        data: [bidDetail?.bidId, `${bigNumber.toPrecision(bigNumber.e ? bigNumber.e + 1 : 0)}`],
      };
      if (!getStatusPrice(balance.usdc, value.price)) {
        message.info(`Lack of USDC`);
        return;
      }
      setLoading(true);
      mutatePostWalletSystem(request);
    }
  };

  const handleCancelBid = () => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }

    if (action) {
      message.info('You have an loading action');
      return;
    }

    if (wallet !== bidDetail?.bidder || bidDetail?.isActive === 0) {
      message.info('Please stop change website');
    } else {
      setLoading(true);
      setAction('cancel');
      setResetGetTransaction(false);
      if (loginType === 'wallet') {
        sendCancelBid(bidDetail?.bidId);
      } else if (loginType === 'email') {
        const request: IWalletSystemRequest = {
          method: 'cancelBid',
          currency: 'polygon',
          data: [bidDetail?.bidId],
        };
        mutatePostWalletSystem(request);
      }
    }
  };

  const handleAcceptBid = () => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }
    setResetGetTransaction(false);
    setLoading(true);
    setAction('accept');
    if (loginType === 'wallet') {
      sendAcceptBid(bidDetail?.bidId);
    } else if (loginType === 'email') {
      const request: IWalletSystemRequest = {
        method: 'acceptBid',
        currency: 'polygon',
        data: [bidDetail?.bidId],
      };
      mutatePostWalletSystem(request);
    }
  };

  useEffect(() => {
    if (statusPostWalletSystem === 'success' && !loadingGetTransaction) {
      setTimeout(() => {
        setLoading(false);
        setTxid('');
        setResetGetTransaction(true);
        refetchBidDetail();
        refetchNftDetail();
        setAction('');
        message.success(
          `${action === 'cancel' ? 'Cancel' : action === 'update' ? 'Update' : 'Accept'} offer successfully`
        );
        window.location.reload();
      }, 5000);
    }
  }, [statusPostWalletSystem, loadingGetTransaction]);

  useEffect(() => {
    if (statusUpdateBid.status === 'Success' || statusCancelBid.status === 'Success') {
      const timeOut = setTimeout(() => {
        setLoading(false);
        setAction('');
        message.success(`${action === 'cancel' ? 'Cancel' : 'Update'} offer successfully`);
        refetchBidDetail();
        resetStateUpdateBid();
        resetStateCancelBid();
      }, 5000);
      return () => clearTimeout(timeOut);
    } else if (
      statusUpdateBid.status === 'Exception' ||
      statusCancelBid.status === 'Exception' ||
      statusAcceptBid.status === 'Exception' ||
      statusUpdateBid.status === 'Fail' ||
      statusCancelBid.status === 'Fail' ||
      statusAcceptBid.status === 'Fail'
    ) {
      message.error(
        statusUpdateBid?.errorMessage || statusCancelBid?.errorMessage || statusAcceptBid?.errorMessage || 'Error'
      );
      setAction('');
      resetStateAcceptBid();
      resetStateUpdateBid();
      resetStateCancelBid();
      setLoading(false);
    } else if (statusAcceptBid.status === 'Success') {
      const timeOut = setTimeout(() => {
        dispatch(setNFTModal(null));
        setLoading(false);
        message.success('Accept offer successfully');
        refetchNftDetail();
        resetStateAcceptBid();
        setAction('');
      }, 5000);

      return () => clearTimeout(timeOut);
    }
  }, [statusUpdateBid, statusCancelBid, statusAcceptBid]);

  return (
    <Modal visible={visible} onCancel={handleClose} width={630}>
      <Title level={3} className="text-md-start text-center">
        DETAIL OFFER
      </Title>
      <Paragraph>{dataNFT?.name}</Paragraph>
      <Row>
        <Col xs={24} md={8} className="mb-md-0 mb-3">
          <div style={{ backgroundImage: `url("${dataNFT?.image_url}")` }} className={styles.image} />
        </Col>
        <Col xs={24} md={16}>
          <Form layout="vertical" form={form} onFinish={onFinish}>
            <Form.Item label="Price" name="price" rules={[{ required: true }]}>
              <InputNumber
                placeholder="Price"
                disabled={
                  wallet === dataNFT?.human_owner ||
                  (wallet !== dataNFT?.human_owner && (wallet !== bidDetail?.bidder || bidDetail?.isActive === 0))
                }
                min={PRICE.minSell}
                max={PRICE.maxSell}
              />
            </Form.Item>
            <Form.Item label="Days" name="days">
              <Select placeholder="Expired time" disabled>
                {COMMON_DATA.listDay.map((item) => (
                  <Option key={item.value} value={item.value}>
                    {item.value + ' ' + item.text}
                  </Option>
                ))}
              </Select>
            </Form.Item>
            {wallet === dataNFT?.human_owner && (
              <Form.Item>
                <Button
                  loading={
                    getLoadingBtn(statusAcceptBid) ||
                    statusPostWalletSystem === 'loading' ||
                    (action === 'accept' && loading) ||
                    (txid !== '' && loadingGetTransaction && action === 'accept')
                  }
                  className="w-100"
                  onClick={handleAcceptBid}
                  disabled={bidDetail?.isActive === 0 || !dataNFT?.is_onsale}
                >
                  {bidDetail?.isActive === 0 ? 'CANCELLED' : 'ACCEPT OFFER'}
                </Button>
              </Form.Item>
            )}
            {wallet !== dataNFT?.human_owner && (
              <Space wrap align="center" className="justify-content-center w-100">
                <Form.Item>
                  <Button
                    disabled={wallet !== bidDetail?.bidder || bidDetail?.isActive === 0}
                    loading={
                      getLoadingBtn(statusUpdateBid) ||
                      (statusPostWalletSystem === 'loading' && action === 'update') ||
                      (action === 'update' && loading) ||
                      (txid !== '' && loadingGetTransaction && action === 'update')
                    }
                    className="w-100"
                    htmlType="submit"
                  >
                    UPDATE OFFER
                  </Button>
                </Form.Item>
                <Form.Item>
                  <Button
                    disabled={wallet !== bidDetail?.bidder || bidDetail?.isActive === 0}
                    loading={
                      getLoadingBtn(statusCancelBid) ||
                      (statusPostWalletSystem === 'loading' && action === 'cancel') ||
                      (loading && action === 'cancel') ||
                      (txid !== '' && loadingGetTransaction && action === 'cancel')
                    }
                    className="w-100"
                    onClick={handleCancelBid}
                  >
                    CANCEL OFFER
                  </Button>
                </Form.Item>
              </Space>
            )}
          </Form>
        </Col>
      </Row>
    </Modal>
  );
};
