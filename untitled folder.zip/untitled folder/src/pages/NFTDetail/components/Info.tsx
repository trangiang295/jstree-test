import { FC, useEffect, useState } from 'react';
import styles from './Info.module.less';
import { Col, Descriptions, Row, Space, Tooltip, Typography } from 'antd';
import { Button } from 'components/Button';
import clsx from 'clsx';
import { useHistory, useParams } from 'react-router-dom';
import { useGetNFT } from 'api/nft';
import { LoadingFullpage } from 'components/Loading';
import { convertEther } from 'utils/number';
import { shortenAddress, useContractFunction, useEthers } from '@usedapp/core';
import { useAppDispatch, useAppSelector } from 'hooks';
import { message } from 'utils/message';
import { useConnectABI } from 'hooks/useConnectABI';
import { CONTRACT_ADDRESS } from 'utils/constant';
import MarketABI from 'contracts/MarketABI.json';
import { checkLogin, convertName, getLoadingBtn } from 'utils/common';
import { IError } from 'api/types';
import { useMutation } from 'react-query';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';
import { useContractProvider } from 'hooks/useContract';
import { setNFTModal } from 'store/ducks/nft/slice';
import { Video } from 'components/Media';

const { Title } = Typography;

export const Info: FC = () => {
  const history = useHistory();
  const { id } = useParams<{ id: string }>();
  const { data: dataNFT, status, refetch } = useGetNFT(id, { enabled: !!id });
  const { wallet, loginType } = useAppSelector((state) => state.user);
  const [loading, setLoading] = useState(false);
  const [txid, setTxid] = useState('');

  const dispatch = useAppDispatch();

  const { active } = useEthers();

  const loadingGetTransaction = useContractProvider(txid);

  const handleBuy = () => {
    if (!wallet) {
      message.info('Please login to continue');
    } else history.push(`/buy-nft/summary/${id}`);
  };

  const handleSell = () => {
    if (!wallet) {
      message.info('Please login to continue');
    } else history.push(`/sell-nft/summary/${id}`);
  };

  const { state: statusCancelSell, send: sendCancelSell } = useContractFunction(
    useConnectABI(MarketABI, CONTRACT_ADDRESS.MARKET),
    'cancelOrder'
  );

  const { mutate: mutatePostWalletSystem, status: statusPostWalletSystem } = useMutation(postMethod, {
    onSuccess: (data) => {
      if (data?.status !== 'failed') {
        setTxid(data?.txid);
      } else {
        setLoading(false);
        message.error('Invalid');
      }
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const handleCancelSell = () => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }

    setLoading(true);

    if (loginType === 'wallet') {
      sendCancelSell(dataNFT?.order_id);
    } else {
      const request: IWalletSystemRequest = {
        method: 'cancelOrder',
        currency: 'polygon',
        data: [dataNFT?.order_id],
      };
      mutatePostWalletSystem(request);
    }
  };

  useEffect(() => {
    if (statusPostWalletSystem === 'success' && !loadingGetTransaction) {
      setTimeout(() => {
        setLoading(false);
        message.success('Cancel successfully');
        setTxid('');
        refetch();
      }, 5000);
    }
  }, [statusPostWalletSystem, loadingGetTransaction]);

  useEffect(() => {
    if (statusCancelSell.status === 'Success') {
      const timeOut = setTimeout(() => {
        setLoading(false);
        message.success('Successfully');
        history.push(`/nft-detail/${id}`);
        refetch();
      }, 3000);

      return () => clearTimeout(timeOut);
    } else if (statusCancelSell.status === 'Exception' || statusCancelSell.status === 'Fail') {
      message.error(statusCancelSell?.errorMessage || 'Error');
      setLoading(false);
    }
  }, [statusCancelSell]);

  const handleTransferNFT = () => {
    dispatch(setNFTModal('transfer-nft'));
  };

  if (status === 'loading') {
    return <LoadingFullpage />;
  }

  return (
    <div className={styles.root}>
      <Row>
        <Col
          xs={24}
          sm={24}
          lg={12}
          xl={16}
          className="d-flex flex-column justify-content-between mb-md-0 mb-4 pe-md-5"
        >
          <div>
            <Title level={1} className={styles.title}>
              {dataNFT?.name}
            </Title>
            <Descriptions layout="vertical">
              <Descriptions.Item label="DESCRIPTION">{dataNFT?.description}</Descriptions.Item>
            </Descriptions>
            <Row>
              <Col md={12} xs={24} sm={12}>
                <Descriptions layout="vertical">
                  <Descriptions.Item label="CURRENT OWNER">{convertName(dataNFT)}</Descriptions.Item>
                </Descriptions>
                <Descriptions layout="vertical">
                  <Descriptions.Item label="PRICE">{convertEther(dataNFT?.price)} USDC</Descriptions.Item>
                </Descriptions>
                <Descriptions layout="vertical">
                  <Descriptions.Item label="NFT ID">{dataNFT?.token_id}</Descriptions.Item>
                </Descriptions>
              </Col>
              <Col md={12} xs={24} sm={12}>
                <Descriptions layout="vertical">
                  <Descriptions.Item label="DETAIL" contentStyle={{ display: 'block' }}>
                    <Row>
                      <Col md={12}>
                        <div className="ms-xl-5">- Contract Address</div>
                        <div className="ms-xl-5">- TokenId</div>
                        <div className="ms-xl-5">- Collection Name</div>
                        <div className="ms-xl-5">- Payment Token</div>
                        <div className="ms-xl-5">- MetaData</div>
                      </Col>
                      <Col md={12}>
                        <div className="text-end">
                          <Tooltip title={dataNFT?.contract_address}>
                            {dataNFT?.contract_address ? shortenAddress(dataNFT?.contract_address) : '-'}
                          </Tooltip>
                        </div>
                        <div className="text-end">{dataNFT?.token_id}</div>
                        <div className="text-end">
                          <Tooltip title={dataNFT?.collection_name}>
                            {dataNFT?.collection_name && dataNFT?.collection_name?.length > 20
                              ? `${dataNFT?.collection_name?.slice(0, 20)}...`
                              : dataNFT?.collection_name}
                          </Tooltip>
                        </div>
                        <div className="text-end">
                          <Tooltip title={dataNFT?.payment_token}>
                            {dataNFT?.payment_token ? shortenAddress(dataNFT?.payment_token) : '-'}
                          </Tooltip>
                        </div>
                        <div className="text-end">{dataNFT?.meta_data || '-'}</div>
                      </Col>
                    </Row>
                  </Descriptions.Item>
                </Descriptions>
              </Col>
            </Row>
          </div>
          <div>
            {wallet !== dataNFT?.human_owner && dataNFT?.is_onsale === 1 && (
              <div>
                <Button className={clsx(styles.customBtn, 'me-4')} onClick={handleBuy}>
                  BUY NOW
                </Button>
                <Button
                  className={clsx(styles.customBtnView)}
                  onClick={() => history.push(`/buy-nft/make-offer/${id}`)}
                >
                  MAKE OFFER
                </Button>
              </div>
            )}
            {wallet === dataNFT?.human_owner && (
              <Space>
                <Button className={styles.customBtn} onClick={handleSell} disabled={dataNFT?.is_onsale === 1}>
                  {dataNFT?.is_onsale === 1 ? 'Selling' : 'Sell'}
                </Button>
                {loginType === 'email' && dataNFT?.is_onsale !== 1 && (
                  <Button className="customBtnCommon" onClick={handleTransferNFT}>
                    TRANSFER NFT
                  </Button>
                )}
                {dataNFT?.is_onsale === 1 && (
                  <Button
                    className={clsx(styles.customBtnView)}
                    onClick={() => history.push(`/sell-nft/summary/${id}`)}
                  >
                    UPDATE SELL
                  </Button>
                )}
                {dataNFT?.is_onsale === 1 && (
                  <Button
                    className={styles.customBtnView}
                    onClick={handleCancelSell}
                    loading={
                      getLoadingBtn(statusCancelSell) ||
                      statusPostWalletSystem === 'loading' ||
                      loading === true ||
                      (txid !== '' && loadingGetTransaction)
                    }
                  >
                    CANCEL SELL
                  </Button>
                )}
              </Space>
            )}
          </div>
        </Col>
        <Col xs={24} sm={24} lg={12} xl={8} className="ps-xl-4 mt-3 mt-xl-0">
          {dataNFT?.image_type === 'video/mp4' ? (
            <Video src={dataNFT?.image_url || ''} className={styles.image} />
          ) : (
            <div style={{ backgroundImage: `url("${dataNFT?.image_url}")` }} className={styles.image} />
          )}
        </Col>
      </Row>
    </div>
  );
};
