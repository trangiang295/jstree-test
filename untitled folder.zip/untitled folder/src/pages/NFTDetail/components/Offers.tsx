import clsx from 'clsx';
import { HeaderTitle } from 'components/HeaderTitle';
import { FC, useState } from 'react';
import styles from './History.module.less';
import { Table as AntdTable } from 'antd';
import { useGetOffers } from 'api/nft';
import { IOffersRequest } from 'api/types';
import useBreakpoint from 'antd/lib/grid/hooks/useBreakpoint';
import { useParams } from 'react-router-dom';
import { Pagination } from 'components/Pagination';
import { convertEther } from 'utils/number';
import { POLYGON_SCAN } from 'utils/constant';
import { FiExternalLink } from 'react-icons/fi';
import { relativeTime } from 'utils/time';
import moment from 'moment';
import { useAppDispatch } from 'hooks';
import { setBidId, setNFTModal } from 'store/ducks/nft/slice';
import { Button } from 'components/Button';
import { convertName, convertOfferBidder } from 'utils/common';

const COLUMNS = [
  {
    title: 'Owner',
    key: 'human_owner',
    align: 'center' as const,
    width: '150px',
    render: (data: any) => <>{convertName(data)}</>,
  },
  {
    title: 'Bidder',
    key: 'bidder',
    align: 'center' as const,
    width: '150px',
    render: (data: any) => <>{convertOfferBidder(data)}</>,
  },

  {
    title: 'Price',
    dataIndex: 'price',
    key: 'price',
    align: 'center' as const,
    render: (price: any) => <>{convertEther(price)} USDC</>,
    width: '150px',
  },
  {
    title: 'Create Date',
    dataIndex: 'created_at',
    key: 'created_at',
    align: 'center' as const,
    render: (created_at: any) => (
      <>
        {moment(new Date(Number(created_at)))
          .format('YYYY-MM-DD HH:mm')
          .toString()}
      </>
    ),
  },
  {
    title: 'Expired time',
    dataIndex: 'exp_time',
    key: 'exp_time',
    align: 'center' as const,
    render: (exp_time: any) => (
      <>
        {moment(new Date(Number(exp_time)))
          .format('YYYY-MM-DD HH:mm')
          .toString()}
      </>
    ),
  },
  {
    title: 'Date',
    key: 'updated_at',
    render: (data: any) => (
      <a href={`${POLYGON_SCAN}/tx/${data.txid}`} target="_blank" rel="noopener noreferrer" className={styles.date}>
        {relativeTime(data.updated_at)}
        <FiExternalLink />
      </a>
    ),
    align: 'center' as const,
  },
  {
    title: 'Action',
    key: 'action',
    render: (data: any) => {
      const dispatch = useAppDispatch();
      const handleDetailModal = () => {
        dispatch(setBidId(data?.bid_id));
        dispatch(setNFTModal('offer'));
      };

      return (
        <Button type="default" onClick={handleDetailModal}>
          Detail
        </Button>
      );
    },
    align: 'center' as const,
  },
];

export const Offers: FC = () => {
  const { id } = useParams<{ id: string }>();

  const [offerRequest, setOfferRequest] = useState<IOffersRequest>({
    tokenId: id,
    page: 1,
    limit: 8,
  });
  const { data: dataOffers } = useGetOffers(offerRequest, { enabled: !!id });

  const onChangePage = (current: number) => {
    setOfferRequest({ ...offerRequest, page: current });
  };

  const screen = useBreakpoint();

  return (
    <div className={clsx(styles.root)}>
      <HeaderTitle title="OFFERS" />
      <AntdTable
        columns={COLUMNS}
        pagination={false}
        dataSource={dataOffers && dataOffers.list}
        scroll={screen.lg ? undefined : { x: 1200 }}
      />
      <Pagination
        className={styles.pagination}
        onChange={onChangePage}
        current={Number(dataOffers?.pagination?.currentPage || 1)}
        pageSize={dataOffers?.pagination?.itemsPerPage || 8}
        total={dataOffers?.pagination?.totalItems || 8}
      />
    </div>
  );
};
