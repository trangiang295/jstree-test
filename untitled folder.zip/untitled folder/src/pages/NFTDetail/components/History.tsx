import clsx from 'clsx';
import { HeaderTitle } from 'components/HeaderTitle';
import { FC, useState } from 'react';
import styles from './History.module.less';
import { Table as AntdTable } from 'antd';
import { useGetHistory } from 'api/nft';
import { IPaginationRequest } from 'api/types';
import useBreakpoint from 'antd/lib/grid/hooks/useBreakpoint';
import { useParams } from 'react-router-dom';
import { Pagination } from 'components/Pagination';
import { convertEther } from 'utils/number';
import { POLYGON_SCAN } from 'utils/constant';
import { FiExternalLink } from 'react-icons/fi';
import { relativeTime } from 'utils/time';
import { convertLogAction } from 'utils/logAction';
import { convertHistoryFromName, convertHistoryToName } from 'utils/common';

const COLUMNS = [
  {
    title: 'Token ID',
    key: 'token_id',
    dataIndex: 'token_id',
    align: 'center' as const,
    width: '150px',
  },
  {
    title: 'Log Action',
    key: 'log_action',
    dataIndex: 'log_action',
    align: 'center' as const,
    width: '150px',
    render: (log_action: any) => <>{convertLogAction(log_action)}</>,
  },
  {
    title: 'NFT Action',
    key: 'nft_action',
    dataIndex: 'nft_action',
    align: 'center' as const,
    width: '150px',
  },
  {
    title: 'Price',
    dataIndex: 'price',
    key: 'price',
    align: 'center' as const,
    render: (price: any) => <>{convertEther(price)} USDC</>,
    width: '150px',
  },
  {
    title: 'From',
    key: 'from',
    align: 'center' as const,
    render: (data: any) => <>{convertHistoryFromName(data)}</>,
  },
  {
    title: 'To',
    key: 'to',
    align: 'center' as const,
    render: (data: any) => <>{convertHistoryToName(data)}</>,
  },
  {
    title: 'Date',
    key: 'updated_at',
    render: (data: any) => (
      <a href={`${POLYGON_SCAN}/tx/${data.txid}`} target="_blank" rel="noopener noreferrer" className={styles.date}>
        {relativeTime(data.updated_at)}
        <FiExternalLink />
      </a>
    ),
    align: 'center' as const,
  },
];

export const History: FC = () => {
  const { id } = useParams<{ id: string }>();
  const [page, setPage] = useState<IPaginationRequest>({
    page: 1,
    limit: 8,
  });
  const { data: histories } = useGetHistory(id, page);

  const onChangePage = (current: number) => {
    setPage({ ...page, page: current });
  };

  const screen = useBreakpoint();

  return (
    <div className={clsx(styles.root)}>
      <HeaderTitle title="EDITION HISTORY/RELEASE HISTORY" />
      <AntdTable
        columns={COLUMNS}
        pagination={false}
        dataSource={histories && histories.list}
        scroll={screen.lg ? undefined : { x: 1200 }}
      />
      <Pagination
        className={styles.pagination}
        onChange={onChangePage}
        current={Number(histories?.pagination?.currentPage || 1)}
        pageSize={histories?.pagination?.itemsPerPage || 8}
        total={histories?.pagination?.totalItems || 8}
      />
    </div>
  );
};
