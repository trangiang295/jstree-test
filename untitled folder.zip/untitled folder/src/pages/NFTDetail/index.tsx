import { FC } from 'react';
import styles from './styles.module.css';
import { Info } from './components/Info';
import { History } from './components/History';
import clsx from 'clsx';
import { Offers } from './components/Offers';
import { OfferModal } from './components/OfferModal';
import { TransferNftModal } from './components/TransferNftModal';

const NFTDetail: FC = () => {
  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <div className="container">
        <Info />
        <Offers />
        <History />
      </div>
      <OfferModal />
      <TransferNftModal />
    </div>
  );
};

export default NFTDetail;
