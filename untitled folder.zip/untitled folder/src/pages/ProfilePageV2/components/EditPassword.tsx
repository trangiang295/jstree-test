import { FC } from 'react';
import { Col, Form, message, Row, Typography } from 'antd';
import { routesEnum } from 'pages/Routes';
import { useHistory } from 'react-router-dom';
import { IUpdatePasswordRequest, logout, updatePassword } from 'api/account';
import { InputPassword } from 'components/Input';
import { setToken } from 'store/ducks/user/slice';
import { setAuthModal } from 'store/ducks/system/slice';
import { IError } from 'api/types';
import { useAppDispatch } from 'hooks';
import { useMutation } from 'react-query';
import { Button } from 'components/Button';
import styles from './Account.module.less';

const { Paragraph } = Typography;

export const EditPassword: FC = () => {
  const history = useHistory();
  const dispatch = useAppDispatch();

  const { mutate: mutateLogout } = useMutation(logout, {
    onSuccess: () => {
      localStorage.clear();
      dispatch(setToken(''));
      history.push(routesEnum.home);
      dispatch(setAuthModal('login'));
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const { mutate: mutateUpdatePassword, status: statusChangePassword } = useMutation(updatePassword, {
    onSuccess: () => {
      message.success('Update Password successfully');
      mutateLogout();
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const onFinishChangePassword = (value: any) => {
    const updatePasswordRequest: IUpdatePasswordRequest = { ...value };
    mutateUpdatePassword(updatePasswordRequest);
  };

  return (
    <>
      <Paragraph strong className="primaryText">
        EDIT PASSWORD
      </Paragraph>
      <Form layout="vertical" onFinish={onFinishChangePassword} validateTrigger="onBlur">
        <Row className="mb-4">
          <Col className="d-flex align-items-center" md={4} xs={24} sm={24}>
            Current Password
          </Col>
          <Col md={10} xs={24} sm={24}>
            <Form.Item
              className="mb-0"
              name="oldPassword"
              label="Password"
              rules={[{ required: true }, { type: 'string', min: 6 }, { type: 'string', max: 20 }]}
            >
              <InputPassword placeholder="Password" className="w-100" />
            </Form.Item>
          </Col>
        </Row>
        <Row className="mb-4">
          <Col className="d-flex align-items-center" md={4} xs={24} sm={24}>
            New Password
          </Col>
          <Col md={10} xs={24} sm={24}>
            <Form.Item
              className="mb-0"
              name="newPassword"
              label="New Password"
              rules={[{ required: true }, { type: 'string', min: 6 }, { type: 'string', max: 20 }]}
            >
              <InputPassword className="w-100" placeholder="New Password" />
            </Form.Item>
          </Col>
        </Row>
        <Row>
          <Col className="d-flex align-items-center" md={4} xs={24} sm={24}>
            Confirm Password
          </Col>
          <Col md={10} xs={24} sm={24}>
            <Form.Item
              className="mb-0"
              name="confirmPassword"
              label="Confirm Password"
              dependencies={['newPassword']}
              rules={[
                { required: true },
                ({ getFieldValue }) => ({
                  validator(_, value) {
                    if (!value || getFieldValue('newPassword') === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject(new Error('Confirm password do not match!'));
                  },
                }),
              ]}
            >
              <InputPassword className="w-100" placeholder="Confirm Password" />
            </Form.Item>
          </Col>
        </Row>
        <Row className="mb-4">
          <Col md={4} xs={24} sm={24}></Col>
          <Col md={10} xs={24} sm={24}>
            <Form.Item>
              <Paragraph className={styles.definePass}>
                Password must be at least 8 characters and contain 1 special character or number.
              </Paragraph>
              <Button loading={statusChangePassword === 'loading'} className="w-100" htmlType="submit">
                CHANGE PASSWORD
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </>
  );
};
