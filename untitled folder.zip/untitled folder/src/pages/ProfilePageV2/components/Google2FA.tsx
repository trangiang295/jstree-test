import { Col, Row, Typography } from 'antd';
import { active2FARequest, disable2FARequest, useGet2FA, useGetUserInfo } from 'api/account';
import { FC, useEffect, useState } from 'react';
import styles from './Google2FA.module.less';
import QRCode from 'qrcode';
import { authenticator } from 'otplib';
import { message } from 'utils/message';
import { Input } from 'components/Input';
import { Button } from 'components/Button';
import { useMutation } from 'react-query';
import { LoadingFullpage } from 'components/Loading';
import { IError } from 'api/types';

const { Title, Paragraph } = Typography;

export const Google2FA: FC = () => {
  const [imageURL, setImageURL] = useState('');
  const { data: data2Fa, refetch: refetchGet2FA } = useGet2FA();
  const { data: userInfo, refetch } = useGetUserInfo();
  const [verifyCode, setVerifyCode] = useState('');

  const { mutate, isLoading } = useMutation(userInfo?.isActive2fa !== 0 ? disable2FARequest : active2FARequest, {
    onSuccess: () => {
      refetch();
      refetchGet2FA();
      message.success(`Update 2FA successfully!`);
      setVerifyCode('');
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  useEffect(() => {
    if (userInfo?.type === 'wallet' || !userInfo?.email || !data2Fa?.twoFactorAuthenticationSecret) return undefined;
    const otpauthUrl = authenticator.keyuri(userInfo?.email, 'MARKET-PLACE', data2Fa?.twoFactorAuthenticationSecret);
    QRCode.toDataURL(otpauthUrl, (error, url) => {
      if (error) {
        message.error(error.message);
      } else {
        setImageURL(url);
      }
    });
  }, [data2Fa, userInfo]);

  const handleSubmit = () => {
    if (!verifyCode) {
      message.info('Please input your two fa code');
      return;
    }
    mutate({
      twofa: verifyCode,
    });
  };

  if (userInfo?.isActive2fa === 0 && !imageURL) {
    return <LoadingFullpage />;
  }

  return (
    <div className={styles.root}>
      <Title level={3} className="text-center primaryText">
        TWO FACTOR AUTHENTICATION
      </Title>
      <Paragraph className="text-center">
        Use Google Authenticator app for Android and iOS to protect your account.
      </Paragraph>
      {userInfo?.isActive2fa === 0 && (
        <>
          <Paragraph strong className="text-center mt-5">
            Scan QR code with your phone Google Authenticator app
          </Paragraph>
          <Row justify="center">
            <Col xs={12} md={4} sm={8}>
              <img src={imageURL} alt="" width="100%" />
            </Col>
          </Row>
          <Paragraph strong className="text-center mt-4">
            or use the following code:
          </Paragraph>
          <Title level={3} className="text-center primaryText">
            {data2Fa?.twoFactorAuthenticationSecret}
          </Title>
          <Paragraph className="text-center ">For your safety, copy and backup this code in a safe place.</Paragraph>
        </>
      )}
      <Paragraph className="text-center ">
        <strong>
          Enter google authenticator 6 digit code to {userInfo?.isActive2fa !== 0 ? 'disable' : 'enable'} it:
        </strong>
      </Paragraph>
      <Row justify="center">
        <Col xs={24} md={8} sm={8}>
          <Input onChange={(e) => setVerifyCode(e.target.value)} value={verifyCode} />
        </Col>
      </Row>
      <div className="text-center my-4" onClick={handleSubmit}>
        <Button loading={isLoading} className="customBtnCommon">
          {userInfo?.isActive2fa !== 0 ? 'DISABLE' : 'ENABLE'}
        </Button>
      </div>
    </div>
  );
};
