import { Col, Form, Row, Typography } from 'antd';
import { IUpdateSendEmailCode, sendEmailCode, updateSendEmailCode, useGetUserInfo } from 'api/account';
import { IError } from 'api/types';
import { Button } from 'components/Button';
import { Input } from 'components/Input';
import { FC } from 'react';
import { useMutation } from 'react-query';
import { message } from 'utils/message';
const { Title } = Typography;

export const EmailActiveCode: FC = () => {
  const { data: userInfo, refetch } = useGetUserInfo();

  const onFinish = (value: any) => {
    const request: IUpdateSendEmailCode = {
      ...value,
      status: !userInfo?.isActiveEmailCode,
    };
    mutateUpdateSendEmailCode(request);
  };

  const { mutate: mutateSendEmailCode, status } = useMutation(sendEmailCode, {
    onSuccess: () => {
      message.success('An email has been sent to your mail');
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const { mutate: mutateUpdateSendEmailCode, status: statusUpdate } = useMutation(updateSendEmailCode, {
    onSuccess: () => {
      message.success('Successfully');
      refetch();
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  return (
    <Row justify="center">
      <Col md={12} xs={24} sm={24}>
        <Title level={3} className="primaryText text-center">
          EMAIL ACTIVE CODE
        </Title>
        <div className="text-center my-4">
          <Button onClick={() => mutateSendEmailCode()} loading={status === 'loading'}>
            SEND EMAIL CODE
          </Button>
        </div>
        <Form onFinish={onFinish}>
          <Form.Item name="emailCode" label="Email Code" rules={[{ required: true }]}>
            <Input placeholder="Email Code" />
          </Form.Item>
          <div className="text-center">
            <Form.Item>
              <Button htmlType="submit" loading={statusUpdate === 'loading'} className="customBtnCommon">
                {userInfo?.isActiveEmailCode !== 0 ? 'DISABLE' : 'ENABLE'}
              </Button>
            </Form.Item>
          </div>
        </Form>
      </Col>
    </Row>
  );
};
