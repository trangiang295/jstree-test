import { FC } from 'react';
import { Menu as MenuAntd } from 'antd';
import { routesEnum } from 'pages/Routes';
import { useHistory, useLocation } from 'react-router-dom';
import { useGetUserInfo } from 'api/account';

export const Menu: FC = () => {
  const location = useLocation();
  const history = useHistory();
  const { data: userInfo } = useGetUserInfo();

  return (
    <MenuAntd mode="horizontal" selectedKeys={[location.pathname]}>
      <MenuAntd.Item onClick={() => history.push(routesEnum.profile)} key={routesEnum.profile}>
        <strong>Account</strong>
      </MenuAntd.Item>
      {userInfo?.type === 'email' && (
        <>
          <MenuAntd.Item onClick={() => history.push(routesEnum.google2fa)} key={routesEnum.google2fa}>
            <strong>Google 2FA</strong>
          </MenuAntd.Item>
          <MenuAntd.Item onClick={() => history.push(routesEnum.emailActiveCode)} key={routesEnum.emailActiveCode}>
            <strong>Active Email Code</strong>
          </MenuAntd.Item>
        </>
      )}
      <MenuAntd.Item onClick={() => history.push(routesEnum.wallet)} key={routesEnum.wallet}>
        <strong>My Wallet</strong>
      </MenuAntd.Item>
    </MenuAntd>
  );
};
