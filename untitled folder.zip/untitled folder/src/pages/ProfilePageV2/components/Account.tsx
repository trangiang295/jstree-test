import { FC, useEffect, useState } from 'react';
import styles from './Account.module.less';
import { Avatar as AntdAvatar, Col, DatePicker, Form, Row, Typography, Upload } from 'antd';
import { Input } from 'components/Input';
import { Button } from 'components/Button';
import { phoneNumberRule } from 'utils/validator';
import { shortenAddress } from '@usedapp/core';
import { updateProfile, useGetUserInfo } from 'api/account';
import { useCopy } from 'hooks/useCopy';
import { CheckOutlined, CopyOutlined, UserOutlined } from '@ant-design/icons';
import moment from 'moment';
import { useMutation } from 'react-query';
import { message } from 'utils/message';
import { IError } from 'api/types';
import { convertToFormData } from 'api/axios';
import { convertToBase64 } from 'utils/common';
import { LoadingFullpage } from 'components/Loading';
import { EditPassword } from './EditPassword';
import { useAppSelector } from 'hooks';

const { Title, Paragraph } = Typography;

export const Account: FC = () => {
  const { loginType } = useAppSelector((state) => state.user);
  const { data: userInfo, refetch } = useGetUserInfo();
  const [copied, copy] = useCopy();
  const [form] = Form.useForm();
  const [file, setFile] = useState('');
  const [src, setSrc] = useState('');

  useEffect(() => {
    form.setFieldsValue({
      ...userInfo,
      dateOfBirth: userInfo?.dateOfBirth ? moment(userInfo?.dateOfBirth, 'YYYY-MM-DD') : null,
    });
  }, [userInfo]);

  const { mutate: mutateUpdateProfile, status } = useMutation(updateProfile, {
    onSuccess: () => {
      refetch();
      message.success('Update Profile successfully');
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const handleCopy = () => {
    copy(userInfo?.wallet as string);
  };

  const onFinish = (value: any) => {
    const updateProfileRequest = {
      ...value,
      dateOfBirth: value.dateOfBirth ? value['dateOfBirth'].format('YYYY-MM-DD') : null,
    };
    if (file) {
      updateProfileRequest.image = file;
    }
    mutateUpdateProfile(convertToFormData(updateProfileRequest));
  };

  const onChangeAvatar = (info: any) => {
    setFile(info?.file);
    const reader = new FileReader();
    reader.onload = () => {
      setSrc(convertToBase64(reader.result));
    };
    reader.readAsArrayBuffer(info?.file);
  };

  if (!userInfo) {
    return <LoadingFullpage />;
  }
  return (
    <div className={styles.root}>
      <Title level={3} className="primaryText">
        BASIC INFORMATION
      </Title>
      <Paragraph className="my-4">
        You have signed up using: <strong>{userInfo?.email}</strong>
      </Paragraph>
      <Paragraph className={styles.addressWallet} onClick={handleCopy}>
        Your address: <strong> {userInfo?.wallet ? shortenAddress(userInfo?.wallet) : ''}</strong>
        {copied ? <CheckOutlined className="pointer" /> : <CopyOutlined className="pointer" />}
      </Paragraph>
      <Row className="my-5">
        <Col md={4} xs={24} sm={24}>
          <Paragraph strong className="primaryText">
            AVATAR
          </Paragraph>
        </Col>
        <Col md={10} xs={24} sm={24}>
          <AntdAvatar className="d-block mb-4" size={120} src={src || userInfo?.avatarUrl} icon={<UserOutlined />} />
          <Upload className={styles.upload} showUploadList={false} beforeUpload={() => false} onChange={onChangeAvatar}>
            <Input value="" suffix="Browser" placeholder="Choose image"></Input>
          </Upload>
        </Col>
      </Row>

      <Paragraph strong className="primaryText">
        EDIT PROFILE
      </Paragraph>
      <Form layout="vertical" onFinish={onFinish} form={form} validateTrigger="onBlur">
        <Row className="mb-4">
          <Col className="d-flex align-items-center" md={4} xs={24} sm={24}>
            First Name
          </Col>
          <Col md={10} xs={24} sm={24}>
            <Form.Item className="mb-0" label="First Name" name="firstName">
              <Input placeholder="First name" maxLength={50} />
            </Form.Item>
          </Col>
        </Row>
        <Row className="mb-4">
          <Col className="d-flex align-items-center" md={4} xs={24} sm={24}>
            Last Name
          </Col>
          <Col md={10} xs={24} sm={24}>
            <Form.Item className="mb-0" label="Last Name" name="lastName">
              <Input placeholder="Last name" maxLength={50} />
            </Form.Item>
          </Col>
        </Row>
        <Row className="mb-4">
          <Col className="d-flex align-items-center" md={4} xs={24} sm={24}>
            Phone Number
          </Col>
          <Col md={10} xs={24} sm={24}>
            <Form.Item
              className="mb-0"
              validateFirst
              label="Phone"
              name="phone"
              rules={[
                { whitespace: true },
                {
                  async validator(_, value) {
                    return await phoneNumberRule(value);
                  },
                },
              ]}
            >
              <Input placeholder="Phone" />
            </Form.Item>
          </Col>
        </Row>
        <Row className="mb-4">
          <Col className="d-flex align-items-center" md={4} xs={24} sm={24}>
            Date Of Birth
          </Col>
          <Col md={10} xs={24} sm={24}>
            <Form.Item className="mb-0" label="Date Of Birth" name="dateOfBirth">
              <DatePicker
                className="w-100"
                format="YYYY-MM-DD"
                placeholder="Date Of Birth"
                disabledDate={(currentDate) => currentDate && currentDate.valueOf() > Date.now()}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row className="mb-4">
          <Col md={4} xs={24} sm={24}></Col>
          <Col md={10} xs={24} sm={24}>
            <Form.Item>
              <Button loading={status === 'loading'} className="w-100" htmlType="submit">
                SAVE
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
      {loginType === 'email' && <EditPassword />}
    </div>
  );
};
