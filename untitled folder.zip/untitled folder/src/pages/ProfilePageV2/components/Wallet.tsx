import { Col, Row, Typography } from 'antd';
import { Button } from 'components/Button';
import { Input } from 'components/Input';
import { useAppDispatch, useAppSelector } from 'hooks';
import { FC } from 'react';
import { setAuthModal } from 'store/ducks/system/slice';
import styles from './Wallet.module.less';

const { Title } = Typography;

export const Wallet: FC = () => {
  const dispatch = useAppDispatch();
  const { balance, loginType } = useAppSelector((state) => state.user);

  const handleTransfer = () => {
    dispatch(setAuthModal('transfer'));
  };

  return (
    <div className={styles.root}>
      <Title level={3} className="primaryText text-center">
        MY WALLET
      </Title>
      <Row justify="center" className="mb-4">
        <Col md={16} xl={10} xs={24} sm={24}>
          <Input prefix="MATIC" className={styles.input} value={balance.matic} />
        </Col>
      </Row>
      <Row justify="center" className="mb-4">
        <Col md={16} xl={10} xs={24} sm={24}>
          <Input prefix="USDC" className={styles.input} value={balance?.usdc} />
        </Col>
      </Row>
      <Row justify="center" className="mb-4">
        <Col md={16} xl={10} xs={24} sm={24}>
          <Input prefix="DMT" className={styles.input} value={balance?.token} />
        </Col>
      </Row>
      <Row justify="center" className="mb-4">
        <Col md={16} xl={10} xs={24} sm={24}>
          <Input prefix="DIG" className={styles.input} value={balance?.nft} />
        </Col>
      </Row>
      {loginType === 'email' && (
        <Row justify="center" className="mb-4">
          <Col md={16} xl={10} xs={24} sm={24}>
            <Button className="w-100" onClick={handleTransfer}>
              TRANSFER
            </Button>
          </Col>
        </Row>
      )}
    </div>
  );
};
