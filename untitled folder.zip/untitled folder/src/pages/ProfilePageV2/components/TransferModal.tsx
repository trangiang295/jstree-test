import { FC, useEffect, useMemo, useState } from 'react';
import styles from './Wallet.module.less';
import { Form, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Modal } from 'components/Modal';
import { useAppDispatch, useAppSelector } from 'hooks';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { Input, InputNumber } from 'components/Input';
import { message } from 'utils/message';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';
import { useContractProvider } from 'hooks/useContract';
import { useParams } from 'react-router-dom';
import { sendEmailCode, useGetUserInfo } from 'api/account';
import { Select } from 'components/Select';
import { CONTRACT_ADDRESS } from 'utils/constant';
import { getAuthModal, setAuthModal } from 'store/ducks/system/slice';
import { setWithDrawRequest } from 'store/ducks/nft/slice';
import BigNumber from 'bignumber.js';
import { getBalance } from 'store/ducks/user/slice';
import { getStatusPrice } from 'utils/common';

const { Title } = Typography;
const { Option } = Select;

const LIST_TOKEN = [
  { value: CONTRACT_ADDRESS.USDC, title: 'USDC' },
  { value: CONTRACT_ADDRESS.TOKEN, title: 'DMT' },
];

export const TransferModal: FC = () => {
  const state = useAppSelector(getAuthModal);
  const [form] = Form.useForm();
  const dispatch = useAppDispatch();
  const [txid, setTxid] = useState('');
  const { data: userInfo } = useGetUserInfo();
  const balance = useAppSelector(getBalance);

  const { id } = useParams<{ id: string }>();

  const visible = useMemo(() => state === 'transfer', [state]);
  const loadingGetTransaction = useContractProvider(txid);

  useEffect(() => {
    form.resetFields();
    setTxid('');
    reset();
  }, [visible]);

  const handleClose = () => {
    dispatch(setAuthModal(null));
  };

  const {
    mutate: mutatePostWalletSystem,
    status: statusPostWalletSystem,
    reset,
  } = useMutation(postMethod, {
    onSuccess: (data) => {
      if (data?.status !== 'failed') {
        setTxid(data?.txid);
      } else {
        message.error('Invalid');
      }
    },

    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const onFinish = async (value: any) => {
    const bigNumber = new BigNumber(value.price).multipliedBy(10 ** 18);

    const request: IWalletSystemRequest = {
      method: 'withDrawToken',
      currency: 'polygon',
      data: [value.paymentToken, `${bigNumber.toPrecision(bigNumber.e ? bigNumber.e + 1 : 0)}`, value.toAddress],
    };

    const token = value.paymentToken === CONTRACT_ADDRESS.TOKEN ? 'DMT' : 'USDC';

    if (!userInfo?.isActiveEmailCode && !userInfo?.isActive2fa) {
      if (!getStatusPrice(token === 'DMT' ? balance.token : balance.usdc, value.price)) {
        message.info(`Lack of ${token}`);
        return;
      }
      mutatePostWalletSystem(request);
    } else {
      if (userInfo.isActiveEmailCode) {
        await mutateSendEmailCode();
      }
      dispatch(setWithDrawRequest({ ...request, price: value.price }));
      dispatch(setAuthModal('verify'));
    }
  };

  const { mutateAsync: mutateSendEmailCode } = useMutation(sendEmailCode, {
    onSuccess: () => {
      message.success('An email has been sent to your mail');
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  useEffect(() => {
    if (statusPostWalletSystem === 'success' && !loadingGetTransaction) {
      message.success('Successfully');
      window.location.reload();
    }
  }, [statusPostWalletSystem, loadingGetTransaction]);

  return (
    <Modal visible={visible} onCancel={handleClose}>
      <div className={clsx(styles.root)}>
        <Title level={3} className="text-center">
          Transfer Token
        </Title>
        <Form layout="vertical" onFinish={onFinish} form={form} validateTrigger="onBlur">
          <Form.Item label="Address" name="toAddress" rules={[{ required: true }]}>
            <Input placeholder={'Enter to address'} />
          </Form.Item>
          <Form.Item label="Transfer price" name="price" rules={[{ required: true }]}>
            <InputNumber placeholder="Transfer price" />
          </Form.Item>
          <Form.Item label="Payment tokens" name="paymentToken" rules={[{ required: id ? false : true }]}>
            <Select placeholder="Choose your token">
              {LIST_TOKEN.map((item, index) => (
                <Option key={index} value={item.value}>
                  {item.title}
                </Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item>
            <Button
              loading={(txid !== '' && loadingGetTransaction) || statusPostWalletSystem === 'loading'}
              className="w-100"
              htmlType="submit"
            >
              Transfer
            </Button>
          </Form.Item>
        </Form>
      </div>
    </Modal>
  );
};
