import clsx from 'clsx';
import { FC } from 'react';
import styles from './styles.module.less';
import { NewsLetter } from 'components/NewsLetter';
import { Account } from './components/Account';
import { Menu } from './components/Menu';
import { Wallet } from './components/Wallet';
import { Google2FA } from './components/Google2FA';
import { useLocation } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';
import { EmailActiveCode } from './components/EmailActiveCode';
import { TransferModal } from './components/TransferModal';
const Profile: FC = () => {
  const { pathname } = useLocation<{ pathname: string }>();

  return (
    <div>
      <div className={clsx(styles.root, 'container-fluid')}>
        <div className={clsx(styles.content, 'container')}>
          <Menu />
          <div className={styles.tabContent}>
            {pathname === routesEnum.profile && <Account />}
            {pathname === routesEnum.wallet && <Wallet />}
            {pathname === routesEnum.google2fa && <Google2FA />}
            {pathname === routesEnum.emailActiveCode && <EmailActiveCode />}
          </div>
        </div>
      </div>
      <NewsLetter />
      <TransferModal />
    </div>
  );
};

export default Profile;
