import { Button } from 'components/Button';
import { useHistory } from 'react-router-dom';
import styles from './styles.module.less';
import { Result } from 'antd';
import { routesEnum } from 'pages/Routes';
import clsx from 'clsx';

export const NotFoundPage = () => {
  const history = useHistory();
  return (
    <div className={clsx(styles.root, 'container pb-5')}>
      <div className={styles.content}>
        <Result
          status="500"
          title="500"
          subTitle="Sorry, Something went wrong"
          extra={<Button onClick={() => history.push(routesEnum.home)}>Back Home</Button>}
        />
      </div>
    </div>
  );
};
