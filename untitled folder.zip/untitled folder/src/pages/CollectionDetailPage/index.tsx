import { FC } from 'react';
import styles from './styles.module.less';
import { Info } from './components/Info';
// import { FAQ } from 'components/FAQ';
import { Col, Empty, Row } from 'antd';
import { HeaderTitle } from 'components/HeaderTitle';
import { NFTCard } from 'components/NFTCard';
import { useHistory, useParams } from 'react-router-dom';
import clsx from 'clsx';
import { useGetListNFT } from 'api/nft';
import { Pagination } from 'components/Pagination';
import { usePathQuery } from 'hooks/usePathQuery';
import { convertName } from 'utils/common';

const CollectionDetailPage: FC = () => {
  const history = useHistory();
  const { id } = useParams<{ id: string }>();
  const query = usePathQuery();

  const onChangePage = (current: number) => {
    history.push(`/collection/${id}?page=${current}`);
  };

  const { data } = useGetListNFT({
    collectionId: id,
    page: query.get('page') ? Number(query.get('page')) : 1,
    limit: 10,
  });

  return (
    <div className="container-fluid">
      <div className={clsx(styles.root, 'container')}>
        <Info />

        <>
          <div className="my-4">
            <HeaderTitle title="EXPLORE OTHER EDITIONS ON VERDANT MARKETPLACE" />
            {data && data?.list.length > 0 ? (
              <Row gutter={[16, 16]} justify="start">
                {data?.list.map((item, index) => (
                  <Col key={index} xs={24} md={8} xl={6} sm={12} className={styles.customCol}>
                    <NFTCard
                      image={item.image_url}
                      name={item.name}
                      price={item.price}
                      id={item.token_id}
                      edition={item?.edition || '-'}
                      owner={convertName(item)}
                      ownerAddress={item.human_owner}
                      brand="Blank"
                      onClick={() => history.push(`/nft-detail/${item.token_id}`)}
                      type={item.image_type}
                    />
                  </Col>
                ))}
              </Row>
            ) : (
              <Empty />
            )}
          </div>
          <Pagination
            className={styles.pagination}
            onChange={onChangePage}
            current={Number(data?.pagination?.currentPage || 1)}
            pageSize={data?.pagination?.itemsPerPage || 10}
            total={data?.pagination?.totalItems || 10}
          />
        </>
      </div>
    </div>
  );
};

export default CollectionDetailPage;
