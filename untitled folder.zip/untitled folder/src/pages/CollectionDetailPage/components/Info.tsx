import { FC } from 'react';
import styles from './Info.module.less';
import { Descriptions, Typography } from 'antd';
import clsx from 'clsx';
import { useParams } from 'react-router-dom';
import { useGetCollectionDetail } from 'api/collection';
import { LoadingFullpage } from 'components/Loading';

const { Title } = Typography;

export const Info: FC = () => {
  const { id } = useParams<{ id: string }>();
  const { data: dataCollection, status } = useGetCollectionDetail(id);

  if (status === 'loading') {
    return <LoadingFullpage />;
  }

  return (
    <div className={clsx(styles.root, 'container mb-5')}>
      <div className={styles.info}>
        <div>
          <Title level={1} className={styles.title}>
            {dataCollection?.name}
          </Title>
          <div
            className={clsx(styles.description, 'text-justify')}
            dangerouslySetInnerHTML={{ __html: dataCollection?.description || '' }}
          />
        </div>
        <div className="mt-3">
          <Descriptions layout="vertical">
            <Descriptions.Item label="OWNER NAME">{dataCollection?.ownerName}</Descriptions.Item>
            <Descriptions.Item label="PAYMENT TOKEN">{dataCollection?.paymentToken}</Descriptions.Item>
            <Descriptions.Item label="OWNER ID">{dataCollection?.ownerId}</Descriptions.Item>
          </Descriptions>
        </div>
      </div>
      <div>
        <div
          style={{ backgroundImage: `url("${dataCollection?.imageUrl}")` }}
          className={clsx(styles.collectionImage)}
        />
      </div>
    </div>
  );
};
