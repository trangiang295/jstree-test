import { Col, Row, Typography } from 'antd';
import { FC } from 'react';
import styles from './Info.module.less';
import clsx from 'clsx';

const { Title, Paragraph } = Typography;

export const Info: FC<{ brand_name?: string; description?: string; description_url?: string }> = ({
  brand_name,
  description,
  description_url,
}) => {
  return (
    <div className={clsx(styles.root, 'px-md-0 px-4')}>
      <Row align="middle" gutter={[24, 24]}>
        <Col md={12} xs={24} sm={24} lg={12}>
          <Title>{brand_name}</Title>
          <Paragraph>{description}</Paragraph>
        </Col>
        <Col
          className={styles.backgroundBrands}
          md={12}
          xs={24}
          sm={24}
          lg={12}
          style={{ backgroundImage: `url("${description_url}")` }}
        ></Col>
      </Row>
    </div>
  );
};
