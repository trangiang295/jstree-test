import clsx from 'clsx';
import { FC } from 'react';
import styles from './styles.module.less';
import { NewsLetter } from 'components/NewsLetter';
import { Info } from './components/Info';
import { HeaderTitle } from 'components/HeaderTitle';
import { Col, Empty, Row } from 'antd';
import { useHistory, useParams } from 'react-router-dom';
import { useGetBrandDetail } from 'api/brands';
import { LoadingFullpage } from 'components/Loading';
import { CollectionCard } from 'components/CollectionCard';

const BrandDetailPage: FC = () => {
  const { id } = useParams<{ id: string }>();
  const { data: brand } = useGetBrandDetail(id);

  const history = useHistory();

  if (!brand) {
    return <LoadingFullpage />;
  }

  return (
    <div className={clsx('container-fluid', styles.root)}>
      <div className={clsx('container', styles.content)}>
        <Info
          description={brand?.description}
          description_url={brand?.description_url}
          brand_name={brand?.brand_name}
        />
        <HeaderTitle title="EXPLORE EDITIONS ON VERDANT MARKETPLACE" />
        {brand?.collections && brand?.collections.length > 0 ? (
          <Row gutter={[16, 16]} justify="start">
            {brand?.collections.map((item, index) => (
              <Col key={index} xxl={6} md={8} xs={24} sm={12}>
                <CollectionCard
                  image={item.image_url}
                  name={item.name}
                  owner={brand?.brand_name}
                  description={item.description}
                  onClick={() => history.push(`/collection/${item.id}`)}
                />
              </Col>
            ))}
          </Row>
        ) : (
          <Empty />
        )}
      </div>

      <NewsLetter />
    </div>
  );
};

export default BrandDetailPage;
