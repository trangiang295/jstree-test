import { Menu } from 'antd';
import clsx from 'clsx';
import { FC } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { CollectionSearch } from './components/CollectionSearch';
import { NftSearch } from './components/NftSearch';
import styles from './styles.module.less';

const SearchPage: FC = () => {
  const { key, tab } = useParams<{ key: string; tab: string }>();
  const history = useHistory();
  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <div className="container">
        <Menu mode="horizontal" className={styles.menu} selectedKeys={[tab]}>
          <Menu.Item key="nft" onClick={() => history.push(`/search/nft/${key ? key : ''}`)}>
            <strong>NFT</strong>
          </Menu.Item>
          <Menu.Item key="collection" onClick={() => history.push(`/search/collection/${key ? key : ''}`)}>
            <strong>Collection</strong>
          </Menu.Item>
        </Menu>
        {tab === 'nft' && <NftSearch />}
        {tab === 'collection' && <CollectionSearch />}
      </div>
    </div>
  );
};

export default SearchPage;
