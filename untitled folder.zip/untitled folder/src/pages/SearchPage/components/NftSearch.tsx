import { Col, Empty, Row } from 'antd';
import { useGetListNFT } from 'api/nft';
import { NFTCard } from 'components/NFTCard';
import { Pagination } from 'components/Pagination';
import { usePathQuery } from 'hooks/usePathQuery';
import { FC } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { convertName } from 'utils/common';
import styles from './styles.module.less';

export const NftSearch: FC = () => {
  const { key, tab } = useParams<{ key: string; tab: string }>();
  const history = useHistory();
  const query = usePathQuery();

  const { data: nfts } = useGetListNFT(
    { name: key, page: query.get('page') ? Number(query.get('page')) : 1, limit: 8 },
    { enabled: !!(tab === 'nft') }
  );

  const onChangePage = (current: number) => {
    history.push(`/search/${tab}/${key || ''}?page=${current}`);
  };
  if (nfts && nfts.list.length > 0)
    return (
      <div className={styles.root}>
        <Row gutter={[16, 16]} justify="start">
          {nfts?.list.map((item, index) => (
            <Col key={index} md={12} xs={24} xl={6} sm={12}>
              <NFTCard
                image={item.image_url}
                name={item.name}
                price={item.price}
                id={item.token_id}
                edition={item?.edition || '-'}
                owner={convertName(item)}
                ownerAddress={item.human_owner}
                brand="Blank"
                type={item.image_type}
                onClick={() => history.push(`/nft-detail/${item.token_id}`)}
              />
            </Col>
          ))}
        </Row>
        <Pagination
          className={styles.pagination}
          onChange={onChangePage}
          current={Number(nfts?.pagination?.currentPage || 1)}
          pageSize={nfts?.pagination?.itemsPerPage || 8}
          total={nfts?.pagination?.totalItems || 8}
        />
      </div>
    );
  return <Empty />;
};
