import { Col, Empty, Row } from 'antd';
import { useGetListCollection } from 'api/collection';
import { CollectionCard } from 'components/CollectionCard';
import { Pagination } from 'components/Pagination';
import { usePathQuery } from 'hooks/usePathQuery';
import { FC } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { convertName } from 'utils/common';
import styles from './styles.module.less';

export const CollectionSearch: FC = () => {
  const { key, tab } = useParams<{ key: string; tab: string }>();
  const history = useHistory();
  const query = usePathQuery();

  const { data: collections } = useGetListCollection(
    { name: key, page: query.get('page') ? Number(query.get('page')) : 1, limit: 8 },
    { enabled: !!(tab === 'collection') }
  );

  const onChangePage = (current: number) => {
    history.push(`/search/${tab}/${key || ''}?page=${current}`);
  };

  if (collections && collections.list.length > 0)
    return (
      <div className={styles.root}>
        <Row gutter={[16, 16]}>
          {collections?.list.map((collection: any, index: number) => (
            <Col key={index} md={12} xs={24} xl={6} sm={12}>
              <CollectionCard
                image={collection.imageUrl}
                name={collection.name}
                owner={convertName(collection)}
                description={collection.description}
                onClick={() => history.push(`/collection/${collection.id}`)}
              />
            </Col>
          ))}
        </Row>
        <Pagination
          className={styles.pagination}
          onChange={onChangePage}
          current={Number(collections?.pagination?.currentPage || 1)}
          pageSize={collections?.pagination?.itemsPerPage || 8}
          total={collections?.pagination?.totalItems || 8}
        />
      </div>
    );
  return <Empty />;
};
