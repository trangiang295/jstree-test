import clsx from 'clsx';
import { HeaderTitle } from 'components/HeaderTitle';
import { FC } from 'react';
import styles from './styles.module.less';
import { Typography } from 'antd';

const { Paragraph } = Typography;

const PrivacyPage: FC = () => {
  return (
    <div className={clsx('container-fluid', styles.root)}>
      <div className={clsx('container', styles.content)}>
        <HeaderTitle title="PRIVACY POLICY" notShowDivider description="Last Updated: Oct 12, 2021" />
        <Paragraph strong className={styles.title}>
          Introduction
        </Paragraph>
        <Paragraph>
          Verdant NFT(“VNFT”, “we” or “us”) takes the privacy of your information seriously. This Privacy Policy applies
          to the verdantnft.com website (the “Website”) and governs data collection, processing and usage in compliance
          with the Personal Data Protection Act 2012 (No. 26 of 2012) of Singapore (“PDPA”). By using the Website, you
          consent to the data practices described in this statement. Capitalized terms that are not defined in this
          Privacy Policy have the meaning given to them in our Terms of Service.
        </Paragraph>
        <Paragraph>Information Collected from All Visitors to our Website</Paragraph>
        <Paragraph>
          We will obtain personal data about you when you visit us. When you visit us, we may monitor the use of this
          Website through the use of cookies and similar tracking devices. For example, we may monitor the number of
          times you visit our Website or which pages you go to. This information helps us to build a profile of our
          users. Some of this data will be aggregated or statistical, which means that we will not be able to identify
          you individually.
        </Paragraph>
        <Paragraph>This Privacy Policy applies to all visitors to our Website.</Paragraph>
        <Paragraph strong className={styles.title}>
          Additional Personal Information that May be Collected
        </Paragraph>
        <Paragraph>VNFT may collect and process:</Paragraph>
        <Paragraph>1. Personally identifiable information, such as:</Paragraph>
        <Paragraph>2. Your e-mail address and name, when you contact us;</Paragraph>
        <Paragraph>3. Details contained in the relevant document that you key in when you use our Services. </Paragraph>
        <Paragraph>
          These details may include your name, handphone number, email, the purpose of your query, and details about
          your will; (“Personal Information”)
        </Paragraph>
        <Paragraph>
          4. Information about your computer hardware and software when you use our Website. The information can
          include: your IP address, browser type, domain names, access times and referring website addresses. This
          information is used by VNFT for the operation of the Services, to maintain quality of the Services, and to
          provide general statistics regarding the use of the verdantnft.com Website.
        </Paragraph>
        <Paragraph>Use of Personal Information</Paragraph>
        <Paragraph>VNFT uses the collected information:</Paragraph>
        <Paragraph>1. To operate the Website and deliver the Services;</Paragraph>
        <Paragraph>2. To process, and where necessary, respond to your application, enquiry or request;</Paragraph>
        <Paragraph>3. To gather customer feedback;</Paragraph>
        <Paragraph>
          4. To inform or update you of other products or services available from VNFT and its affiliates, where you
          have consented to be contacted for such purposes;
        </Paragraph>
        <Paragraph>
          5. To monitor, improve and administer the Website and Services, and to provide general statistics regarding
          users of the Website;
        </Paragraph>
        <Paragraph>6. To update you on changes to the Website and Services.</Paragraph>
        <Paragraph strong className={styles.title}>
          Non-disclosure
        </Paragraph>
        <Paragraph>
          VNFT does not sell, rent, lease, or release your Personal Information to third parties. VNFT may, from time to
          time, contact you on behalf of external business partners about a particular offering that may be of interest
          to you. In those cases, your unique Personal Information is not transferred to the third party without your
          explicit consent. In addition, VNFT may share data with trusted partners to help us perform statistical
          analysis, send you email or provide customer support. All such third parties are prohibited from using your
          personal information except to provide these services to VNFT, and they are required to maintain the
          confidentiality of your Personal Information.
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Disclosure of Personal Information
        </Paragraph>
        <Paragraph>
          VNFT will disclose or share your Personal Information, without notice, only if required to do so by law or in
          the good faith belief that any such action is necessary to: (a) comply with any legal requirements or comply
          with the legal process served on VNFT or the Website; (b) protect and defend the rights or property of VNFT;
          and (c) act under exigent circumstances to protect the personal safety of users of verdantnft.com, or the
          general public.
        </Paragraph>
        <Paragraph>
          We may disclose your personal information to third parties: (a) in the event that we sell or buy any business
          or assets, in which case we may disclose your personal data to the prospective seller or buyer of such
          business or assets; and (b) if verdantnft.com or substantially all of its assets are acquired by a third
          party, in which case personal data held by it about its customers will be one of the transferred assets.
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Use Of Cookies
        </Paragraph>
        <Paragraph>
          The Website uses “cookies” to help you personalize your online experience. A cookie is a text file that is
          placed on your hard drive by a web page server. Cookies cannot be used to run programs or deliver viruses to
          your computer. Cookies are uniquely assigned to you, and can only be read by a web server in the domain that
          issued the cookie to you.
        </Paragraph>
        <Paragraph>
          Cookies on the Website may be used to ensure a smooth user experience, perform analytics, and for showing
          relevant advertisements. Please note that third parties (such as analytics software) may also use cookies,
          over which we have no control. These cookies are likely to be analytical/performance cookies or targeting
          cookies. The Website uses Google Analytics. Please refer to http://www.google.com/policies/privacy/partners to
          find out more about how Google uses data when you use our website and how to control the information sent to
          Google.
        </Paragraph>
        <Paragraph>
          Most Web browsers automatically accept cookies, but you can usually modify your browser setting to decline
          cookies if you prefer. If you choose to decline cookies, you may not be able to access all or parts of our
          Website or to fully experience the interactive features of the VNFT services or websites you visit.
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Security Of Your Personal Information
        </Paragraph>
        <Paragraph>
          We strive to maintain the safety of your Personal Information. Any payment transactions will be encrypted
          using SSL technology. Unfortunately, no internet-based service is completely secure. Although we will do our
          best to protect your personal data, we cannot guarantee the security of your data transmitted to our site; any
          transmission is at your own risk. Once we have received your information, we will use strict procedures and
          security features to try to prevent unauthorized access.
        </Paragraph>
        <Paragraph>Access to, Updating, and Non-Use of Your Personal Information</Paragraph>
        <Paragraph>
          Subject to the exceptions referred to in section 21(2) of PDPA, you have the right to request a copy of the
          information that we hold about you. If you would like a copy of some or all of your personal information,
          please send an email to info@verdantnft.com. We may make a small charge for this service.
        </Paragraph>
        <Paragraph>
          We want to ensure that your Personal Information is accurate and up to date. If any of the information that
          you have provided to VNFT changes, for example if you change your email address, name or contact number,
          please let us know the correct details by sending an email to info@verdantnft.com. You may ask us, or we may
          ask you, to correct information you or we think is inaccurate, and you may also ask us to remove information
          that is inaccurate.
        </Paragraph>
        <Paragraph>
          You have the right to ask us not to collect, use, process, or disclose your Personal Information in any of the
          manners described herein. We will usually inform you (before collecting your Personal Information) if we
          intend to use your Personal Information for such purposes or if we intend to disclose your Personal
          Information to any third party for such purposes. You can give us notice of your intention to halt the
          collection, use, processing, or disclosure of your Personal Information at any time by contacting us at
          info@verdantnft.com.
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Links to Other Websites
        </Paragraph>
        <Paragraph>
          Our Website may contain links to other websites. This Privacy Policy only applies to this website so when you
          link to other websites you should read their own privacy policies.
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Changes To This Statement
        </Paragraph>
        <Paragraph>
          VNFT will occasionally update this Privacy Policy to reflect customer feedback. VNFT encourages you to
          periodically review this Privacy Policy to be informed of how VNFT is protecting your information.
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Contact Information
        </Paragraph>
        <Paragraph>
          First World Problems Pte. Ltd. welcomes your comments regarding this Privacy Policy. If you believe that
          verdantnft.com has not adhered to this Privacy Policy, please contact us at info@verdantnft.com.
        </Paragraph>
        <Paragraph>(Last updated in January, 2022)</Paragraph>
      </div>
    </div>
  );
};

export default PrivacyPage;
