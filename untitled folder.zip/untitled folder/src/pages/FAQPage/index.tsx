import { Col, Row, Skeleton, Typography } from 'antd';
import clsx from 'clsx';
import { HeaderTitle } from 'components/HeaderTitle';
import { FC } from 'react';
import styles from './styles.module.less';
import { Link, useHistory, useParams } from 'react-router-dom';
import { Button } from 'components/Button';
import { Collapse } from 'components/Collapse';
import { NewsLetter } from 'components/NewsLetter';
import { routesEnum } from 'pages/Routes';
import { useGetCategoryFAQ, useGetListCategoryById } from 'api/faq';

const { Paragraph } = Typography;

const FAQPage: FC = () => {
  const { key } = useParams<{ key: string }>();

  const history = useHistory();
  const { data: category } = useGetCategoryFAQ({ page: 1, limit: 20 });
  const { data: categories, isLoading } = useGetListCategoryById({
    id: key || category?.list[0].id?.toString() || '',
    page: 1,
    limit: 20,
  });

  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <div className="container">
        <HeaderTitle title="FAQs" className="mt-5 mb-0" notShowDivider />
        <Paragraph className="text-center">
          Search for answers or
          <Link to={'/'}>
            <strong> Contact Support</strong>
          </Link>
        </Paragraph>
        <Row className="container">
          <Col span={24} className="d-flex justify-content-center flex-wrap">
            {category?.list.map((item, index) => (
              <Button
                onClick={() => history.push(`${routesEnum.faq}/${item.id}`)}
                key={item.id}
                className={clsx('mb-4 me-3', item.id === Number(key) || (!key && index === 0) ? 'customBtnCommon' : '')}
              >
                {item.categoryName}
              </Button>
            ))}
          </Col>
          <Col span={24}>
            {isLoading ? <Skeleton /> : <Collapse data={categories?.list || []} className="mw-100" />}
          </Col>
        </Row>
      </div>
      <NewsLetter />
    </div>
  );
};

export default FAQPage;
