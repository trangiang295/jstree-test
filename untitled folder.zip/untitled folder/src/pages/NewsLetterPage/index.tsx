import clsx from 'clsx';
import { HeaderTitle } from 'components/HeaderTitle';
import { FC } from 'react';
import styles from './styles.module.less';
import { Typography } from 'antd';
import { NewsLetter } from 'components/NewsLetter';

const { Paragraph } = Typography;

const NewsLetterPage: FC = () => {
  return (
    <div className={clsx('container-fluid', styles.root)}>
      <div className={clsx('container', styles.content)}>
        <HeaderTitle className="mb-0" title="NEWSLETTER" notShowDivider description="KEEP ME UPDATED" />
        <Paragraph className="text-center">
          Sign up to our newsletter and stay up to date with the latest Verdant news
        </Paragraph>
      </div>
      <NewsLetter />
    </div>
  );
};

export default NewsLetterPage;
