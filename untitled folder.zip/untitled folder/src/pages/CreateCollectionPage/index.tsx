import { Form, Select as AntdSelect, Tooltip, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { HeaderTitle } from 'components/HeaderTitle';
import { Input, InputTextArea } from 'components/Input';
import { Select } from 'components/Select';
import { FC, useEffect, useState } from 'react';
import styles from './styles.module.less';
import { AiOutlineQuestionCircle } from 'react-icons/ai';
import { createCollection, useGetCollectionDetail, updateCollection } from 'api/collection';
import { IError } from 'api/types';
import { useMutation } from 'react-query';
import { useHistory, useParams } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';
import { convertToFormData } from 'api/axios';
import { message } from 'utils/message';
import { Upload } from 'components/Upload';
import { configForm } from 'utils/form';
import { useGetUserInfo } from 'api/account';
import { NotFoundPage } from 'pages/NotFoundPage.tsx';
import { useGetListBrands, useGetListCategory } from 'api/brands';
const { Option } = AntdSelect;
const { Paragraph } = Typography;

const LIST_TOKEN = [{ value: 'matic', title: 'MATIC' }];

const CreateCollection: FC = () => {
  const [statusUpload, setStatusUpload] = useState(false);
  const { data: userInfo } = useGetUserInfo();
  const { data: brands } = useGetListBrands({ page: 1, limit: 100 });
  const { data: categories } = useGetListCategory({ page: 1, limit: 100 });

  const { id } = useParams<{ id: string }>();
  const history = useHistory();
  const { data: dataCollection } = useGetCollectionDetail(id, { enabled: !!id });
  const [form] = Form.useForm();

  useEffect(() => {
    if (dataCollection) {
      form.setFieldsValue({
        ...dataCollection,
        image: dataCollection.imageUrl,
      });
    } else {
      form.resetFields();
    }
  }, [dataCollection]);

  const handleChange = (file: File) => {
    form.setFieldsValue({ image: file });
  };

  const onFinish = (value: any) => {
    let request = {
      ...value,
      image: value.image,
      brandId: userInfo?.brandId,
    };

    if (id) {
      request = { id, ...request };
    }

    const action = id ? mutateUpdateCollection : mutateCreateCollection;

    action(convertToFormData(request));
  };

  const { mutate: mutateCreateCollection, status: statusCreateCollection } = useMutation(createCollection, {
    onSuccess: () => {
      message.success('Create collection successfully');
      history.push(routesEnum.listCollection);
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const { mutate: mutateUpdateCollection, status: statusUpdateCollection } = useMutation(updateCollection, {
    onSuccess: () => {
      message.success('Update collection successfully');
      history.push(routesEnum.listCollection);
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  if (userInfo?.brandId === null) {
    return <NotFoundPage />;
  }

  return (
    <div className={clsx(styles.root, 'container pb-5')}>
      <div className={styles.content}>
        <HeaderTitle notShowDivider title="Create New Collection" className="text-start align-items-start mb-4" />
        <Form layout="vertical" onFinish={onFinish} validateTrigger="onBlur" form={form}>
          <Paragraph strong className={styles.title}>
            Image, Video, Audio, or 3D Model *
          </Paragraph>
          <Paragraph className={styles.text}>File types supported: JPG, PNG, GIF, MP4. Max size: 100MB</Paragraph>
          <Form.Item
            name="image"
            label="Image"
            rules={[
              {
                required: true,
                message: statusUpload
                  ? `Image must smaller than ${configForm.maxImageFileSize}MB!`
                  : 'Image is required!',
              },
            ]}
          >
            <Upload
              listType="picture-card"
              onChangeFile={handleChange}
              imageUrl={dataCollection?.imageUrl}
              onSubmitFailUpload={setStatusUpload}
            />
          </Form.Item>
          <Paragraph strong className={styles.title}>
            Name *
          </Paragraph>
          <Form.Item label="Name Collection" name="name" rules={[{ required: true }]}>
            <Input placeholder="Collection name" maxLength={255} />
          </Form.Item>
          <Paragraph strong className={styles.title}>
            Description
          </Paragraph>
          <Paragraph className={styles.text}>
            The description will be included on the item&apos;s detail page underneath its image.
          </Paragraph>
          <Form.Item label="Description" name="description">
            <InputTextArea placeholder="Provide a detailed description of your collection. " maxLength={5000} />
          </Form.Item>

          <Paragraph className={clsx(styles.text, 'mb-4')}>
            <strong>Blockchain</strong>
            <br />
            <div className="d-flex align-items-center">
              The blockchain we use is Polygon
              <Tooltip placement="top" title="A fast, gas-free blockchain experience that works with Ethereum.">
                <AiOutlineQuestionCircle size={16} className="ms-1" />
              </Tooltip>
            </div>
          </Paragraph>
          <Paragraph strong className={styles.title}>
            Payment tokens *
          </Paragraph>
          <Paragraph className={styles.text}>These tokens can be used to buy your items.</Paragraph>
          <Form.Item label="Payment tokens" name="paymentToken" rules={[{ required: id ? false : true }]}>
            <Select placeholder="Choose your token">
              {LIST_TOKEN.map((item, index) => (
                <Option key={index} value={item.value}>
                  {item.title}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Paragraph strong className={styles.title}>
            Brand *
          </Paragraph>
          <Form.Item label="Brand" name="brandId" rules={[{ required: id ? false : true }]}>
            <Select placeholder="Choose your token">
              {brands?.list.map((item, index) => (
                <Option key={index} value={item.id}>
                  {item.brandName}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Paragraph strong className={styles.title}>
            Category *
          </Paragraph>
          <Form.Item label="Brand" name="categoryId" rules={[{ required: id ? false : true }]}>
            <Select placeholder="Choose your token">
              {categories?.list.map((item, index) => (
                <Option key={index} value={item.id}>
                  {item.categoryName}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item>
            <Button
              loading={(id && statusUpdateCollection === 'loading') || (!id && statusCreateCollection === 'loading')}
              htmlType="submit"
            >
              {!id ? 'Create Collection' : 'Update Collection'}
            </Button>
          </Form.Item>
        </Form>
      </div>
    </div>
  );
};

export default CreateCollection;
