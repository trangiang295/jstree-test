import { Col, Row, Typography } from 'antd';
import { useGetUserInfo } from 'api/account';
import { useGetNFT } from 'api/nft';
import clsx from 'clsx';
import { LoadingFullpage } from 'components/Loading';
import { Video } from 'components/Media';
import { NotFoundPage } from 'pages/NotFoundPage.tsx';
import { FC } from 'react';
import { useParams } from 'react-router-dom';
import { convertName } from 'utils/common';
import { MakeOffer } from './components/MakeOffer';
import { Summary } from './components/Summary';
import styles from './styles.module.less';

const { Paragraph, Title } = Typography;

const BuyNFTPage: FC = () => {
  const { tab, id } = useParams<{ id: string; tab: string }>();
  const { data: dataNFT, status } = useGetNFT(id);
  const { data: userInfo } = useGetUserInfo();

  if (status === 'loading') {
    return <LoadingFullpage />;
  }

  if (!userInfo || userInfo?.brandId !== null) {
    return <NotFoundPage />;
  }

  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <div className="container">
        <Row gutter={24}>
          <Col className="px-xl-5 px-4" xs={24} md={10} xxl={6}>
            {dataNFT?.image_type === 'video/mp4' ? (
              <Video src={dataNFT?.image_url || ''} className={styles.image} />
            ) : (
              <div style={{ backgroundImage: `url("${dataNFT?.image_url}")` }} className={styles.image} />
            )}
            <Title level={3} className="mt-3">
              {dataNFT?.name}
            </Title>
            <Paragraph>
              Owner by <strong className={styles.priceText}>@{convertName(dataNFT)}</strong>
            </Paragraph>
            <Paragraph>
              <strong>DESCRIPTION</strong>
            </Paragraph>
            <Paragraph>{dataNFT?.description}</Paragraph>
          </Col>
          <Col className="ps-xl-4 ps-md-3" md={14} xxl={18} xs={24}>
            {tab === 'summary' && <Summary />}
            {tab === 'make-offer' && <MakeOffer />}
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default BuyNFTPage;
