import { Form, Space, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { InputNumber } from 'components/Input';
import { FC, useEffect, useMemo, useState } from 'react';
import styles from './MakeOffer.module.less';
import { Select } from 'components/Select';
import MarketABI from 'contracts/MarketABI.json';
import USDCABI from 'contracts/USDCABI.json';
import { APPROVE_AMOUNT, CONTRACT_ADDRESS, COMMON_DATA, PRICE } from 'utils/constant';
import { useContractFunction, useEthers, useTokenAllowance } from '@usedapp/core';
import { useConnectABI } from 'hooks/useConnectABI';
import { formatUnits } from 'ethers/lib/utils';
import { useHistory, useParams } from 'react-router-dom';
import { getTimeOffer } from 'utils/time';
import { checkLogin, getLoadingBtn, getStatusPrice } from 'utils/common';
import { message } from 'utils/message';
import { useMutation } from 'react-query';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';
import { IError } from 'api/types';
import { useAppSelector } from 'hooks';
import { getBalance, getLoginType, getWallet } from 'store/ducks/user/slice';
import BigNumber from 'bignumber.js';
import { useContractProvider } from 'hooks/useContract';
import { useGetNFT } from 'api/nft';

const { Title, Paragraph } = Typography;
const { Option } = Select;

export const MakeOffer: FC = () => {
  const [txid, setTxid] = useState('');
  const [loading, setLoading] = useState(false);

  const { id } = useParams<{ id: string }>();
  const { data: dataNFT } = useGetNFT(id);

  const { account, active } = useEthers();
  const loginType = useAppSelector(getLoginType);
  const wallet = useAppSelector(getWallet);
  const tokenAllowance = useTokenAllowance(CONTRACT_ADDRESS.USDC, account, CONTRACT_ADDRESS.MARKET);
  const balance = useAppSelector(getBalance);

  const history = useHistory();

  const loadingGetTransaction = useContractProvider(txid);

  const allowance: number | undefined = useMemo(() => {
    if (tokenAllowance === undefined) {
      return undefined;
    }

    return Number(formatUnits(tokenAllowance || 0, 18));
  }, [tokenAllowance]);

  const onFinish = (value: any) => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }

    if (dataNFT?.human_owner === wallet) {
      message.info('Cannot make your offer');
      return;
    }

    const bigNumber = new BigNumber(value.price).multipliedBy(10 ** 18);

    if (loginType === 'wallet') {
      setLoading(true);
      sendCreateBid(
        CONTRACT_ADDRESS.NFT,
        CONTRACT_ADDRESS.USDC,
        id,
        `${bigNumber.toPrecision(bigNumber.e ? bigNumber.e + 1 : 0)}`,
        getTimeOffer(Number(value.days))
      );
    } else if (loginType === 'email') {
      const request: IWalletSystemRequest = {
        method: 'createBid',
        currency: 'polygon',
        data: [
          CONTRACT_ADDRESS.NFT,
          CONTRACT_ADDRESS.USDC,
          id,
          `${bigNumber.toPrecision(bigNumber.e ? bigNumber.e + 1 : 0)}`,
          getTimeOffer(Number(value.days)),
        ],
      };
      if (!getStatusPrice(balance.usdc, value.price)) {
        message.info(`Lack of USDC`);
        return;
      }
      setLoading(true);
      mutatePostWalletSystem(request);
    }
  };

  const { state: statusApprove, send: sendApprove } = useContractFunction(
    useConnectABI(USDCABI, CONTRACT_ADDRESS.USDC),
    'approve',
    {
      transactionName: 'wrap',
    }
  );

  const { state: statusCreateBid, send: sendCreateBid } = useContractFunction(
    useConnectABI(MarketABI, CONTRACT_ADDRESS.MARKET),
    'createBid'
  );

  const { mutate: mutatePostWalletSystem, status: statusPostWalletSystem } = useMutation(postMethod, {
    onSuccess: (data) => {
      if (data?.status !== 'failed') {
        setTxid(data?.txid);
      } else {
        setLoading(false);
        message.error('Invalid');
      }
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const getLoadingSubmit = () => {
    return (
      getLoadingBtn(statusCreateBid) ||
      statusPostWalletSystem === 'loading' ||
      loading === true ||
      (txid !== '' && loadingGetTransaction)
    );
  };

  useEffect(() => {
    if (statusPostWalletSystem === 'success' && !loadingGetTransaction) {
      setTimeout(() => {
        setTxid('');
        setLoading(false);
        message.success('Make offer successfully');
        history.push(`/nft-detail/${id}`);
      }, 5000);
    }
  }, [statusPostWalletSystem, loadingGetTransaction]);

  useEffect(() => {
    if (statusCreateBid.status === 'Success') {
      const timeOut = setTimeout(() => {
        setLoading(false);
        history.push(`/nft-detail/${id}`);
        message.success('Make offer successfully');
      }, 5000);

      return () => clearTimeout(timeOut);
    } else if (statusCreateBid.status === 'Exception' || statusCreateBid.status === 'Fail') {
      message.error(statusCreateBid?.errorMessage || 'Error');
      setLoading(false);
    }
  }, [statusCreateBid]);

  useEffect(() => {
    if (statusApprove.status === 'Exception' || statusApprove.status === 'Fail') {
      message.error(statusApprove?.errorMessage || 'Error');
    }
  }, [statusApprove]);

  const handleApprove = () => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }
    sendApprove(CONTRACT_ADDRESS.MARKET, APPROVE_AMOUNT);
  };

  return (
    <div className={clsx(styles.root, 'p-5')}>
      <Title level={3}>MAKE OFFFER</Title>
      <Paragraph>Please fill the input to make your offer</Paragraph>
      <Form layout="vertical" onFinish={onFinish}>
        <Form.Item label="Price" name="price" rules={[{ required: true }]}>
          <InputNumber placeholder="Price" min={PRICE.minSell} />
        </Form.Item>
        <Form.Item label="Expired time" name="days" rules={[{ required: true }]}>
          <Select placeholder="Expired time">
            {COMMON_DATA.listDay.map((item) => (
              <Option key={item.value} value={item.value}>
                {item.value + ' ' + item.text}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Space>
          <Form.Item>
            <Button className={styles.customBtn} onClick={() => history.go(-1)}>
              BACK
            </Button>
          </Form.Item>
          <Form.Item>
            <Button loading={getLoadingSubmit()} htmlType="submit" className={styles.customBtn}>
              CONFIRM
            </Button>
          </Form.Item>
          {account && allowance === 0 && (
            <Form.Item>
              <Button className={styles.customBtn} loading={getLoadingBtn(statusApprove)} onClick={handleApprove}>
                Approve
              </Button>
            </Form.Item>
          )}
        </Space>
      </Form>
    </div>
  );
};
