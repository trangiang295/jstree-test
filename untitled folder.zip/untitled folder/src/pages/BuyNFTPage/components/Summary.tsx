import { useContractFunction, useTokenAllowance, useEthers } from '@usedapp/core';
import { Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { useConnectABI } from 'hooks/useConnectABI';
import { FC, useEffect, useMemo } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { APPROVE_AMOUNT, CONTRACT_ADDRESS } from 'utils/constant';
import styles from './Summary.module.less';
import USDCABI from 'contracts/USDCABI.json';
import MarketABI from 'contracts/MarketABI.json';
import { formatUnits } from 'ethers/lib/utils';
import { useGetNFT } from 'api/nft';
import { routesEnum } from 'pages/Routes';
import { convertEther } from 'utils/number';
import { useAppSelector } from 'hooks';
import { checkLogin, checkPrice, getLoadingBtn } from 'utils/common';
import { message } from 'utils/message';
import { IError } from 'api/types';
import { useMutation } from 'react-query';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';
import { useState } from 'react';
import { useContractProvider } from 'hooks/useContract';
import { getBalance } from 'store/ducks/user/slice';

const { Title, Paragraph } = Typography;

export const Summary: FC = () => {
  const { id } = useParams<{ id: string }>();
  const history = useHistory();
  const { account, active } = useEthers();
  const { data: dataNFT } = useGetNFT(id);
  const { wallet, loginType } = useAppSelector((state) => state.user);
  const tokenAllowance = useTokenAllowance(CONTRACT_ADDRESS.USDC, wallet, CONTRACT_ADDRESS.MARKET);
  const [txid, setTxid] = useState('');
  const loadingGetTransaction = useContractProvider(txid);
  const [loading, setLoading] = useState(false);
  const balance = useAppSelector(getBalance);

  const allowance: number | undefined = useMemo(() => {
    if (tokenAllowance === undefined) {
      return undefined;
    }

    return Number(formatUnits(tokenAllowance || 0, 18));
  }, [tokenAllowance]);

  const { state: statusApprove, send: sendApprove } = useContractFunction(
    useConnectABI(USDCABI, CONTRACT_ADDRESS.USDC),
    'approve',
    {
      transactionName: 'wrap',
    }
  );

  const { state: statusBuy, send: sendBuy } = useContractFunction(
    useConnectABI(MarketABI, CONTRACT_ADDRESS.MARKET),
    'buy'
  );

  const { mutate: mutatePostWalletSystem, status: statusPostWalletSystem } = useMutation(postMethod, {
    onSuccess: (data) => {
      if (data?.status !== 'failed') {
        setTxid(data?.txid);
      } else {
        setLoading(false);
        checkPrice(balance.usdc, convertEther(dataNFT?.price), 'USDC', 'Invalid');
      }
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const handleBuy = () => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }
    setLoading(true);

    if (loginType === 'wallet') {
      sendBuy(dataNFT?.order_id, CONTRACT_ADDRESS.USDC);
    } else {
      const request: IWalletSystemRequest = {
        method: 'buy',
        currency: 'polygon',
        data: [dataNFT?.order_id, CONTRACT_ADDRESS.USDC],
      };
      mutatePostWalletSystem(request);
    }
  };

  useEffect(() => {
    if (statusPostWalletSystem === 'success' && !loadingGetTransaction) {
      setTimeout(() => {
        setLoading(false);
        message.success('Buy nft successfully');
        setTxid('');
        history.push(routesEnum.listNft);
      }, 5000);
    }
  }, [statusPostWalletSystem, loadingGetTransaction]);

  useEffect(() => {
    if (statusBuy.status === 'Success') {
      setLoading(false);
      message.success('Buy nft successfully');
      history.push(routesEnum.listNft);
    } else if (statusBuy.status === 'Exception' || statusBuy.status === 'Fail') {
      message.error(statusBuy?.errorMessage || 'Error');
      setLoading(false);
    }
  }, [statusBuy]);

  useEffect(() => {
    if (dataNFT && dataNFT.human_owner === wallet) {
      history.push(routesEnum.home);
    }
  }, [dataNFT]);

  useEffect(() => {
    if (statusApprove.status === 'Exception' || statusApprove.status === 'Fail') {
      message.error(statusApprove?.errorMessage || 'Error');
    }
  }, [statusApprove]);

  const handleApprove = () => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }
    sendApprove(CONTRACT_ADDRESS.MARKET, APPROVE_AMOUNT);
  };

  return (
    <div className={clsx(styles.root, 'p-xl-5 p-4')}>
      <Title level={3}>SUMMARY</Title>
      <Paragraph>Confirm the information below to buy</Paragraph>
      <Paragraph className="my-5">
        Total price: <strong className={styles.priceText}>{convertEther(dataNFT?.price)} USD</strong>
      </Paragraph>
      <Paragraph strong={true}>
        You are purchasing a digital NFT. You will need to be in full compliance of your jurisdiction to receive the
        asset.
      </Paragraph>
      <Paragraph className={styles.description}>- IP of this product remains with the Brand.</Paragraph>
      <Paragraph className={styles.description}>
        - This NFT does not represent actual ownership in the physical asset.
      </Paragraph>
      <Paragraph className={styles.description}>
        - This NFT represents right to apply for redempction of the physical asset.
      </Paragraph>
      <div className="d-flex justify-content-center mt-5">
        <Button className={styles.customBtn} onClick={() => history.go(-1)}>
          BACK
        </Button>
        <Button
          disabled={!account === false && allowance === 0}
          className={styles.customBtn}
          onClick={handleBuy}
          loading={
            getLoadingBtn(statusBuy) ||
            statusPostWalletSystem === 'loading' ||
            loading === true ||
            (txid !== '' && loadingGetTransaction)
          }
        >
          CONFIRM
        </Button>
        {loginType === 'wallet' && allowance === 0 && (
          <Button className={styles.customBtn} loading={getLoadingBtn(statusApprove)} onClick={handleApprove}>
            Approve
          </Button>
        )}
      </div>
    </div>
  );
};
