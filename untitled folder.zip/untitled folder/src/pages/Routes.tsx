import { lazy } from '@loadable/component';
import { FC, useEffect } from 'react';
import { Route, RouteProps, Switch, useLocation } from 'react-router-dom';

export enum routesEnum {
  home = '/',
  login = '/login',
  collections = '/collections',
  faq = '/faq',
  resetPassword = '/reset-password',
  setting = '/setting',
  wallet = '/wallet',
  google2fa = '/google2fa',
  changePassword = '/change-password',
  ntfDetail = '/nft-detail/:id',
  createNtf = '/create-nft',
  listCollection = '/list-collection',
  listNft = '/list-nft',
  createCollection = '/create-collection',
  editNft = '/edit-nft/:id',
  editCollection = '/edit-collection/:id',
  detailCollection = '/collection/:id',
  buyNft = '/buy-nft/:tab/:id',
  sellNft = '/sell-nft/:tab/:id',
  brands = '/brand',
  about = '/about',
  privacy = '/privacy',
  newsletter = '/newsletter',
  brandDetail = '/brandDetail',
  search = '/search/:tab/',
  termsService = '/terms-of-service',
  listNotification = '/list-notification',
  profile = '/profile',
  emailActiveCode = '/email-active-code',
  listOffer = '/list-offer',
}

type CustomRouteProps = RouteProps & { private?: boolean };
const routes: CustomRouteProps[] = [
  {
    path: [routesEnum.home, routesEnum.login],
    exact: true,
    component: lazy(() => import('./HomePage')),
  },
  {
    path: routesEnum.collections,
    exact: true,
    component: lazy(() => import('./CollectionsPage')),
  },
  {
    path: routesEnum.ntfDetail,
    exact: true,
    component: lazy(() => import('./NFTDetail')),
  },
  {
    path: [routesEnum.faq, `${routesEnum.faq}/:key`],
    exact: true,
    component: lazy(() => import('./FAQPage')),
  },
  {
    path: [routesEnum.profile, routesEnum.wallet, routesEnum.google2fa, routesEnum.emailActiveCode],
    exact: true,
    component: lazy(() => import('./ProfilePageV2')),
  },
  {
    path: routesEnum.resetPassword,
    exact: true,
    component: lazy(() => import('./ResetPasswordPage')),
  },
  {
    path: [routesEnum.createNtf, routesEnum.editNft],
    exact: true,
    component: lazy(() => import('./CreateNFT')),
  },
  {
    path: [routesEnum.listCollection, routesEnum.listNft, routesEnum.listNotification, routesEnum.listOffer],
    exact: true,
    component: lazy(() => import('./MyCollectionPage')),
  },
  {
    path: [routesEnum.createCollection, routesEnum.editCollection],
    exact: true,
    component: lazy(() => import('./CreateCollectionPage')),
  },
  {
    path: routesEnum.detailCollection,
    exact: true,
    component: lazy(() => import('./CollectionDetailPage')),
  },
  {
    path: routesEnum.buyNft,
    exact: true,
    component: lazy(() => import('./BuyNFTPage')),
  },
  {
    path: routesEnum.sellNft,
    exact: true,
    component: lazy(() => import('./SellNFTPage')),
  },
  {
    path: routesEnum.brands,
    exact: true,
    component: lazy(() => import('./BrandsPage')),
  },
  {
    path: routesEnum.about,
    exact: true,
    component: lazy(() => import('./AboutPage')),
  },
  {
    path: routesEnum.privacy,
    exact: true,
    component: lazy(() => import('./PrivacyPage')),
  },
  {
    path: routesEnum.newsletter,
    exact: true,
    component: lazy(() => import('./NewsLetterPage')),
  },
  {
    path: `${routesEnum.brandDetail}/:id`,
    exact: true,
    component: lazy(() => import('./BrandDetailPage')),
  },
  {
    path: [routesEnum.search, `${routesEnum.search}:key`],
    exact: true,
    component: lazy(() => import('./SearchPage')),
  },
  {
    path: routesEnum.termsService,
    exact: true,
    component: lazy(() => import('./TermsServicePage')),
  },
];

export const Routes: FC = () => {
  const location = useLocation();
  useEffect(() => {
    window.history.scrollRestoration = 'manual';
  }, []);

  useEffect(() => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  }, [location]);
  return (
    <Switch>
      {routes.map((route) => (
        <Route path={route.path} key={route.path as string} exact={route.exact} component={route.component} />
      ))}
    </Switch>
  );
};
