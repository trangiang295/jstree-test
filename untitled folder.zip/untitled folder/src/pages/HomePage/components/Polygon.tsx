import { Typography } from 'antd';
import { HeaderTitle } from 'components/HeaderTitle';
import { FC } from 'react';
import styles from './Polygon.module.less';
import clsx from 'clsx';

const { Text } = Typography;

export const Polygon: FC = () => {
  return (
    <div className={styles.root}>
      <div className={styles.videoWrapper}>
        <video
          className={styles.videoWrapper}
          src="https://cdn.blockbar.com/media/uploads/product/Product/218a7fc7-0b08-40b9-a37a-7e7998175620/PAT-Blockbar-Hero_3.mp4"
          loop={true}
          autoPlay
          muted
        />
      </div>
      <div className={clsx(styles.content, 'container-fluid')}>
        <HeaderTitle className="align-items-start" title="WHY WE USE POLYGON" notShowDivider />
        <Text className="text-center fw-bold" style={{ fontSize: '16px' }}>
          Polygon’s focus on environmental issues <br />
          was the decisive factor that persuaded
          <br />
          Verdant to choose Polygon as its vendor.
        </Text>
      </div>
    </div>
  );
};
