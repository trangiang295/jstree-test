import clsx from 'clsx';
import { FC } from 'react';
import styles from './Brand.module.less';
import { Button } from 'components/Button';
import { Row, Space } from 'antd';
import { BoxAbout } from 'components/BoxAbout';
import { HeaderTitle } from 'components/HeaderTitle';
import { Carousel } from 'components/Carousel';
import { LIST_ABOUT } from 'utils/constant';
import { useHistory } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';
import { useGetListBrands } from 'api/brands';

export const Brands: FC = () => {
  const history = useHistory();
  const { data } = useGetListBrands({ page: 1, limit: 9 });

  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <HeaderTitle title="BRANDS" />
      <Carousel
        className="mb-5"
        slidesPerRow={3}
        responsive={[
          {
            breakpoint: 1270,
            settings: {
              slidesPerRow: 3,
            },
          },
          {
            breakpoint: 960,
            settings: {
              slidesPerRow: 2,
            },
          },
          {
            breakpoint: 678,
            settings: {
              slidesPerRow: 1,
            },
          },
        ]}
      >
        {data?.list.map((item, index) => (
          <div key={index}>
            <div
              className="d-flex justify-content-center pointer"
              onClick={() => history.push(`${routesEnum.brandDetail}/${item.id}`)}
            >
              <img className={styles.images} src={item.logoUrl} alt="img" />
            </div>
          </div>
        ))}
      </Carousel>
      <HeaderTitle title="What is VERDANT?" />
      <div className={clsx('d-flex mx-auto', styles.verdant)}>
        <Row>
          {LIST_ABOUT.map((item, index) => (
            <BoxAbout index={index} key={index} title={item.title} content={item.des} />
          ))}
        </Row>
      </div>
      <Space className="my-5" direction="vertical" align="center">
        <Button className="customBtnCommon" onClick={() => history.push(routesEnum.about)}>
          SEE MORE
        </Button>
      </Space>
    </div>
  );
};
