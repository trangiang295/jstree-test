import { Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Carousel } from 'components/Carousel';
import { FC } from 'react';
import styles from './Banner.module.less';
import { useGetCollectionHot } from 'api/collection';
import { useHistory } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';

const { Title } = Typography;

export const Banner: FC = () => {
  const { data } = useGetCollectionHot();
  const history = useHistory();

  return (
    <div className={clsx(styles.root, 'position-relative')}>
      <div className={styles.videoWrapper}>
        <video
          className={styles.videoWrapper}
          src="https://cdn.blockbar.com/media/uploads/product/Product/218a7fc7-0b08-40b9-a37a-7e7998175620/PAT-Blockbar-Hero_3.mp4"
          loop={true}
          autoPlay
          muted
        />
      </div>
      <div className={clsx(styles.swiperWrapper, 'position-absolute w-100 container-fluid')}>
        <Title level={1}>Welcome to Verdant</Title>
        <Title level={4}>
          Verdant offers certified authenticity by working directly <br /> with luxury brands & offering consumers asset
          backed NFTs
        </Title>
        <Button className="my-4 customBtnCommon" onClick={() => history.push(routesEnum.about)}>
          View Detail
        </Button>
        <p className={clsx('mb-2 text-white fw-bold')}>HOT COLLECTION</p>
        <Carousel
          autoPlay={true}
          slidesPerRow={4}
          className={styles.root}
          responsive={[
            {
              breakpoint: 1270,
              settings: {
                slidesPerRow: 3,
              },
            },
            {
              breakpoint: 960,
              settings: {
                slidesPerRow: 2,
              },
            },
            {
              breakpoint: 678,
              settings: {
                slidesPerRow: 1,
              },
            },
          ]}
          draggable
          infinite
        >
          {data?.map((item, index) => (
            <div key={index} className={styles.carouselItem} onClick={() => history.push(`/collection/${item.id}`)}>
              <div style={{ backgroundImage: `url("${item?.image_url}")` }} />
            </div>
          ))}
        </Carousel>
      </div>
    </div>
  );
};
