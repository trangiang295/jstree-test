import { FC } from 'react';
import styles from './MarketPlace.module.less';
import { Col, Empty, Row } from 'antd';
import { Button } from 'components/Button';
import { HeaderTitle } from 'components/HeaderTitle';
import clsx from 'clsx';
import { useHistory } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';
import { LoadingFullpage } from 'components/Loading';
import { convertName } from 'utils/common';
import { NFTCard } from 'components/NFTCard';
import { useGetListNFT } from 'api/nft';

export const MarketPlace: FC = () => {
  const history = useHistory();

  const { data: nfts, status } = useGetListNFT({
    page: 1,
    limit: 10,
  });

  if (status === 'loading') return <LoadingFullpage />;

  return (
    <div className={clsx(styles.root, 'container text-center')}>
      <HeaderTitle title="MARKETPLACE" />
      {nfts?.list && nfts?.list.length !== 0 ? (
        <Row gutter={[16, 16]} justify="start">
          {nfts?.list.map((item, index) => (
            <Col key={index} md={8} xs={24} xl={6} sm={12} className={styles.nftCardWidth}>
              <NFTCard
                image={item.image_url}
                name={item.name}
                price={item.price}
                id={item.token_id}
                edition={item?.edition || '-'}
                owner={convertName(item)}
                ownerAddress={item.human_owner}
                brand="Blank"
                onClick={() => history.push(`/nft-detail/${item.token_id}`)}
                type={item.image_type}
              />
            </Col>
          ))}
        </Row>
      ) : (
        <Empty />
      )}

      <Button className="mt-5 customBtnCommon" onClick={() => history.push(routesEnum.collections)}>
        EXPLORE MORE
      </Button>
    </div>
  );
};
