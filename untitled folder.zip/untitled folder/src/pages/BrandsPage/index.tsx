import clsx from 'clsx';
import { AboutInfo } from 'components/AboutInfo';
import { HeaderTitle } from 'components/HeaderTitle';
import { FC } from 'react';
import styles from './styles.module.less';
import { useGetListBrands } from 'api/brands';
import { LoadingFullpage } from 'components/Loading';
import { Pagination } from 'components/Pagination';
import { usePathQuery } from 'hooks/usePathQuery';
import { useHistory } from 'react-router-dom';
import { Empty } from 'antd';

const BrandsPage: FC = () => {
  const history = useHistory();
  const query = usePathQuery();
  const { data } = useGetListBrands({ page: query.get('page') ? Number(query.get('page')) : 1, limit: 5 });

  const onChangePage = (current: number) => {
    history.push(`/brand?page=${current}`);
  };

  if (!data) {
    return <LoadingFullpage />;
  }

  return (
    <div className={clsx('container-fluid', styles.root)}>
      <div className="container">
        <HeaderTitle
          title="BRAND"
          notShowDivider
          description="We partner with the top luxury liquor brands 
to bring you unique access to unique and rare bottles."
        />
        {data?.list.length > 0 ? (
          data?.list?.map((item, index) => (
            <AboutInfo key={index} index={index} item={item} showBtn imageUrl={item.descriptionUrl} />
          ))
        ) : (
          <Empty />
        )}
      </div>
      <Pagination
        className={styles.pagination}
        onChange={onChangePage}
        current={Number(data?.pagination?.currentPage || 1)}
        pageSize={data?.pagination?.itemsPerPage || 10}
        total={data?.pagination?.totalItems || 10}
      />
    </div>
  );
};

export default BrandsPage;
