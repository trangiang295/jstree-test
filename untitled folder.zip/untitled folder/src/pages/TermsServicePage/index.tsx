import clsx from 'clsx';
import { HeaderTitle } from 'components/HeaderTitle';
import { FC } from 'react';
import styles from './styles.module.less';
import { Typography } from 'antd';

const { Paragraph } = Typography;

const TermsServicePage: FC = () => {
  return (
    <div className={clsx('container-fluid', styles.root)}>
      <div className={clsx('container', styles.content)}>
        <HeaderTitle title="TERMS OF SERVICE" notShowDivider description="Last Updated: Oct 12, 2021" />
        <Paragraph strong className={styles.title}>
          Agreement - Terms
        </Paragraph>
        <Paragraph>
          All-access to any area on our websites at Verdant are governed by the terms and conditions below
          (&quot;Terms&quot;). If you are not comfortable with any of these Terms, we would advise you to exit. Please
          continue only if you can accept these Terms. In these Terms, the words &quot;we&quot;, &quot;our&quot; and
          &quot;us&quot; refers to Verdant.
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Access to Verdant{' '}
        </Paragraph>
        <Paragraph>
          The accessibility and operation of our website rely on technologies outside our control. We are not able to
          guarantee continuous accessibility or uninterrupted operation of our website.
        </Paragraph>

        <Paragraph strong className={styles.title}>
          Relying on Information
        </Paragraph>
        <Paragraph>
          We provide our website as a general information source only. Do note that we are not involved in giving
          professional advice here. The website may not cover all information available on a particular issue. We would
          advise that you conduct your own checks or obtain professional advice relevant to your circumstances, outside
          of our website.
        </Paragraph>

        <Paragraph strong className={styles.title}>
          Security
        </Paragraph>
        <Paragraph>
          Where appropriate, we use available technology to protect the security of communications made through our
          website. Do note that we do not accept liability for the security, authenticity, integrity, or confidentiality
          of any transactions and other communications made through our website. Internet communications may be
          susceptible to interference or interception by third parties. We will do our best but we cannot make any
          warranties that our website is free of infection by computer viruses or other unauthorized software.
        </Paragraph>

        <Paragraph strong className={styles.title}>
          Hyperlinks
        </Paragraph>
        <Paragraph>
          We are not responsible or liable for the availability or content of any other Internet site (not provided by
          us) linked to or from our website. Access to any other Internet site is at your own risk. If you create a link
          or frame to our website, you do so at your own risk. We reserve the right to object or disable any link or
          frame to or from our website.
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Restrictions on Use of Materials
        </Paragraph>
        <Paragraph>
          No material from this website shall be reproduced, republished, uploaded, posted, transmitted, or otherwise
          distributed in any way without the prior written consent of Verdant. Graphics and images on this website,
          including the Verdant logo and related images, are protected by copyright and may not be reproduced or
          appropriated in any manner without prior written consent.
        </Paragraph>
        <Paragraph>
          Modification of any of the materials or use of any of the materials for any other purpose will be a violation
          of Verdant’s copyright and other intellectual property rights.
        </Paragraph>
        <Paragraph>
          The downloading of any software, including any files, images, and data accompanying the software (hereinafter
          called &quot;the software&quot;) from the website by you does not in any way transfer title of the software to
          you. You may not redistribute, sell, decompile, reverse-engineer or disassemble or otherwise deal with the
          software nor create derivative works from this website or the materials thereon. Any unauthorized use of the
          website or the materials thereon is strictly prohibited.{' '}
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Third-Party Content
        </Paragraph>
        <Paragraph>
          Third-party content may appear on the website or maybe accessible via links from the website. Verdant shall
          not be responsible and assumes no liability for any infringement, mistakes, misstatements of law, defamation,
          libel, slander, omissions, falsehood, or profanity in the statements, opinions, representations or any other
          form of content contained in any third-party content appearing on the web site.{' '}
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Non-confidentiality
        </Paragraph>
        <Paragraph>
          You agree that all information and/or particulars sent or submitted by you to Verdant NFT in relation to the
          access of this website is non-confidential and non-proprietary unless otherwise expressly indicated by you.
          You further undertake not to submit any information and/or other materials which are or may be offensive,
          illegal or which may not be lawfully disseminated under the laws of Singapore or any other relevant country.
        </Paragraph>
        <Paragraph>
          Modification to Terms and Conditions of Use The Terms and Conditions set out here may be edited from time to
          time. Updated versions of the Terms and Conditions of Use will be posted on the website and are effective
          immediately.
        </Paragraph>
        <Paragraph strong className={styles.title}>
          Privacy
        </Paragraph>
        <Paragraph>
          Your use of the website is subject to Verdant’s Privacy Policy. Registration on Web Site and e-Services Web
          Sites
        </Paragraph>
        <Paragraph>Information collected from our users may be used for various reasons.</Paragraph>
        <Paragraph>
          We are committed to safeguarding your privacy. We do not disclose specific information about our users to any
          third parties unless so required by law or any government agencies. In the event that you participate in
          contests or other promotional programs on our site sponsored or organized by third parties or purchase goods
          and services offered by third parties or offer goods and services to third parties on our sites, your
          information may be disclosed to and used by such third parties.
        </Paragraph>
      </div>
    </div>
  );
};

export default TermsServicePage;
