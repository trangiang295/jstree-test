import { Col, Empty, Row } from 'antd';
import { useGetListCollection } from 'api/collection';
import clsx from 'clsx';
import { LoadingFullpage } from 'components/Loading';
import { Pagination } from 'components/Pagination';
import { FC } from 'react';
import { useHistory } from 'react-router-dom';
import { CollectionCard } from 'components/CollectionCard';
import styles from './styles.module.css';
import { HeaderTitle } from 'components/HeaderTitle';
import { usePathQuery } from 'hooks/usePathQuery';
import { routesEnum } from 'pages/Routes';
import { convertName } from 'utils/common';

const CollectionsPage: FC = () => {
  const history = useHistory();
  const query = usePathQuery();

  const { data: collections, status: collectionsStatus } = useGetListCollection({
    page: query.get('page') ? Number(query.get('page')) : 1,
    limit: 12,
  });

  const onChangePage = (current: number) => {
    history.push(`${routesEnum.collections}?page=${current}`);
  };

  if (collectionsStatus === 'loading') {
    return <LoadingFullpage />;
  }

  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <div className="container">
        <HeaderTitle title="EXPLORE COLLECTIONS" notShowDivider />
        <div className={styles.collections}>
          {collections?.list && collections.list.length !== 0 ? (
            <Row gutter={[16, 16]}>
              {collections.list.map((collection: any, index: number) => (
                <Col key={index} xxl={6} md={8} xs={24} sm={12}>
                  <CollectionCard
                    image={collection.imageUrl}
                    name={collection.name}
                    owner={convertName(collection)}
                    description={collection.description}
                    onClick={() => history.push(`/collection/${collection.id}`)}
                  />
                </Col>
              ))}
            </Row>
          ) : (
            <Empty />
          )}
        </div>
        <Pagination
          className={styles.pagination}
          onChange={onChangePage}
          current={Number(collections?.pagination?.currentPage || 1)}
          pageSize={collections?.pagination?.itemsPerPage || 8}
          total={collections?.pagination?.totalItems || 8}
        />
      </div>
    </div>
  );
};

export default CollectionsPage;
