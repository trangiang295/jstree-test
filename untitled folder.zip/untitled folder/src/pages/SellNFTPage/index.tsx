import { Col, Row, Typography } from 'antd';
import { useGetNFT } from 'api/nft';
import clsx from 'clsx';
import { Video } from 'components/Media';
import { FC } from 'react';
import { useParams } from 'react-router-dom';
import { convertName } from 'utils/common';
import { Process } from './components/Process';
import { Summary } from './components/Summary';
import styles from './styles.module.less';

const { Paragraph, Title } = Typography;

const SellNFTPage: FC = () => {
  const { tab, id } = useParams<{ id: string; tab: string }>();
  const { data: dataNFT } = useGetNFT(id);

  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <div className="container">
        <Row gutter={24}>
          <Col className="px-md-3" xs={24} lg={8} md={10} xxl={6}>
            {dataNFT?.image_type === 'video/mp4' ? (
              <Video src={dataNFT?.image_url || ''} className={styles.image} />
            ) : (
              <div style={{ backgroundImage: `url("${dataNFT?.image_url}")` }} className={styles.image} />
            )}
            <Title level={3} className="mt-3">
              {dataNFT?.name}
            </Title>
            <Paragraph>
              Owner by <strong className={styles.priceText}>@{convertName(dataNFT)}</strong>
            </Paragraph>
            <Paragraph>{dataNFT?.description}</Paragraph>
          </Col>
          <Col className="ps-md-3" lg={16} md={14} xxl={18} xs={24}>
            {tab === 'summary' && <Summary />}
            {tab === 'process' && <Process />}
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default SellNFTPage;
