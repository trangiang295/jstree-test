import { useContractFunction, useEthers } from '@usedapp/core';
import { Form, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { InputNumber } from 'components/Input';
import { useConnectABI } from 'hooks/useConnectABI';
import { FC, useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { CONTRACT_ADDRESS, PRICE } from 'utils/constant';
import styles from './Summary.module.less';
import NFTABI from 'contracts/NFTABI.json';
import MarketABI from 'contracts/MarketABI.json';
import { useGetCommission, useGetNFT } from 'api/nft';
import { message } from 'utils/message';
import { useAppSelector } from 'hooks';
import { LoadingFullpage } from 'components/Loading';
import { routesEnum } from 'pages/Routes';
import { useIsApprovedForAll } from 'hooks/useIsApprovedForAll';
import { checkLogin, getLoadingBtn } from 'utils/common';
import { convertFormatPrice, convertEther } from 'utils/number';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import BigNumber from 'bignumber.js';
import { useContractProvider } from 'hooks/useContract';

const { Title, Paragraph } = Typography;

export const Summary: FC = () => {
  const { id } = useParams<{ id: string }>();
  const [txid, setTxid] = useState('');

  const history = useHistory();
  const { refetch, data: dataNFT, status: statusGetNft } = useGetNFT(id);
  const { error, active } = useEthers();
  const { wallet, loginType } = useAppSelector((state) => state.user);
  const [loading, setLoading] = useState(false);
  const [totalPrice, setTotalPrice] = useState<any>(0);
  const loadingGetTransaction = useContractProvider(txid);
  const { data: commission } = useGetCommission();

  const [form] = Form.useForm();

  const { state: statusUpdateOrder, send: sendUpdateOrder } = useContractFunction(
    useConnectABI(MarketABI, CONTRACT_ADDRESS.MARKET),
    'updateOrder'
  );

  const { state: statusCreateOrder, send: sendCreateOrder } = useContractFunction(
    useConnectABI(MarketABI, CONTRACT_ADDRESS.MARKET),
    'createOrder'
  );

  const { state: statusApproveForAll, send: sendApproveForAll } = useContractFunction(
    useConnectABI(NFTABI, CONTRACT_ADDRESS.NFT),
    'setApprovalForAll',
    {
      transactionName: 'wrap',
    }
  );

  const { approved, status: statusIsApprovedForAll } = useIsApprovedForAll(
    wallet,
    CONTRACT_ADDRESS.MARKET,
    statusApproveForAll.status === 'None' || statusApproveForAll.status === 'Success'
  );

  const { mutate: mutatePostWalletSystem, status: statusPostWalletSystem } = useMutation(postMethod, {
    onSuccess: (data) => {
      if (data?.status !== 'failed') {
        setTxid(data?.txid);
      } else {
        setLoading(false);
        message.error('Invalid');
      }
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const onFinish = (value: any) => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }
    setLoading(true);
    const bigNumber = new BigNumber(value.price).multipliedBy(10 ** 18);
    if (!getIsSelling()) {
      if (loginType === 'wallet') {
        sendCreateOrder(
          CONTRACT_ADDRESS.NFT,
          CONTRACT_ADDRESS.USDC,
          dataNFT?.token_id,
          `${bigNumber.toPrecision(bigNumber.e ? bigNumber.e + 1 : 0)}`
        );
      } else if (loginType === 'email') {
        const request: IWalletSystemRequest = {
          method: 'createOrder',
          currency: 'polygon',
          data: [
            CONTRACT_ADDRESS.NFT,
            CONTRACT_ADDRESS.USDC,
            dataNFT?.token_id,
            `${bigNumber.toPrecision(bigNumber.e ? bigNumber.e + 1 : 0)}`,
          ],
        };
        mutatePostWalletSystem(request);
      } else {
        message.info('Please check metamask');
      }
    } else {
      if (loginType === 'wallet') {
        sendUpdateOrder(dataNFT?.order_id, `${bigNumber.toPrecision(bigNumber.e ? bigNumber.e + 1 : 0)}`);
      } else if (loginType === 'email') {
        const request: IWalletSystemRequest = {
          method: 'updateOrder',
          currency: 'polygon',
          data: [dataNFT?.order_id, `${bigNumber.toPrecision(bigNumber.e ? bigNumber.e + 1 : 0)}`],
        };
        mutatePostWalletSystem(request);
      } else {
        message.info('Please check metamask');
      }
    }
  };

  const handleApproveForAll = () => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }
    if (loginType === 'wallet') {
      sendApproveForAll(CONTRACT_ADDRESS.MARKET, true);
    } else {
      message.info('Feature temporarily unavailable for your account');
    }
  };

  const getIsSelling = () => {
    return dataNFT?.is_onsale === 1 && dataNFT?.human_owner === wallet;
  };

  useEffect(() => {
    if (statusCreateOrder.status === 'Success' || statusUpdateOrder.status === 'Success') {
      const timeOut = setTimeout(() => {
        setLoading(false);
        refetch();
        message.success('Successfully');
        history.push(`/nft-detail/${id}`);
      }, 5000);

      return () => clearTimeout(timeOut);
    } else if (
      statusCreateOrder.status === 'Exception' ||
      statusUpdateOrder.status === 'Exception' ||
      statusCreateOrder.status === 'Fail' ||
      statusUpdateOrder.status === 'Fail'
    ) {
      message.error(statusCreateOrder?.errorMessage || statusUpdateOrder?.errorMessage || 'Error');
      setLoading(false);
    }
  }, [statusCreateOrder, statusUpdateOrder]);

  useEffect(() => {
    if (statusPostWalletSystem === 'success' && !loadingGetTransaction) {
      setTimeout(() => {
        setTxid('');
        setLoading(false);
        message.success('Sell offer successfully');
        history.push(`/nft-detail/${id}`);
      }, 5000);
    }
  }, [statusPostWalletSystem, loadingGetTransaction]);

  useEffect(() => {
    if (dataNFT) {
      if (dataNFT?.price) {
        form.setFieldsValue({ price: convertEther(dataNFT?.price) });
      }
      if (dataNFT.human_owner !== wallet) {
        history.push(routesEnum.home);
      }
    }
  }, [dataNFT]);

  useEffect(() => {
    if (statusApproveForAll.status === 'Exception' || statusApproveForAll.status === 'Fail') {
      message.error(statusApproveForAll?.errorMessage || 'Error');
    }
  }, [statusApproveForAll]);

  if (loginType === 'wallet' && (statusIsApprovedForAll !== 'success' || statusGetNft !== 'success')) {
    return <LoadingFullpage />;
  }

  return (
    <div className={clsx(styles.root, 'p-md-5')}>
      <Title level={3}>{getIsSelling() ? 'UPDATE YOUR PRICE' : 'SELL FOR FIXED PRICE'}</Title>
      <Paragraph>
        {getIsSelling() ? 'Enter the price you want to update ' : 'Enter the price you want to sell your NFT '}
      </Paragraph>

      <Paragraph className="mt-4">Current Price</Paragraph>
      <Paragraph className={styles.priceText}>{convertEther(dataNFT?.price)} USD</Paragraph>

      <Form
        layout="vertical"
        onFinish={onFinish}
        form={form}
        onValuesChange={(e: any) =>
          setTotalPrice(convertFormatPrice(Number(e.price) * Number(1 - (commission || 0) / 100)))
        }
      >
        <Paragraph className="mt-4">Enter New Price </Paragraph>
        <Form.Item label="Price" name="price" rules={[{ required: true }]}>
          <InputNumber placeholder="Price" min={PRICE.minSell} max={PRICE.maxSell} />
        </Form.Item>
        <Paragraph className="mt-4">Service fee {commission || 0}% </Paragraph>
        <Paragraph className="mt-4">
          AMOUNT RECEIVED{' '}
          <span className={styles.priceText}>
            {totalPrice || convertEther(Number(dataNFT?.price) * Number(1 - (commission || 0) / 100))} USDC
          </span>
        </Paragraph>

        <div className="d-flex justify-content-center mt-5">
          <Button className={clsx(styles.customBtn, 'me-3')} onClick={() => history.go(-1)}>
            BACK
          </Button>
          <Form.Item>
            <Button
              htmlType="submit"
              className={clsx(styles.customBtn, 'me-3')}
              loading={
                (getIsSelling() && getLoadingBtn(statusUpdateOrder)) ||
                (!getIsSelling() && getLoadingBtn(statusCreateOrder)) ||
                statusPostWalletSystem === 'loading' ||
                loading === true ||
                (txid !== '' && loadingGetTransaction)
              }
              disabled={!approved && statusIsApprovedForAll === 'success' && loginType === 'wallet'}
            >
              CONFIRM
            </Button>
          </Form.Item>
          {!approved && statusIsApprovedForAll === 'success' && loginType === 'wallet' && (
            <Form.Item>
              <Button
                className={styles.customBtn}
                disabled={String(error?.name) === 'UnsupportedChainIdError' || String(error?.name) === 't'}
                loading={getLoadingBtn(statusApproveForAll)}
                onClick={handleApproveForAll}
              >
                Approve
              </Button>
            </Form.Item>
          )}
        </div>
      </Form>
    </div>
  );
};
