import { Space, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { FC } from 'react';
import { AiOutlineCheck } from 'react-icons/ai';
import styles from './Process.module.less';

const { Title, Paragraph } = Typography;

export const Process: FC = () => {
  const loading = true;

  return (
    <div className={clsx(styles.root, 'p-5')}>
      <Title level={3}>CONGRATULATION</Title>
      <Paragraph className={styles.description}>Your are now the owner of this NFT</Paragraph>
      <Paragraph strong={true}>Penfolds Magill Cellar 3 2018 Cabernet Sauvignon Shiraz #175</Paragraph>
      <Space direction="vertical">
        <Button loading={loading} className={styles.btnNoBorder}>
          {!loading && <AiOutlineCheck className="me-2" />}
          Initialize your wallet
        </Button>
        <Button className={styles.btnNoBorder}>
          <AiOutlineCheck className="me-2" />
          Approve token
        </Button>
        <Button className={styles.btnNoBorder}>
          <AiOutlineCheck className="me-2" />
          Pay 0.26 ETH
        </Button>
      </Space>
      <div className="d-flex justify-content-center mt-5">
        <Button className={clsx(styles.customBtn, 'me-3')} onClick={() => history.go(-1)}>
          BACK TO YOUR COLLECTION
        </Button>
        <Button className={styles.customBtn}>VIEW NFT</Button>
      </div>
    </div>
  );
};
