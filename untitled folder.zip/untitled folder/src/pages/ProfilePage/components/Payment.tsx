import { useEtherBalance, useTokenBalance } from '@usedapp/core';
import { Col, Typography } from 'antd';
import { useGetUserInfo } from 'api/account';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { Input } from 'components/Input';
import { formatUnits } from 'ethers/lib/utils';
import { FC } from 'react';
import styles from './Payment.module.less';

const { Title } = Typography;

export const Payment: FC = () => {
  const { data: userInfo } = useGetUserInfo();

  return (
    <Col xs={24} sm={18} md={10} lg={8} className={clsx(styles.root, 'ps-md-4 pe-md-0 px-3')}>
      <Title level={2} className={clsx(styles.title, 'text-center text-md-start')}>
        MY WALLET
      </Title>
      <Input prefix="MATIC" className={styles.input} value={formatUnits(useEtherBalance(userInfo?.wallet) || 0, 18)} />
      <Input
        prefix="USDC"
        className={styles.input}
        value={formatUnits(useTokenBalance('0x69B6c8721EBE62B2dC2Ff272a1a47cC8a755cFe2', userInfo?.wallet) || 0, 18)}
      />
      <Input
        prefix="DMT"
        className={styles.input}
        value={formatUnits(useTokenBalance('0x84C3AEEbECfDa467ed91e753542607E23987B146', userInfo?.wallet) || 0, 18)}
      />
      <Input
        prefix="DIG"
        className={styles.input}
        value={formatUnits(useTokenBalance('0x696c72D66201e385cBCa8E408Df20a1a515495AD', userInfo?.wallet) || 0, 0)}
      />

      <Button className="w-100 ">Add Fund with card</Button>
    </Col>
  );
};
