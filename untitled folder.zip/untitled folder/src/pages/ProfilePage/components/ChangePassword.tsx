import { Col, Form, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { FC } from 'react';
import styles from './Setting.module.less';
import { IError } from 'api/types';
import { useMutation } from 'react-query';
import { IUpdatePasswordRequest, logout, updatePassword } from 'api/account';
import { LOCAL_STORAGE } from 'utils/constant';
import { useAppDispatch } from 'hooks';
import { routesEnum } from 'pages/Routes';
import { useHistory } from 'react-router-dom';
import { setToken } from 'store/ducks/user/slice';
import { setAuthModal } from 'store/ducks/system/slice';
import { InputPassword } from 'components/Input';
import { message } from 'utils/message';

const { Paragraph, Title } = Typography;

export const ChangePassword: FC = () => {
  const history = useHistory();
  const dispatch = useAppDispatch();

  const { mutate: mutateUpdatePassword, status } = useMutation(updatePassword, {
    onSuccess: () => {
      message.success('Update Password successfully');
      mutateLogout();
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const { mutate: mutateLogout } = useMutation(logout, {
    onSuccess: () => {
      localStorage.removeItem(LOCAL_STORAGE.token);
      localStorage.removeItem(LOCAL_STORAGE.wallet);
      localStorage.removeItem(LOCAL_STORAGE.signature);
      localStorage.removeItem(LOCAL_STORAGE.type);
      dispatch(setToken(''));
      history.push(routesEnum.home);
      dispatch(setAuthModal('login'));
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const onFinish = (value: any) => {
    const updatePasswordRequest: IUpdatePasswordRequest = { ...value };
    mutateUpdatePassword(updatePasswordRequest);
  };

  return (
    <Col xs={24} sm={18} md={10} lg={8} className={clsx(styles.root, 'ps-md-4 pe-md-0 px-3')}>
      <Title level={2} className={clsx(styles.title, 'text-center text-md-start')}>
        CHANGE PASSWORD
      </Title>
      <Form layout="vertical" onFinish={onFinish} validateTrigger="onBlur">
        <Form.Item
          rules={[{ required: true }, { type: 'string', min: 6 }, { type: 'string', max: 20 }]}
          label="Current Password"
          name="oldPassword"
        >
          <InputPassword className="py-2" placeholder="Current password" />
        </Form.Item>
        <Form.Item
          rules={[{ required: true }, { type: 'string', min: 6 }, { type: 'string', max: 20 }]}
          label="New Password"
          name="newPassword"
        >
          <InputPassword className="py-2" placeholder="New password" />
        </Form.Item>
        <Form.Item
          rules={[
            { required: true },
            ({ getFieldValue }) => ({
              validator(_, value) {
                if (!value || getFieldValue('newPassword') === value) {
                  return Promise.resolve();
                }
                return Promise.reject(new Error('Confirm password do not match!'));
              },
            }),
          ]}
          dependencies={['newPassword']}
          label="Confirm Password"
          name="confirmPassword"
        >
          <InputPassword className="py-2" placeholder="Confirm password" />
        </Form.Item>
        <Paragraph className={styles.definePass}>
          Password must be at least 8 characters and contain 1 special character or number.
        </Paragraph>
        <Form.Item>
          <Button loading={status === 'loading'} className="w-100" htmlType={'submit'}>
            CHANGE PASSWORD
          </Button>
        </Form.Item>
      </Form>
    </Col>
  );
};
