import {
  AiOutlineLock,
  AiOutlineSetting,
  AiOutlineLogout,
  AiOutlineWallet,
  AiOutlineCamera,
  AiOutlineGooglePlus,
} from 'react-icons/ai';
import { Col, Menu, Typography, Avatar as AntdAvatar, Upload } from 'antd';
import { FC, useState } from 'react';
import styles from './MenuProfile.module.less';
import Avatar from 'assets/images/Avatar.png';
import { useHistory, useLocation } from 'react-router-dom';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { logout, useGetUserInfo } from 'api/account';
import { setFile, setLoginType, setToken, setWallet } from 'store/ducks/user/slice';
import { useAppDispatch } from 'hooks';
import { routesEnum } from 'pages/Routes';
import { message } from 'utils/message';
import { shortenAddress } from '@usedapp/core';
import { useCopy } from 'hooks/useCopy';
import { CheckOutlined, CopyOutlined } from '@ant-design/icons';
import { convertToBase64 } from 'utils/common';

const { Paragraph } = Typography;

export const MenuProfile: FC = () => {
  const history = useHistory();
  const location = useLocation();
  const dispatch = useAppDispatch();
  const { data: userInfo } = useGetUserInfo();
  const [copied, copy] = useCopy();
  const [src, setSrc] = useState<any>('');

  const { mutate: mutateLogout } = useMutation(logout, {
    onSuccess: () => {
      localStorage.clear();
      dispatch(setToken(''));
      dispatch(setLoginType(null));
      dispatch(setWallet(''));
      history.push(routesEnum.home);
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const handleLogout = () => {
    mutateLogout();
  };

  const handleCopy = () => {
    copy(userInfo?.wallet as string);
  };

  const onChangeAvatar = (info: any) => {
    dispatch(setFile(info?.file));
    const reader = new FileReader();
    reader.onload = () => {
      setSrc(convertToBase64(reader.result));
    };
    reader.readAsArrayBuffer(info?.file);
  };

  return (
    <Col xs={24} sm={18} md={10} lg={8} xl={6} className={styles.root}>
      <div className={styles.avatar}>
        <AntdAvatar
          src={userInfo?.avatarUrl || src || Avatar}
          size={{ xs: 160, sm: 160, md: 160, lg: 200, xl: 200, xxl: 200 }}
        />
        <Upload className={styles.upload} showUploadList={false} beforeUpload={() => false} onChange={onChangeAvatar}>
          <AiOutlineCamera size={30} />
        </Upload>
      </div>

      <div className="px-3">
        <Paragraph className={styles.addressWallet} onClick={handleCopy}>
          {userInfo?.wallet ? shortenAddress(userInfo?.wallet) : ''} {copied ? <CheckOutlined /> : <CopyOutlined />}
        </Paragraph>
        <Menu defaultSelectedKeys={[location.pathname]} mode="inline" theme="dark">
          <Menu.Item
            key={routesEnum.setting}
            icon={<AiOutlineSetting color="white" />}
            onClick={() => history.push(routesEnum.setting)}
          >
            Setting
          </Menu.Item>
          <Menu.Item
            key={routesEnum.wallet}
            icon={<AiOutlineWallet color="white" />}
            onClick={() => history.push(routesEnum.wallet)}
          >
            My Wallet
          </Menu.Item>
          <Menu.Item
            key={routesEnum.changePassword}
            icon={<AiOutlineLock color="white" />}
            onClick={() => history.push(routesEnum.changePassword)}
          >
            Change Password
          </Menu.Item>
          {userInfo?.type === 'email' && (
            <Menu.Item
              key={routesEnum.google2fa}
              icon={<AiOutlineGooglePlus color="white" />}
              onClick={() => history.push(routesEnum.google2fa)}
            >
              Google 2FA
            </Menu.Item>
          )}
          <Menu.Item key="4" icon={<AiOutlineLogout color="white" />} onClick={handleLogout}>
            Logout
          </Menu.Item>
        </Menu>
      </div>
    </Col>
  );
};
