import { Col, DatePicker, Form, Typography } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { FC, useEffect } from 'react';
import styles from './Setting.module.less';
import { IError } from 'api/types';
import { useMutation } from 'react-query';
import { updateProfile, useGetUserInfo } from 'api/account';
import moment from 'moment';
import { Input } from 'components/Input';
import { phoneNumberRule } from 'utils/validator';
import { message } from 'utils/message';
import { convertToFormData } from 'api/axios';
import { getFile, setFile } from 'store/ducks/user/slice';
import { useAppDispatch, useAppSelector } from 'hooks';

const { Paragraph, Title } = Typography;

export const Setting: FC = () => {
  const { data: userInfo, refetch } = useGetUserInfo();
  const [form] = Form.useForm();
  const file = useAppSelector(getFile);
  const dispatch = useAppDispatch();

  useEffect(() => {
    form.setFieldsValue({
      ...userInfo,
      dateOfBirth: userInfo?.dateOfBirth ? moment(userInfo?.dateOfBirth, 'YYYY-MM-DD') : null,
    });
  }, [userInfo]);

  const { mutate: mutateUpdateProfile, status } = useMutation(updateProfile, {
    onSuccess: () => {
      refetch();
      message.success('Update Profile successfully');
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const onFinish = (value: any) => {
    const updateProfileRequest = {
      ...value,
      dateOfBirth: value.dateOfBirth ? value['dateOfBirth'].format('YYYY-MM-DD') : null,
    };
    if (file) {
      updateProfileRequest.image = file;
      dispatch(setFile(''));
    }
    mutateUpdateProfile(convertToFormData(updateProfileRequest));
  };

  return (
    <Col xs={24} sm={18} md={10} lg={8} className={clsx(styles.root, 'ps-md-4 pe-md-0 px-3')}>
      <Title level={2} className={clsx(styles.title, 'text-center text-md-start')}>
        SETTING
      </Title>
      <Paragraph className={styles.emailLogin}>
        You have signed up using: <strong>{userInfo?.email}</strong>
      </Paragraph>
      <Form layout="vertical" onFinish={onFinish} form={form} validateTrigger="onBlur">
        <Form.Item label="First Name" name="firstName">
          <Input placeholder="First name" />
        </Form.Item>
        <Form.Item label="Last Name" name="lastName">
          <Input placeholder="Last name" />
        </Form.Item>
        <Form.Item
          validateFirst
          label="Phone"
          name="phone"
          rules={[
            { whitespace: true },
            {
              async validator(_, value) {
                return await phoneNumberRule(value);
              },
            },
          ]}
        >
          <Input placeholder="Phone" />
        </Form.Item>
        <Form.Item label="Date Of Birth" name="dateOfBirth">
          <DatePicker className="w-100" format="YYYY-MM-DD" placeholder="Date Of Birth" />
        </Form.Item>
        <Form.Item>
          <Button loading={status === 'loading'} className="w-100" htmlType={'submit'}>
            SAVE
          </Button>
        </Form.Item>
      </Form>
    </Col>
  );
};
