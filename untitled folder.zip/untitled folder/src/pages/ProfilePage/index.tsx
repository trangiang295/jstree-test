import { Row } from 'antd';
import clsx from 'clsx';
import { FC } from 'react';
import styles from './styles.module.less';
import { useLocation } from 'react-router-dom';
import { Setting } from './components/Setting';
import { Payment } from './components/Payment';
import { MenuProfile } from './components/MenuProfile';
import { ChangePassword } from './components/ChangePassword';
import { routesEnum } from 'pages/Routes';
import { NewsLetter } from 'components/NewsLetter';
import { Google2FA } from './components/Google2FA';

const ProfilePage: FC = () => {
  const { pathname } = useLocation<{ pathname: string }>();

  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <div className={clsx(styles.content, 'container')}>
        <Row className="justify-content-center justify-content-md-start">
          <MenuProfile />
          {pathname === routesEnum.setting && <Setting />}
          {pathname === routesEnum.wallet && <Payment />}
          {pathname === routesEnum.changePassword && <ChangePassword />}
          {pathname === routesEnum.google2fa && <Google2FA />}
        </Row>
      </div>
      <NewsLetter />
    </div>
  );
};

export default ProfilePage;
