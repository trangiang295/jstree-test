import clsx from 'clsx';
import { FC } from 'react';
import styles from './styles.module.less';
import { Menu } from './components/Menu';
import { Col, Row } from 'antd';
import { TableNFT } from './components/TableNFT';
import { TableCollection } from './components/TableCollection';
import { useLocation } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';
import { ListNotification } from './components/ListNotification';
// import { ListOffer } from './components/ListOffer';

const MyCollectionPage: FC = () => {
  const { pathname } = useLocation<{ pathname: string }>();

  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <div className={styles.content}>
        <Row className="px-md-0 px-sm-5">
          <Col md={6} xl={4} xs={24} sm={24} className="my-4">
            <Menu />
          </Col>
          <Col md={18} xl={20} xs={24} sm={24} className="my-4 ps-md-4 ps-xl-5">
            {pathname === routesEnum.listNft && <TableNFT />}
            {pathname === routesEnum.listCollection && <TableCollection />}
            {pathname === routesEnum.listNotification && <ListNotification />}
            {/* {pathname === routesEnum.listOffer && <ListOffer />} */}
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default MyCollectionPage;
