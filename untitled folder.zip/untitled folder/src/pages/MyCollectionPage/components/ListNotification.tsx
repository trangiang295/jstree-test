import { useGetListNotifications } from 'api/notification';
import { Notification } from 'components/Notification';
import { Pagination } from 'components/Pagination';
import { useAppSelector } from 'hooks';
import { useState } from 'react';
import styles from './styles.module.less';

export const ListNotification = () => {
  const { wallet } = useAppSelector((state) => state.user);

  const [params, setParams] = useState<any>({
    page: 1,
    limit: 10,
  });

  const { data: notifications } = useGetListNotifications(params, { enabled: !!wallet });

  const onChangePage = (current: number) => {
    setParams({ ...params, page: current });
  };
  return (
    <div className={styles.root}>
      <Notification
        headerClass="text-left"
        hidden={{ footer: true }}
        notifications={notifications ? notifications.list : []}
      />
      <Pagination
        className={styles.pagination}
        onChange={onChangePage}
        current={Number(notifications?.pagination?.currentPage || 1)}
        pageSize={notifications?.pagination?.itemsPerPage || 10}
        total={notifications?.pagination?.totalItems || 10}
      />
    </div>
  );
};
