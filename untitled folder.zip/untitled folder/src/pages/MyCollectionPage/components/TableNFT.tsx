import { Row, Col, Menu, Empty } from 'antd';
import { Button } from 'components/Button';
import { Tabs } from './Tab';
import { INFTParams, useGetListOwnerNFT } from 'api/nft';
import { useHistory } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';
import styles from './styles.module.less';
import { Pagination } from 'components/Pagination';
import { LoadingFullpage } from 'components/Loading';
import { NFTCard } from 'components/NFTCard';
import { useState } from 'react';
import { convertName } from 'utils/common';

const TABS = [
  { label: 'All', value: '' },
  { label: 'On Sale', value: 'onsale' },
  // { label: 'Out of stock', value: 'Out of stock' },
  // { label: 'Hidden', value: 'hidden' },
];

export const TableNFT = () => {
  const history = useHistory();
  const [params, setParams] = useState<INFTParams>({
    page: 1,
    limit: 10,
    name: '',
    status: '',
  });

  const { data, status } = useGetListOwnerNFT(params);

  const onChangePage = (current: number) => {
    setParams({ ...params, page: current });
  };

  if (status === 'loading') {
    return <LoadingFullpage />;
  }

  return (
    <div className={styles.root}>
      <Tabs params={params} setParams={setParams} />
      <div className={styles.content}>
        <Menu mode="horizontal" className={styles.menu} defaultActiveFirst>
          {TABS.map((item) => (
            <Menu.Item key={item.value} onClick={() => setParams({ ...params, status: item.value })}>
              <strong>{item.label}</strong>
            </Menu.Item>
          ))}
        </Menu>
        <Row justify="space-between" align="middle" className="my-3">
          <Col span={12}>
            <strong>{data && data.pagination.totalItems} Product</strong>
          </Col>
          <Col span={12} className="text-end">
            <Button onClick={() => history.push(routesEnum.createNtf)}>+ Create</Button>
          </Col>
        </Row>
        {data && data?.list.length > 0 ? (
          <>
            <Row gutter={[16, 16]} justify="start">
              {data?.list.map((item, index) => (
                <Col key={index} className={styles.nftCardWidth} md={12} xs={24} xl={8} xxl={6} sm={12}>
                  <NFTCard
                    image={item.image_url}
                    name={item.name}
                    price={item.price}
                    id={item.token_id}
                    ownerAddress={item.human_owner}
                    owner={convertName(item)}
                    edition={item?.edition || '-'}
                    brand="Dictador"
                    type={item.image_type}
                    onClick={() => history.push(`/nft-detail/${item.token_id}`)}
                  />
                </Col>
              ))}
            </Row>
            <Pagination
              className={styles.pagination}
              onChange={onChangePage}
              current={Number(data?.pagination?.currentPage || 1)}
              pageSize={data?.pagination?.itemsPerPage || 10}
              total={data?.pagination?.totalItems || 10}
            />
          </>
        ) : (
          <Empty />
        )}
      </div>
    </div>
  );
};
