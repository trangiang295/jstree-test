import styles from './Menu.module.less';
import { Menu as AntdMenu } from 'antd';
import { useHistory, useLocation } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';
import { MdCollections } from 'react-icons/md';
import { GiWineBottle } from 'react-icons/gi';
import { AiOutlineBell } from 'react-icons/ai';

export const Menu = () => {
  const history = useHistory();
  const location = useLocation();

  return (
    <div className={styles.root}>
      <AntdMenu className={styles.menu} selectedKeys={[location.pathname]} mode="inline" theme="dark">
        <AntdMenu.Item
          key={routesEnum.listCollection}
          icon={<MdCollections />}
          onClick={() => history.push(routesEnum.listCollection)}
        >
          Collection
        </AntdMenu.Item>
        <AntdMenu.Item
          key={routesEnum.listNft}
          icon={<GiWineBottle />}
          onClick={() => history.push(routesEnum.listNft)}
        >
          NFT
        </AntdMenu.Item>
        {/* <AntdMenu.Item
          key={routesEnum.listOffer}
          icon={<MdOutlineLocalOffer />}
          onClick={() => history.push(routesEnum.listOffer)}
        >
          Offer
        </AntdMenu.Item> */}
        <AntdMenu.Item
          key={routesEnum.listNotification}
          icon={<AiOutlineBell />}
          onClick={() => history.push(routesEnum.listNotification)}
        >
          Notification
        </AntdMenu.Item>
        {/* <AntdMenu.Item key="sales-analysis">Sales analysis</AntdMenu.Item> */}
      </AntdMenu>
    </div>
  );
};
