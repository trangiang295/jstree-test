import { Row, Col, Menu, Empty } from 'antd';
import { Button } from 'components/Button';
// import { Tabs } from './Tab';
import styles from './styles.module.less';
import { ICollectionParams, useGetListOwnerCollection } from 'api/collection';
import { useHistory } from 'react-router-dom';
import { routesEnum } from 'pages/Routes';
import { Pagination } from 'components/Pagination';
import { LoadingFullpage } from 'components/Loading';
import { CollectionCard } from 'components/CollectionCard';
import { useState } from 'react';
import { Tabs } from './Tab';
import { convertName } from 'utils/common';

const TABS = [
  { label: 'All', value: '' },
  { label: 'On Sale', value: 'onsale' },
];

export const TableCollection = () => {
  const history = useHistory();
  const [params, setParams] = useState<ICollectionParams>({
    page: 1,
    limit: 10,
    name: '',
    status: '',
  });
  const { data, status } = useGetListOwnerCollection(params);

  const onChangePage = (current: number) => {
    setParams({ ...params, page: current });
  };

  if (status === 'loading') {
    return <LoadingFullpage />;
  }

  return (
    <div className={styles.root}>
      <Tabs params={params} setParams={setParams} />
      <div className={styles.content}>
        <Menu mode="horizontal" className={styles.menu} defaultActiveFirst>
          {TABS.map((item) => (
            <Menu.Item key={item.value} onClick={() => setParams({ ...params, status: item.value })}>
              <strong>{item.label}</strong>
            </Menu.Item>
          ))}
        </Menu>
        <Row justify="space-between" align="middle" className="my-3">
          <Col span={12}>
            <strong>{data?.pagination?.totalItems || 0} Collection</strong>
          </Col>
          <Col span={12} className="text-end">
            <Button onClick={() => history.push(routesEnum.createCollection)}>+ Create</Button>
          </Col>
        </Row>
        {data?.list && data.list.length !== 0 ? (
          <>
            <Row gutter={[16, 16]}>
              {data.list.map((collection: any, index: number) => (
                <Col key={index} md={12} xs={24} xl={6} sm={12}>
                  <CollectionCard
                    image={collection.imageUrl}
                    name={collection.name}
                    owner={convertName(collection)}
                    description={collection.description}
                    onClick={() => history.push(`/collection/${collection.id}`)}
                  />
                </Col>
              ))}
            </Row>
            <Pagination
              className={styles.pagination}
              onChange={onChangePage}
              current={Number(data?.pagination?.currentPage || 1)}
              pageSize={data?.pagination?.itemsPerPage || 10}
              total={data?.pagination?.totalItems || 10}
            />
          </>
        ) : (
          <Empty />
        )}
      </div>
    </div>
  );
};
