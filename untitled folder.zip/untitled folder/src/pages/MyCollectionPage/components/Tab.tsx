import { Form } from 'antd';
import { Button } from 'components/Button';
import { Input } from 'components/Input';
import useBreakpoint from 'antd/lib/grid/hooks/useBreakpoint';
import styles from './Tab.module.less';
import { FC } from 'react';
import { INFTParams } from 'api/nft';

type ITabs = {
  params: INFTParams;
  setParams: (value: any) => void;
};

export const Tabs: FC<ITabs> = ({ params, setParams }) => {
  const screen = useBreakpoint();

  const onFinish = (value: any) => {
    setParams({ ...params, ...value });
  };

  return (
    <div className={styles.root}>
      <Form layout={screen.md ? 'inline' : 'horizontal'} onFinish={onFinish} validateTrigger="onBlur">
        <Form.Item className={styles.formItem} name="name">
          <Input placeholder="Name" />
        </Form.Item>
        <Form.Item className="text-center">
          <Button htmlType="submit" className={styles.button}>
            Search
          </Button>
        </Form.Item>
      </Form>
    </div>
  );
};
