import { Checkbox, Form, Space, Typography, Input as AntdInput } from 'antd';
import clsx from 'clsx';
import { Button } from 'components/Button';
import { HeaderTitle } from 'components/HeaderTitle';
import { Input, InputNumber, InputTextArea } from 'components/Input';
import { Select } from 'components/Select';
import { FC, useEffect, useMemo, useState } from 'react';
import styles from './styles.module.less';
import { createNft, useGetNFT, IUpdateNFTRequest, updateNft } from 'api/nft';
import { useGetListOwnerCollection } from 'api/collection';
import { useFileData } from 'hooks/useFileData';
import { useHistory, useParams } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from 'hooks';
import { setNFTModal } from 'store/ducks/nft/slice';
import { useMutation } from 'react-query';
import { IError } from 'api/types';
import { useContractFunction, useEthers, useTokenAllowance } from '@usedapp/core';
import { APPROVE_AMOUNT, CONTRACT_ADDRESS } from 'utils/constant';
import { useConnectABI } from 'hooks/useConnectABI';
import TokenABI from 'contracts/TokenABI.json';
import { convertToFormData } from 'api/axios';
import { message } from 'utils/message';
import { formatUnits } from 'ethers/lib/utils';
import { LoadingFullpage } from 'components/Loading';
import { checkLogin, checkPrice, getLoadingBtn, getStatusPrice } from 'utils/common';
import { Upload } from 'components/Upload';
import NFTABI from 'contracts/NFTABI.json';
import { IWalletSystemRequest, postMethod } from 'api/systemwallet';
import { routesEnum } from 'pages/Routes';
import { useContractProvider } from 'hooks/useContract';
import { configForm } from 'utils/form';
import { getBalance } from 'store/ducks/user/slice';
import { useGetUserInfo } from 'api/account';
import { NotFoundPage } from 'pages/NotFoundPage.tsx';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';

const { Option } = Select;
const { Paragraph } = Typography;

const LIST_PAYMENT_TOKEN = [
  { value: 'eth', title: 'ETH' },
  { value: 'btc', title: 'BTC' },
  { value: 'bnb', title: 'BNB' },
];

const CreateNFT: FC = () => {
  const [agreeMintNFT, setAgreeCreateNFT] = useState<boolean>(false);
  const [statusUpload, setStatusUpload] = useState(false);
  const [txid, setTxid] = useState('');
  const [loading, setLoading] = useState(false);
  const balance = useAppSelector(getBalance);
  const { data: userInfo } = useGetUserInfo();

  const dispatch = useAppDispatch();
  const { wallet, loginType } = useAppSelector((state) => state.user);

  const { account, error, active } = useEthers();
  const tokenAllowance = useTokenAllowance(CONTRACT_ADDRESS.TOKEN, wallet, CONTRACT_ADDRESS.NFT);
  const allowance: number = useMemo(() => Number(formatUnits(tokenAllowance || 0, 18)), [tokenAllowance]);

  const [form] = Form.useForm();
  const { id } = useParams<{ id: string }>();
  const history = useHistory();

  const { data: listOwnerCollection } = useGetListOwnerCollection();
  const { data: dataNFT } = useGetNFT(id, { enabled: !!id });

  const loadingGetTransaction = useContractProvider(txid);

  useEffect(() => {
    if (id && dataNFT) {
      form.setFieldsValue({
        ...dataNFT,
        image: dataNFT.image_url,
      });
    } else {
      form.setFieldsValue({ quantity: 1 });
    }
  }, [dataNFT]);

  const handleChange = (file: File) => {
    form.setFieldsValue({ image: file });
  };

  const onFinish = (value: any) => {
    if (!agreeMintNFT) {
      message.info('Please accept term to create nft');
      return;
    }

    if (!id) {
      const request = {
        ...value,
        image: value.image,
        currency: 'MATIC',
        properties: JSON.stringify(value.properties),
      };
      mutateCreateNFT(convertToFormData(request));
    } else {
      const updateNFTRequest: IUpdateNFTRequest = {
        id: parseInt(id),
        price: value?.price,
        paymentToken: value?.paymentToken,
      };
      mutateUpdateNFT(updateNFTRequest);
    }
  };

  const { mutate: mutateCreateNFT, status: statusCreateNFT } = useMutation(createNft, {
    onSuccess: (data) => {
      handleMint(data);
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const { mutate: mutateUpdateNFT, status: statusUpdateNFT } = useMutation(updateNft, {
    onSuccess: () => {
      message.success('Update NFT successfully');
    },
    onError: (error: IError) => {
      message.error(error.meta.message[0]);
    },
  });

  const { state: statusApprove, send: sendApprove } = useContractFunction(
    useConnectABI(TokenABI, CONTRACT_ADDRESS.TOKEN),
    'approve',
    {
      transactionName: 'wrap',
    }
  );

  const { state: statusMint, send: sendSafeMint } = useContractFunction(
    useConnectABI(NFTABI, CONTRACT_ADDRESS.NFT),
    'safeMint',
    {
      transactionName: 'wrap',
    }
  );

  const { mutate: mutatePostWalletSystem, status: statusPostWalletSystem } = useMutation(postMethod, {
    onSuccess: (data) => {
      if (data?.status !== 'failed') {
        setTxid(data?.txid);
      } else {
        setLoading(false);
        checkPrice(balance.token, 1, 'DMT', 'Invalid');
      }
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const getLoadingMint = () => {
    if (loginType === 'email') {
      return statusPostWalletSystem === 'loading' || (txid !== '' && loadingGetTransaction) || loading === true;
    }
    return getLoadingBtn(statusMint) || loading === true;
  };

  useEffect(() => {
    if (statusMint.status === 'Success' || (statusPostWalletSystem === 'success' && !loadingGetTransaction)) {
      setTimeout(() => {
        setTxid('');
        setLoading(false);
        message.success('Successfully');
        history.push(routesEnum.listNft);
      }, 5000);
    } else if (statusMint.status === 'Exception' || statusMint.status === 'Fail') {
      message.error(statusMint?.errorMessage || 'Error');
      setLoading(false);
    }
  }, [statusMint, statusPostWalletSystem, loadingGetTransaction]);

  const handleMint = (data: any) => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login to continue');
      return;
    }

    if (loginType === 'email') {
      const request: IWalletSystemRequest = {
        method: 'safeMint',
        currency: 'polygon',
        data: [
          Array(parseInt(data.quantity)).fill(wallet),
          Array(parseInt(data.quantity)).fill(data.url_ipfs.toString()),
        ],
      };
      if (!getStatusPrice(balance.token, data.quantity)) {
        message.info(`Lack of DMT`);
        return;
      }
      setLoading(true);
      mutatePostWalletSystem(request);
    } else if (loginType === 'wallet') {
      setLoading(true);
      sendSafeMint(
        Array(parseInt(data.quantity)).fill(wallet),
        Array(parseInt(data.quantity)).fill(data.url_ipfs.toString())
      );
    }
  };

  useEffect(() => {
    if (statusApprove.status === 'Exception' || statusApprove.status === 'Fail') {
      message.error(statusApprove?.errorMessage || 'Error');
    }
  }, [statusApprove]);

  const handleApprove = () => {
    if (!checkLogin(loginType, active)) {
      message.info('Please login metamask to continue');
      return;
    }
    sendApprove(CONTRACT_ADDRESS.NFT, APPROVE_AMOUNT);
  };

  if (account && tokenAllowance === undefined) {
    return <LoadingFullpage />;
  }

  if (userInfo?.brandId === null) {
    return <NotFoundPage />;
  }

  return (
    <div className={clsx(styles.root, 'container pb-5')}>
      <div className={styles.content}>
        <HeaderTitle notShowDivider title="Create New NFT" className="text-start align-items-start mb-4" />
        <Form
          layout="vertical"
          onFinish={onFinish}
          onFinishFailed={() => dispatch(setNFTModal(null))}
          validateTrigger="onBlur"
          form={form}
        >
          <Paragraph strong className={styles.title}>
            Image, Video, Audio, or 3D Model *
          </Paragraph>
          <Paragraph className={styles.text}>File types supported: JPG, PNG, GIF, MP4. Max size: 100MB</Paragraph>
          <Form.Item
            name="image"
            label="Image"
            getValueFromEvent={useFileData}
            rules={[
              {
                required: true,
                message: statusUpload
                  ? `Image must smaller than ${configForm.maxImageFileSize}MB!`
                  : 'Image is required!',
              },
            ]}
          >
            <Upload
              listType="picture-card"
              onChangeFile={handleChange}
              imageUrl={dataNFT?.image_url}
              onSubmitFailUpload={setStatusUpload}
            />
          </Form.Item>
          <Paragraph strong className={styles.title}>
            Name *
          </Paragraph>
          <Form.Item label="Name" name="name" rules={[{ required: true }]}>
            <Input placeholder="Item name" disabled={id !== undefined} maxLength={255} />
          </Form.Item>
          <Paragraph strong className={styles.title}>
            Description
          </Paragraph>
          <Paragraph className={styles.text}>
            The description will be included on the item&apos;s detail page underneath its image.
          </Paragraph>
          <Form.Item label="Description" name="description">
            <InputTextArea
              className={styles.textArea}
              placeholder="Provide a detailed description of your item. "
              disabled={id !== undefined}
              maxLength={5000}
            />
          </Form.Item>
          <Paragraph strong className={styles.title}>
            Collection *
          </Paragraph>
          <Paragraph className={styles.text}>This is the collection where your item will appear.</Paragraph>
          <Form.Item label="Collection" name="collectionId" rules={[{ required: true }]}>
            <Select placeholder="Select collection" disabled={id !== undefined}>
              {listOwnerCollection &&
                listOwnerCollection.list.map((item) => (
                  <Option key={item.id} value={item.id}>
                    {item.name}
                  </Option>
                ))}
            </Select>
          </Form.Item>
          {id && (
            <>
              <Paragraph className={styles.text}>Choose your payment token</Paragraph>
              <Form.Item label="Payment Token" name="paymentToken">
                <Select placeholder="Payment token">
                  {LIST_PAYMENT_TOKEN.map((item) => (
                    <Option key={item.value} value={item.value}>
                      {item.title}
                    </Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item label="Price" name="price">
                <Input placeholder="Price" />
              </Form.Item>
            </>
          )}
          <Paragraph strong className={styles.title}>
            Quantity *
          </Paragraph>
          <Paragraph className={styles.text}>The number of items that can be minted</Paragraph>
          <Form.Item label="Quantity" name="quantity" rules={[{ required: true }]}>
            <InputNumber placeholder="Enter the number of items" disabled={id !== undefined} min={1} max={15} />
          </Form.Item>
          <Paragraph strong className={styles.title}>
            Metadata
          </Paragraph>
          <Form.List name="properties">
            {(fields, { add, remove }) => (
              <>
                {fields.map((field, index) => (
                  <AntdInput.Group
                    key={index}
                    compact
                    className="d-flex align-items-center flex-md-row flex-column mb-4"
                  >
                    <Form.Item
                      className="mb-md-0"
                      {...field}
                      label="Type"
                      rules={[{ required: true }]}
                      name={[field.name, 'type']}
                    >
                      <Input
                        style={{ borderTopRightRadius: 0, borderBottomRightRadius: 0 }}
                        placeholder="Property type"
                      />
                    </Form.Item>
                    <Form.Item
                      style={{ flex: 1 }}
                      className="mb-md-0"
                      {...field}
                      label="Name"
                      rules={[{ required: true }]}
                      name={[field.name, 'name']}
                    >
                      <Input
                        style={{ borderTopLeftRadius: 0, borderBottomLeftRadius: 0 }}
                        placeholder="Property Name"
                      />
                    </Form.Item>
                    <MinusCircleOutlined
                      className="ms-md-4"
                      onClick={() => {
                        remove(field.name);
                      }}
                    />
                  </AntdInput.Group>
                ))}
                <Button
                  className="w-auto my-3"
                  onClick={() => {
                    add();
                  }}
                  block
                >
                  <PlusOutlined /> Add More
                </Button>
              </>
            )}
          </Form.List>
          {!id && (
            <Checkbox
              checked={agreeMintNFT}
              onChange={(e) => setAgreeCreateNFT(e.target.checked)}
              className={clsx(styles.textTermPolicy, 'd-flex align-items-center mb-3')}
            >
              Please make sure to double check your entries before continue creating NFT. You can’t edit data when mint
              NFT is success.
            </Checkbox>
          )}
          <Space>
            <Form.Item>
              <Button
                loading={
                  (id && statusUpdateNFT === 'loading') || (!id && (statusCreateNFT === 'loading' || getLoadingMint()))
                }
                htmlType="submit"
                disabled={((loginType === 'wallet' && allowance === 0) || !agreeMintNFT) && !id}
              >
                {!id ? 'Create NFT' : 'Update NFT'}
              </Button>
            </Form.Item>
            {loginType === 'wallet' && allowance === 0 && (
              <Form.Item>
                <Button
                  disabled={String(error?.name) === 'UnsupportedChainIdError' || String(error?.name) === 't'}
                  loading={getLoadingBtn(statusApprove)}
                  onClick={handleApprove}
                >
                  Approve
                </Button>
              </Form.Item>
            )}
          </Space>
        </Form>
      </div>
    </div>
  );
};

export default CreateNFT;
