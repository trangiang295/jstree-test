import { Col, Form, Row, Typography } from 'antd';
import clsx from 'clsx';
import { HeaderTitle } from 'components/HeaderTitle';
import { FC } from 'react';
import styles from './styles.module.less';
import { Button } from 'components/Button';
import { IResetPasswordRequest, resetPassword } from 'api/account';
import { useHistory } from 'react-router-dom';
import { useMutation } from 'react-query';
import { routesEnum } from 'pages/Routes';
import { IError } from 'api/types';
import { usePathQuery } from 'hooks/usePathQuery';
import { InputPassword } from 'components/Input';
import { message } from 'utils/message';

const { Paragraph } = Typography;

const ResetPasswordPage: FC = () => {
  const history = useHistory();
  const query = usePathQuery();

  const { mutate: mutateResetPassword, status } = useMutation(resetPassword, {
    onSuccess: () => {
      history.push(routesEnum.home);
    },
    onError: (error: IError) => {
      message.error(error.meta.message);
    },
  });

  const onResetPassword = (value: any) => {
    const resetPasswordRequest: IResetPasswordRequest = { ...value, token: query.get('code') };
    mutateResetPassword(resetPasswordRequest);
  };

  return (
    <div className={clsx(styles.root, 'container-fluid')}>
      <div className={clsx(styles.content, 'container')}>
        <HeaderTitle title="RESET PASSWORD" notShowDivider />
        <Row justify="center" className="mt-3">
          <Col md={16} sm={20} lg={8} xs={24}>
            <Form layout="vertical" onFinish={onResetPassword} validateTrigger="onBlur">
              <Form.Item
                rules={[{ required: true }, { type: 'string', min: 6 }, { type: 'string', max: 20 }]}
                label="New Password"
                name="password"
              >
                <InputPassword placeholder="New password" />
              </Form.Item>
              <Form.Item
                rules={[{ required: true }, { type: 'string', min: 6 }, { type: 'string', max: 20 }]}
                label="Confirm Password"
                name="confirmPassword"
              >
                <InputPassword placeholder="Confirm password" />
              </Form.Item>
              <Paragraph className={styles.definePass}>
                Password must be at least 8 characters and contain 1 special character or number.
              </Paragraph>
              <Form.Item>
                <Button loading={status === 'loading'} className="w-100" htmlType={'submit'}>
                  RESET PASSWORD
                </Button>
              </Form.Item>
            </Form>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default ResetPasswordPage;
