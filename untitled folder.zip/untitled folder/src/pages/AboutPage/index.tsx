import { Empty } from 'antd';
import { useGetAbout } from 'api/brands';
import clsx from 'clsx';
import { AboutInfo } from 'components/AboutInfo';
import { HeaderTitle } from 'components/HeaderTitle';
import { LoadingFullpage } from 'components/Loading';
import { Pagination } from 'components/Pagination';
import { usePathQuery } from 'hooks/usePathQuery';
import { FC } from 'react';
import { useHistory } from 'react-router-dom';
import styles from './styles.module.less';

const AboutPage: FC = () => {
  const history = useHistory();
  const query = usePathQuery();
  const { data } = useGetAbout({ page: query.get('page') ? Number(query.get('page')) : 1, limit: 5 });

  if (!data) {
    return <LoadingFullpage />;
  }

  const onChangePage = (current: number) => {
    history.push(`/about?page=${current}`);
  };

  return (
    <div className={clsx('container-fluid', styles.root)}>
      <div className="container">
        <HeaderTitle
          title="WHAT IS VERDANT"
          notShowDivider
          description="Verdant offers certified authenticity by working directly with luxury brands & offering consumers asset backed NFTs"
        />
        {data?.list.length > 0 ? (
          data?.list
            ?.reverse()
            .map((item, index) => <AboutInfo key={index} index={index} item={item} imageUrl={item.logoUrl} />)
        ) : (
          <Empty />
        )}
      </div>
      <Pagination
        className={styles.pagination}
        onChange={onChangePage}
        current={Number(data?.pagination?.currentPage || 1)}
        pageSize={data?.pagination?.itemsPerPage || 10}
        total={data?.pagination?.totalItems || 10}
      />
    </div>
  );
};

export default AboutPage;
