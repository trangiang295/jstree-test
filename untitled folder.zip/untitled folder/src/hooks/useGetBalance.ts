import { Contract } from '@ethersproject/contracts';
import { useEffect, useState } from 'react';
import { POLYGON_RPC } from 'utils/constant';
import Web3 from 'web3';
import { useContractNoSignner } from './useContract';

export function useGetTokenBalanceToken(address: string, token: string, ABI: any) {
  const [value, setValue] = useState(undefined);
  const contract = useContractNoSignner<Contract>(token, ABI);
  useEffect(() => {
    (async () => {
      if (address) {
        const balance = await contract.balanceOf(address);
        setValue(balance);
      }
    })();
  }, [token, address]);
  return value;
}

export function useGetTokenBalance(address: string) {
  const [value, setValue] = useState<any>(undefined);
  const httpProvider = new Web3.providers.HttpProvider(POLYGON_RPC);
  const lib = new Web3(httpProvider);
  useEffect(() => {
    (async () => {
      if (address) {
        const balance = await lib.eth.getBalance(address);
        setValue(balance);
      }
    })();
  }, [address]);
  return value;
}
