import { NFTABI } from 'contracts/types';
import { useContractNoSignner } from './useContract';
import NFT_ABI from 'contracts/NFTABI.json';
import { useEffect, useState } from 'react';
import { CONTRACT_ADDRESS } from 'utils/constant';

export function useIsApprovedForAll(owner: any, operator: any, reset: any) {
  const [data, setData] = useState<any>({ approved: undefined, status: 'start' });
  const contract = useContractNoSignner<NFTABI>(CONTRACT_ADDRESS.NFT, NFT_ABI);
  useEffect(() => {
    (async () => {
      if (reset) {
        if (!owner) {
          return;
        }
        setData({ ...data, status: 'loading' });
        try {
          const approved = await contract.isApprovedForAll(owner, operator);
          setData({ approved, status: 'success' });
        } catch {
          setData({ approved: false, status: 'error' });
        }
      }
    })();
  }, [owner, reset]);
  return data;
}
