import { useSocket } from 'socket.io-react-hook';
import { SOCKET_URL } from 'utils/constant';
import { useAppSelector } from './useRedux';

export const useAuthWebSocket = () => {
  const wallet = useAppSelector((state) => state.user.wallet);
  const sk = useSocket(SOCKET_URL, {
    enabled: !!wallet,
    query: {
      address: wallet || '',
    },
    transports: ['websocket'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
    reconnectionAttempts: 4,
  });

  return { ...sk };
};
