import { useEffect, useMemo, useState } from 'react';
import { Contract } from '@ethersproject/contracts';
import { useEthers } from '@usedapp/core';
import { JsonRpcProvider } from '@ethersproject/providers';
import { POLYGON_RPC } from 'utils/constant';
import Web3 from 'web3';

export function useContract<T extends Contract = Contract>(address: string, ABI: any): T | null {
  const { library, account, chainId } = useEthers();

  return useMemo(() => {
    if (!address || !ABI || !library || !chainId || !account) {
      return null;
    }

    try {
      return new Contract(address, ABI, library.getSigner(account));
    } catch (error) {
      console.error('Failed To Get Contract', error);

      return null;
    }
  }, [address, ABI, library, account]) as T;
}

export function useContractNoSignner<T extends Contract = Contract>(address: string, ABI: any): T {
  return useMemo(() => {
    const httpProvider = new JsonRpcProvider(POLYGON_RPC);
    return new Contract(address, ABI, httpProvider);
  }, [address, ABI]) as T;
}

export function useContractProvider(hash: string, reset?: any) {
  const httpProvider = new Web3.providers.HttpProvider(POLYGON_RPC);
  const lib = new Web3(httpProvider);
  const [loading, setLoading] = useState(true);
  let data: any = '';

  useEffect(() => {
    if (reset) {
      setLoading(true);
    } else if (hash) {
      const interval = setInterval(async () => {
        data = await lib.eth.getTransactionReceipt(hash);
        if (data?.status) {
          clearInterval(interval);
          setLoading(false);
        }
      }, 5000);
      return () => {
        clearInterval(interval);
      };
    }
  }, [hash, data, reset]);
  return loading;
}
